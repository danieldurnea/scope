module github.com/bbounty-pro/orchestrator

go 1.23

require (
	github.com/go-chi/chi/v5      v5.2.0
	github.com/go-chi/cors        v1.2.1
	github.com/golang-jwt/jwt/v5  v5.2.1
	github.com/google/uuid        v1.6.0
	github.com/gorilla/websocket  v1.5.3
	github.com/jackc/pgx/v5       v5.7.1
	github.com/redis/go-redis/v9  v9.7.0
	github.com/rs/zerolog         v1.33.0
	github.com/spf13/viper        v1.19.0
	golang.org/x/crypto           v0.31.0
	golang.org/x/sync             v0.10.0
	golang.org/x/time             v0.9.0
)

require (
	github.com/alicebob/miniredis/v2 v2.33.0
)
