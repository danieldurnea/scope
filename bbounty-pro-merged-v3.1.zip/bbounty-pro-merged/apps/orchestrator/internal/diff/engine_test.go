package diff_test

import (
	"context"
	"testing"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/diff"
)

func makeSnap(scanID string, subs []string, findingHashes []diff.FindingRecord) *diff.ScanSnapshot {
	return &diff.ScanSnapshot{
		ScanID:     scanID,
		Target:     "example.com",
		CreatedAt:  time.Now(),
		Subdomains: subs,
		Findings:   findingHashes,
	}
}

func TestCompare_NewSubdomains(t *testing.T) {
	engine := diff.NewEngine(nil) // no Redis needed for Compare()

	old := makeSnap("scan-1", []string{"a.example.com", "b.example.com"}, nil)
	new := makeSnap("scan-2", []string{"a.example.com", "b.example.com", "c.example.com"}, nil)

	d := engine.Compare(context.Background(), old, new)

	if len(d.Subdomains.New) != 1 {
		t.Errorf("new subdomains = %d, want 1", len(d.Subdomains.New))
	}
	if d.Subdomains.New[0] != "c.example.com" {
		t.Errorf("new subdomain = %q, want c.example.com", d.Subdomains.New[0])
	}
	if len(d.Subdomains.Disappeared) != 0 {
		t.Errorf("disappeared = %d, want 0", len(d.Subdomains.Disappeared))
	}
	if d.Subdomains.Stable != 2 {
		t.Errorf("stable = %d, want 2", d.Subdomains.Stable)
	}
}

func TestCompare_DisappearedSubdomains(t *testing.T) {
	engine := diff.NewEngine(nil)

	old := makeSnap("s1", []string{"a.example.com", "gone.example.com"}, nil)
	new := makeSnap("s2", []string{"a.example.com"}, nil)

	d := engine.Compare(context.Background(), old, new)

	if len(d.Subdomains.Disappeared) != 1 {
		t.Errorf("disappeared = %d, want 1", len(d.Subdomains.Disappeared))
	}
}

func TestCompare_NewFinding(t *testing.T) {
	engine := diff.NewEngine(nil)

	hash1 := diff.FindingHash("XSS in search", "https://example.com/search", "XSS")
	hash2 := diff.FindingHash("New SQLi", "https://example.com/api", "SQLi")

	old := makeSnap("s1", nil, []diff.FindingRecord{
		{ID: "1", Title: "XSS in search", URL: "https://example.com/search", Severity: "high", Category: "XSS", Hash: hash1},
	})
	new := makeSnap("s2", nil, []diff.FindingRecord{
		{ID: "1", Title: "XSS in search", URL: "https://example.com/search", Severity: "high", Category: "XSS", Hash: hash1},
		{ID: "2", Title: "New SQLi", URL: "https://example.com/api", Severity: "critical", Category: "SQLi", Hash: hash2},
	})

	d := engine.Compare(context.Background(), old, new)

	if len(d.Findings.New) != 1 {
		t.Errorf("new findings = %d, want 1", len(d.Findings.New))
	}
	if d.Findings.New[0].Title != "New SQLi" {
		t.Errorf("new finding title = %q", d.Findings.New[0].Title)
	}
}

func TestCompare_FixedFinding(t *testing.T) {
	engine := diff.NewEngine(nil)

	hash := diff.FindingHash("Old XSS", "https://example.com", "XSS")

	old := makeSnap("s1", nil, []diff.FindingRecord{
		{ID: "1", Title: "Old XSS", URL: "https://example.com", Severity: "high", Category: "XSS", Hash: hash},
	})
	new := makeSnap("s2", nil, []diff.FindingRecord{}) // finding gone = fixed

	d := engine.Compare(context.Background(), old, new)

	if len(d.Findings.Fixed) != 1 {
		t.Errorf("fixed = %d, want 1", len(d.Findings.Fixed))
	}
	if len(d.Findings.New) != 0 {
		t.Errorf("new = %d, want 0", len(d.Findings.New))
	}
}

func TestCompare_SeverityEscalation(t *testing.T) {
	engine := diff.NewEngine(nil)

	hash := diff.FindingHash("SQL Injection", "https://example.com/api", "SQLi")

	old := makeSnap("s1", nil, []diff.FindingRecord{
		{Hash: hash, Severity: "medium", Title: "SQL Injection", URL: "https://example.com/api", Category: "SQLi"},
	})
	new := makeSnap("s2", nil, []diff.FindingRecord{
		{Hash: hash, Severity: "critical", Title: "SQL Injection", URL: "https://example.com/api", Category: "SQLi"},
	})

	d := engine.Compare(context.Background(), old, new)

	if len(d.Findings.SeverityUp) != 1 {
		t.Errorf("severity_up = %d, want 1", len(d.Findings.SeverityUp))
	}
	if d.Findings.SeverityUp[0].OldSev != "medium" {
		t.Errorf("old sev = %q", d.Findings.SeverityUp[0].OldSev)
	}
	if d.Findings.SeverityUp[0].NewSev != "critical" {
		t.Errorf("new sev = %q", d.Findings.SeverityUp[0].NewSev)
	}
}

func TestCompare_AlertLevel(t *testing.T) {
	engine := diff.NewEngine(nil)

	critHash := diff.FindingHash("RCE", "https://example.com/cmd", "RCE")

	old := makeSnap("s1", nil, nil)
	new := makeSnap("s2", nil, []diff.FindingRecord{
		{Hash: critHash, Title: "RCE", URL: "https://example.com/cmd", Severity: "critical", Category: "RCE"},
	})

	d := engine.Compare(context.Background(), old, new)

	if d.AlertLevel != "critical" {
		t.Errorf("alert_level = %q, want critical", d.AlertLevel)
	}
	if !d.HasNewCrits {
		t.Error("has_new_crits should be true")
	}
}

func TestShouldNotify(t *testing.T) {
	d := &diff.ScanDiff{
		Target:      "example.com",
		AlertLevel:  "critical",
		HasNewCrits: true,
	}
	notify, msg := diff.ShouldNotify(d)
	if !notify {
		t.Error("should notify on new criticals")
	}
	if msg == "" {
		t.Error("notification message empty")
	}
}

func TestFindingHash_Deterministic(t *testing.T) {
	h1 := diff.FindingHash("XSS", "https://example.com", "XSS")
	h2 := diff.FindingHash("XSS", "https://example.com", "XSS")
	if h1 != h2 {
		t.Errorf("FindingHash not deterministic: %q != %q", h1, h2)
	}

	h3 := diff.FindingHash("Different", "https://example.com", "XSS")
	if h1 == h3 {
		t.Error("different titles should produce different hashes")
	}
}
