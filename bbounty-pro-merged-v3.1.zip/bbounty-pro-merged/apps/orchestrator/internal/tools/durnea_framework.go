package tools

// ─────────────────────────────────────────────────────────────────────────────
// danieldurnea/BugBounty Framework Integration
//
// This file maps the full danieldurnea/BugBounty methodology (100+ tools,
// OWASP/PTES/WAHH phases, Docker deployment model, AI workflow) directly
// into the BBounty Pro Go orchestrator engine.
//
// Source: github.com/danieldurnea/BugBounty
// Structure adapted: scripts/automation/, configs/, docs/, docker/
// ─────────────────────────────────────────────────────────────────────────────

// DurnFrameworkPhase maps the repo's 5 testing phases to our pipeline
type DurnFrameworkPhase struct {
	ID          int
	Name        string
	Duration    string // typical duration from docs/workflow.md
	Description string
	Tools       []string
	OWASPRefs   []string // OWASP Testing Guide v4.2 categories
}

// DurnFramework is the full danieldurnea methodology embedded in the orchestrator
var DurnFramework = []DurnFrameworkPhase{
	{
		ID:       1,
		Name:     "Initial Setup",
		Duration: "1-2h",
		Description: "Create workspace, define scope, configure rate limits, " +
			"set up test accounts — mirrors scripts/new-program.sh",
		Tools:     []string{"scope-validator", "rate-limiter-config"},
		OWASPRefs: []string{"OTG-INFO-001", "OTG-INFO-002"},
	},
	{
		ID:       2,
		Name:     "Reconnaissance",
		Duration: "Day 1-2 (automated overnight)",
		Description: "Full recon pipeline: subdomain enum → DNS resolution → " +
			"HTTP probing → technology fingerprint → secrets/leaks. " +
			"Mirrors scripts/automation/recon-pipeline.sh",
		Tools: []string{
			// From repo's tool list — all categories
			"subfinder", "amass", "assetfinder", "chaos",     // Subdomain enum
			"httpx", "httprobe",                               // HTTP probing
			"katana", "gospider", "hakrawler", "waybackurls",  // Web crawling
			"gau", "waymore",                                  // Archive URLs
			"linkfinder", "secretfinder", "subjs",             // JS analysis
			"arjun", "paramspider", "x8",                      // Parameter discovery
			"whatweb", "webanalyze", "nuclei",                 // Tech detection
			"nmap", "masscan", "naabu", "rustscan",            // Port scanning
			"kiterunner", "graphql-cop",                       // API discovery
			"gitleaks", "truffleHog",                          // Secrets
			"bbot",                                            // OSINT automation
		},
		OWASPRefs: []string{
			"OTG-INFO-001", "OTG-INFO-002", "OTG-INFO-003",
			"OTG-INFO-004", "OTG-INFO-007", "OTG-INFO-009",
		},
	},
	{
		ID:       3,
		Name:     "Automated Scanning",
		Duration: "Day 2-3 (run overnight)",
		Description: "Comprehensive vuln scanning — Nuclei 9000+ templates, " +
			"CMS-specific scanners, SSL/TLS, directory fuzzing. " +
			"Mirrors the 'overnight scan' pattern from docs/workflow.md",
		Tools: []string{
			"nuclei",      // 9000+ templates: critical/high priority first
			"nikto",       // Web server misconfigs
			"wapiti",      // Web app scanner
			"wpscan",      // WordPress
			"joomscan",    // Joomla
			"droopescan",  // Drupal/Silverstripe
			"testssl",     // SSL/TLS config
			"sslscan",     // SSL cipher enumeration
			"ffuf",        // Directory/file fuzzing
			"gobuster",    // Dir/DNS/vhost brute
			"feroxbuster", // Recursive content discovery
			"wfuzz",       // Advanced web fuzzing
			"403fuzzer",   // 403 bypass
			"nomore403",   // 401/403 bypass advanced
		},
		OWASPRefs: []string{
			"OTG-CONFIG-001", "OTG-CONFIG-002", "OTG-CONFIG-006",
			"OTG-CRYPST-001", "OTG-CRYPST-002",
		},
	},
	{
		ID:       4,
		Name:     "Manual Testing",
		Duration: "Day 3-10 (human-guided)",
		Description: "Deep manual exploitation: auth, authz, injection, " +
			"business logic, API, file upload. AI assists but human drives. " +
			"Implements docs/checklist.md fully.",
		Tools: []string{
			// Authentication
			"sqlmap", "ghauri",         // SQL injection
			"dalfox", "xsstrike",        // XSS
			"commix",                    // Command injection
			"ssrfmap", "gopherus",       // SSRF
			"ysoserial", "phpggc",       // Deserialization
			"jwt-tool", "jwt-cracker",   // JWT attacks
			"hydra", "john", "hashcat",  // Password attacks
			"graphql-cop", "graphw00f",  // GraphQL
			"corsy",                     // CORS
			"crlfuzz",                   // CRLF injection
			"smuggler",                  // HTTP smuggling
			"race-the-web",              // Race conditions
		},
		OWASPRefs: []string{
			"OTG-AUTHN-001", "OTG-AUTHN-003", "OTG-AUTHZ-001",
			"OTG-INPVAL-001", "OTG-INPVAL-002", "OTG-INPVAL-003",
			"OTG-INPVAL-007", "OTG-INPVAL-011", "OTG-INPVAL-012",
			"OTG-BUSLOGIC-001", "OTG-SESS-001", "OTG-SESS-006",
		},
	},
	{
		ID:       5,
		Name:     "Reporting",
		Duration: "Ongoing",
		Description: "Document findings in findings.md format, CVSS scoring, " +
			"PoC creation, AI-assisted report drafting, platform submission. " +
			"Mirrors docs/findings.md template.",
		Tools:     []string{"report-generator", "cvss-calculator", "ai-reviewer"},
		OWASPRefs: []string{"Reporting"},
	},
}

// DurnReconPipeline mirrors scripts/automation/recon-pipeline.sh
// as a structured Go execution plan
type ReconPipelineStep struct {
	Step    int
	Name    string
	Cmd     string // template — {DOMAIN} replaced at runtime
	Output  string // output file pattern
	Depends []string // must complete before this step
	Async   bool     // can run in parallel with siblings
}

// ReconPipeline is the exact flow from recon-pipeline.sh, Go-ified
var ReconPipeline = []ReconPipelineStep{
	{
		Step:   1,
		Name:   "Passive Subdomain Enum",
		Cmd:    "subfinder -d {DOMAIN} -all -recursive -silent -o {OUTDIR}/subs_subfinder.txt",
		Output: "subs_subfinder.txt",
		Async:  true,
	},
	{
		Step:   2,
		Name:   "Amass Passive",
		Cmd:    "amass enum -passive -d {DOMAIN} -o {OUTDIR}/subs_amass.txt",
		Output: "subs_amass.txt",
		Async:  true, // runs in parallel with subfinder
	},
	{
		Step:   3,
		Name:   "Assetfinder",
		Cmd:    "assetfinder --subs-only {DOMAIN} | tee {OUTDIR}/subs_assetfinder.txt",
		Output: "subs_assetfinder.txt",
		Async:  true,
	},
	{
		Step:    4,
		Name:    "Deduplicate & Resolve",
		Cmd:     "sort -u {OUTDIR}/subs_*.txt > {OUTDIR}/subs_all.txt && puredns resolve {OUTDIR}/subs_all.txt --resolvers /opt/resolvers.txt -q -o {OUTDIR}/subs_resolved.txt",
		Output:  "subs_resolved.txt",
		Depends: []string{"subs_subfinder.txt", "subs_amass.txt", "subs_assetfinder.txt"},
		Async:   false,
	},
	{
		Step:    5,
		Name:    "HTTP Probe",
		Cmd:     "httpx -l {OUTDIR}/subs_resolved.txt -td -sc -title -wc -cl -json -rate-limit 150 -o {OUTDIR}/alive.json",
		Output:  "alive.json",
		Depends: []string{"subs_resolved.txt"},
		Async:   false,
	},
	{
		Step:    6,
		Name:    "Screenshot",
		Cmd:     "cat {OUTDIR}/subs_resolved.txt | aquatone -threads 5 -timeout 30000 -out {OUTDIR}/screenshots/",
		Output:  "screenshots/",
		Depends: []string{"subs_resolved.txt"},
		Async:   true, // can run in parallel with crawl
	},
	{
		Step:    7,
		Name:    "Web Crawl (katana)",
		Cmd:     "katana -list {OUTDIR}/alive.json -jc -kf all -aff -d 5 -c 50 -p 10 -o {OUTDIR}/urls_katana.txt",
		Output:  "urls_katana.txt",
		Depends: []string{"alive.json"},
		Async:   true,
	},
	{
		Step:    8,
		Name:    "Wayback URLs",
		Cmd:     "cat {OUTDIR}/subs_resolved.txt | waybackurls | tee {OUTDIR}/urls_wayback.txt",
		Output:  "urls_wayback.txt",
		Depends: []string{"subs_resolved.txt"},
		Async:   true,
	},
	{
		Step:    9,
		Name:    "GAU (Get All URLs)",
		Cmd:     "cat {OUTDIR}/subs_resolved.txt | gau --threads 5 | tee {OUTDIR}/urls_gau.txt",
		Output:  "urls_gau.txt",
		Depends: []string{"subs_resolved.txt"},
		Async:   true,
	},
	{
		Step:    10,
		Name:    "GF Pattern Matching",
		Cmd:     "cat {OUTDIR}/urls_*.txt | sort -u | gf xss | tee {OUTDIR}/gf_xss.txt && cat {OUTDIR}/urls_*.txt | sort -u | gf sqli | tee {OUTDIR}/gf_sqli.txt && cat {OUTDIR}/urls_*.txt | sort -u | gf ssrf | tee {OUTDIR}/gf_ssrf.txt && cat {OUTDIR}/urls_*.txt | sort -u | gf redirect | tee {OUTDIR}/gf_redirect.txt",
		Output:  "gf_*.txt",
		Depends: []string{"urls_katana.txt", "urls_wayback.txt", "urls_gau.txt"},
		Async:   false,
	},
	{
		Step:    11,
		Name:    "Nuclei — Critical/High Fast Pass",
		Cmd:     "nuclei -l {OUTDIR}/alive.json -t nuclei-templates/ -rate-limit 50 -severity critical,high -json-export {OUTDIR}/nuclei_critical.json -silent",
		Output:  "nuclei_critical.json",
		Depends: []string{"alive.json"},
		Async:   false,
	},
	{
		Step:    12,
		Name:    "JS Secret Scanning",
		Cmd:     "cat {OUTDIR}/urls_katana.txt | grep '\\.js$' | sort -u | while read url; do secretfinder -i \"$url\" -o cli 2>/dev/null; done | tee {OUTDIR}/js_secrets.txt",
		Output:  "js_secrets.txt",
		Depends: []string{"urls_katana.txt"},
		Async:   true,
	},
	{
		Step:    13,
		Name:    "Parameter Discovery",
		Cmd:     "arjun -i {OUTDIR}/alive.json -oJ {OUTDIR}/params.json -t 10 --stable",
		Output:  "params.json",
		Depends: []string{"alive.json"},
		Async:   true,
	},
	{
		Step:    14,
		Name:    "Port Scan",
		Cmd:     "naabu -l {OUTDIR}/subs_resolved.txt -p 80,443,8080,8443,8888,9090,3000,4000,5000,8000,9000,9200,6379,27017 -rate 2000 -json -o {OUTDIR}/ports.json",
		Output:  "ports.json",
		Depends: []string{"subs_resolved.txt"},
		Async:   true,
	},
	{
		Step:    15,
		Name:    "Gitleaks (repo scan)",
		Cmd:     "gitleaks detect --source {OUTDIR} -r {OUTDIR}/gitleaks_report.json -f json --no-banner",
		Output:  "gitleaks_report.json",
		Depends: []string{},
		Async:   true,
	},
}

// DurnDocTemplates mirrors the docs/ directory structure from the repo
// These are embedded directly in the report generator
var DurnDocTemplates = map[string]string{
	"finding": `## [FINDING-{ID}] {TITLE}

**Severity:** {SEVERITY} (CVSS: {CVSS_SCORE})  
**CVSS Vector:** {CVSS_VECTOR}  
**CWE:** {CWE}  
**Status:** {STATUS}

### Summary
{SUMMARY}

### Impact
{IMPACT}

### Steps to Reproduce
{STEPS}

### Proof of Concept
` + "```" + `
{POC}
` + "```" + `

### Affected Assets
{ASSETS}

### Remediation
{REMEDIATION}

### References
{REFERENCES}
`,

	"target": `# Target: {PROGRAM_NAME}

## Scope
### In-Scope
{IN_SCOPE}

### Out-of-Scope
{OUT_OF_SCOPE}

## Platform
- **Platform:** {PLATFORM}
- **URL:** {PLATFORM_URL}
- **Reward Range:** {REWARD_RANGE}
- **Response SLA:** {SLA}

## Rules
{RULES}

## Testing Notes
{NOTES}
`,

	"daily_workflow": `# Daily Recon Workflow — {DATE}

## Morning (AI Overnight Scan Review)
- [ ] Review nuclei output: {OUTDIR}/nuclei_critical.json
- [ ] Check new subdomains vs yesterday
- [ ] Triage JS secrets findings
- [ ] Review port scan deltas

## Afternoon (Manual Testing)
- [ ] Auth bypass attempts on identified endpoints
- [ ] Parameter fuzzing on gf_xss.txt / gf_sqli.txt
- [ ] Business logic testing on {TARGET}
- [ ] IDOR testing on authenticated endpoints

## Evening (Documentation)
- [ ] Document new findings in findings.md
- [ ] Calculate CVSS scores
- [ ] Draft PoC materials
- [ ] Commit recon outputs to git
`,

	"recon_summary": `# Recon Summary — {TARGET} — {DATE}

## Discovery Stats
| Metric | Count |
|--------|-------|
| Subdomains Found | {SUBS} |
| Live Hosts | {LIVE} |
| URLs Collected | {URLS} |
| Interesting Parameters | {PARAMS} |
| JS Files | {JS_FILES} |
| Open Ports (non-80/443) | {OPEN_PORTS} |
| Critical Nuclei Findings | {CRITICAL} |
| High Nuclei Findings | {HIGH} |

## Most Interesting Findings
{TOP_FINDINGS}

## Recommended Next Steps
{NEXT_STEPS}

## Tools Ran
{TOOLS_USED}
`,
}

// DurnAIWorkflow defines the AI vs Human responsibility split
// from docs/workflow.md — used by the AI Agent tab
var DurnAIWorkflow = struct {
	AIHandles     []string
	HumanHandles  []string
	StopConditions []string
}{
	AIHandles: []string{
		"Running reconnaissance tools (subfinder, httpx, nuclei, etc.)",
		"Parsing tool outputs and correlating results",
		"Generating automation scripts from templates",
		"Drafting vulnerability reports from findings",
		"Calculating CVSS 3.1 scores with full vector breakdown",
		"Creating PoC templates for identified vulnerability classes",
		"Suggesting testing strategies based on tech stack",
		"Overnight scan execution (daily-recon.sh equivalent)",
		"Deduplication and normalization of recon data",
		"Nuclei template selection based on identified tech",
	},
	HumanHandles: []string{
		"Scope interpretation — ambiguous wildcard decisions",
		"Complex manual testing requiring judgment",
		"Business logic analysis — understanding app flow",
		"Creative exploitation — chaining vulnerabilities",
		"Final report review before submission",
		"High-risk action approval (destructive tests)",
		"Authorization of new testing vectors",
		"Real user data handling decisions",
	},
	StopConditions: []string{
		"Scope is ambiguous — require human clarification",
		"Action could cause unintended service disruption",
		"Accessing real production user data detected",
		"Unintended system behavior observed",
		"Legal or ethical concerns arise",
		"Evidence of active breach by third party",
		"Rate limits exceeded — target showing stress",
		"ROE gate validation fails for any target",
	},
}

// DurnBurpExtensions lists recommended Burp extensions from configs/burp-extensions.txt
var DurnBurpExtensions = []struct {
	Name    string
	Purpose string
}{
	{"Autorize", "Authorization testing — catch IDOR/privilege escalation"},
	{"Active Scan++", "Enhanced active scanning rules"},
	{"JWT Editor", "JWT manipulation and attacks"},
	{"Param Miner", "Hidden parameter discovery"},
	{"Turbo Intruder", "High-speed intruder for race conditions"},
	{"Upload Scanner", "File upload vulnerability detection"},
	{"Logger++", "Advanced request/response logging"},
	{"Hackvertor", "Encoding/decoding transformations"},
	{"CORS*, NGINX, Spring Misconfiguration", "Misconfiguration detection"},
}

// DurnNucleiConfig mirrors configs/nuclei-config.yaml
var DurnNucleiConfig = `# Nuclei config — danieldurnea/BugBounty framework
# Optimized for bug bounty: accuracy over coverage

rate-limit: 50
bulk-size: 25
concurrency: 10
timeout: 10
retries: 2
max-host-error: 30
no-interactsh: false

# Templates priority order for bug bounty
templates:
  - nuclei-templates/cves/
  - nuclei-templates/vulnerabilities/
  - nuclei-templates/exposed-panels/
  - nuclei-templates/exposures/
  - nuclei-templates/misconfiguration/
  - nuclei-templates/takeovers/
  - nuclei-templates/technologies/

# Severity filter — focus on submittable findings
severity:
  - critical
  - high
  - medium

# Exclusions — too noisy for bug bounty
exclude-tags:
  - dos
  - fuzz
  - generic
  
interactsh-server: ""
report-config: ""
`

// DurnDockerConfig mirrors docker/docker-compose.yml approach
// but upgraded to our infra/docker-compose.yml standard
var DurnDockerNotes = `
# danieldurnea/BugBounty Docker Integration Notes:
#
# Original: Kali Linux base image with all 100+ tools
# Our upgrade:
#   - Split into tool-runner container (Kali-based) + orchestrator (Go scratch)
#   - Orchestrator binary calls tools via exec into the kali container
#   - Results stream back via WebSocket to frontend
#   - Volume mounts for persistent scan results
#
# docker/build.sh equivalent: make docker-build
# docker/start.sh equivalent: make docker-up  
# docker/shell.sh equivalent: make docker-shell
`
