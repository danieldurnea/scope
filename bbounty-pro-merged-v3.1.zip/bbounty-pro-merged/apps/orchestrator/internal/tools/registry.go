package tools

import (
	"context"
	"encoding/json"
	"net/http"
	"sort"

	"github.com/go-chi/chi/v5"
)

// Phase constants
const (
	PhaseRecon   = "recon"
	PhaseEnum    = "enumeration"
	PhaseScan    = "scanning"
	PhaseExploit = "exploitation"
	PhaseReport  = "reporting"
)

// ROIRating represents tool effectiveness score
type ROIRating int

const (
	ROILow      ROIRating = 1
	ROIMedium   ROIRating = 2
	ROIHigh     ROIRating = 3
	ROICritical ROIRating = 4
)

// Tool represents a single security tool in the registry
type Tool struct {
	ID          string    `json:"id"`
	Name        string    `json:"name"`
	Phase       string    `json:"phase"`
	Category    string    `json:"category"`
	Description string    `json:"description"`
	InstallCmd  string    `json:"install_cmd"`
	BinaryPath  string    `json:"binary_path"`
	ROI         ROIRating `json:"roi"`
	Flags       []Flag    `json:"flags"`
	Enabled     bool      `json:"enabled"`
	Parallel    bool      `json:"parallel"` // safe to run in parallel
	Timeout     int       `json:"timeout"`  // seconds, 0 = phase default
	Tags        []string  `json:"tags"`
}

type Flag struct {
	Name        string `json:"name"`
	Description string `json:"description"`
	Default     string `json:"default"`
	Required    bool   `json:"required"`
}

// Registry holds all tool definitions
type Registry struct {
	tools map[string]*Tool
}

// NewRegistry returns a registry with all 44 tools pre-loaded
func NewRegistry() *Registry {
	r := &Registry{tools: make(map[string]*Tool)}
	r.loadAll()
	return r
}

func (r *Registry) loadAll() {
	tools := []*Tool{
		// ─────────────── PHASE 1: RECON ───────────────
		{
			ID: "subfinder", Name: "subfinder", Phase: PhaseRecon, Category: "subdomain",
			Description: "Fast passive subdomain enumeration tool",
			InstallCmd:  "go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest",
			BinaryPath:  "subfinder", ROI: ROICritical, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-d", Description: "Target domain", Required: true},
				{Name: "-all", Description: "Use all sources", Default: "true"},
				{Name: "-silent", Description: "Silent mode"},
				{Name: "-o", Description: "Output file", Default: "subs.txt"},
			},
			Tags: []string{"passive", "recon", "dns"},
		},
		{
			ID: "assetfinder", Name: "assetfinder", Phase: PhaseRecon, Category: "subdomain",
			Description: "Find domains and subdomains related to a given domain",
			InstallCmd:  "go install github.com/tomnomnom/assetfinder@latest",
			BinaryPath:  "assetfinder", ROI: ROIHigh, Parallel: true, Timeout: 60,
			Flags: []Flag{{Name: "--subs-only", Description: "Only show subdomains"}},
			Tags: []string{"passive", "recon"},
		},
		{
			ID: "puredns", Name: "puredns", Phase: PhaseRecon, Category: "dns",
			Description: "Powerful DNS bruteforcing and resolution tool",
			InstallCmd:  "go install github.com/d3mondev/puredns/v2@latest",
			BinaryPath:  "puredns", ROI: ROICritical, Parallel: false, Timeout: 300,
			Flags: []Flag{
				{Name: "bruteforce", Description: "Mode: bruteforce or resolve"},
				{Name: "--resolvers", Description: "Resolvers file", Default: "/opt/resolvers.txt"},
				{Name: "--rate-limit", Description: "Rate limit", Default: "3000"},
			},
			Tags: []string{"active", "dns", "bruteforce"},
		},
		{
			ID: "bbot", Name: "bbot", Phase: PhaseRecon, Category: "osint",
			Description: "OSINT automation tool — recursive recon powerhouse",
			InstallCmd:  "pipx install bbot",
			BinaryPath:  "bbot", ROI: ROICritical, Parallel: false, Timeout: 600,
			Flags: []Flag{
				{Name: "-t", Description: "Targets", Required: true},
				{Name: "-p", Description: "Presets", Default: "subdomain-enum"},
				{Name: "-o", Description: "Output dir"},
			},
			Tags: []string{"osint", "recon", "comprehensive"},
		},
		{
			ID: "whatweb", Name: "whatweb", Phase: PhaseRecon, Category: "fingerprint",
			Description: "Web technology fingerprinting — identifies CMS, frameworks, headers",
			InstallCmd:  "gem install whatweb",
			BinaryPath:  "whatweb", ROI: ROIHigh, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-a", Description: "Aggression level (1-4)", Default: "3"},
				{Name: "--log-json", Description: "JSON output"},
			},
			Tags: []string{"fingerprint", "recon"},
		},
		{
			ID: "wafw00f", Name: "wafw00f", Phase: PhaseRecon, Category: "waf",
			Description: "WAF detection & fingerprinting — critical for bypass planning",
			InstallCmd:  "pip install wafw00f",
			BinaryPath:  "wafw00f", ROI: ROIHigh, Parallel: true, Timeout: 60,
			Flags: []Flag{
				{Name: "-a", Description: "Find all WAFs"},
				{Name: "-o", Description: "Output file"},
			},
			Tags: []string{"waf", "recon", "fingerprint"},
		},
		{
			ID: "gitleaks", Name: "gitleaks", Phase: PhaseRecon, Category: "secrets",
			Description: "Detect secrets leaked in git repos — API keys, tokens, creds",
			InstallCmd:  "go install github.com/gitleaks/gitleaks/v8@latest",
			BinaryPath:  "gitleaks", ROI: ROICritical, Parallel: true, Timeout: 180,
			Flags: []Flag{
				{Name: "detect", Description: "Mode: detect or protect"},
				{Name: "--source", Description: "Path to repo"},
				{Name: "-r", Description: "Report format", Default: "json"},
			},
			Tags: []string{"secrets", "recon", "passive"},
		},

		// ─────────────── PHASE 2: ENUMERATION ───────────────
		{
			ID: "httpx", Name: "httpx", Phase: PhaseEnum, Category: "http",
			Description: "Fast multi-purpose HTTP toolkit — probe, tech-detect, screenshot",
			InstallCmd:  "go install -v github.com/projectdiscovery/httpx/cmd/httpx@latest",
			BinaryPath:  "httpx", ROI: ROICritical, Parallel: true, Timeout: 180,
			Flags: []Flag{
				{Name: "-l", Description: "Input file"},
				{Name: "-td", Description: "Tech detection"},
				{Name: "-sc", Description: "Status codes"},
				{Name: "-title", Description: "Page titles"},
				{Name: "-json", Description: "JSON output"},
				{Name: "-rate-limit", Description: "Rate limit", Default: "150"},
			},
			Tags: []string{"http", "probe", "active"},
		},
		{
			ID: "naabu", Name: "naabu", Phase: PhaseEnum, Category: "ports",
			Description: "Fast port scanner — SYN scan, optimized for bug bounty scale",
			InstallCmd:  "go install -v github.com/projectdiscovery/naabu/v2/cmd/naabu@latest",
			BinaryPath:  "naabu", ROI: ROIHigh, Parallel: false, Timeout: 300,
			Flags: []Flag{
				{Name: "-l", Description: "Input file"},
				{Name: "-p", Description: "Ports", Default: "80,443,8080,8443,8888"},
				{Name: "-rate", Description: "Rate limit", Default: "1000"},
				{Name: "-json", Description: "JSON output"},
			},
			Tags: []string{"ports", "active", "scan"},
		},
		{
			ID: "aquatone", Name: "aquatone", Phase: PhaseEnum, Category: "screenshot",
			Description: "Visual website inspection — screenshots all live hosts",
			InstallCmd:  "go install github.com/michenriksen/aquatone@latest",
			BinaryPath:  "aquatone", ROI: ROIHigh, Parallel: false, Timeout: 300,
			Flags: []Flag{
				{Name: "-threads", Description: "Threads", Default: "5"},
				{Name: "-timeout", Description: "Timeout ms", Default: "30000"},
				{Name: "-out", Description: "Output dir"},
			},
			Tags: []string{"screenshot", "visual", "enum"},
		},
		{
			ID: "hakrawler", Name: "hakrawler", Phase: PhaseEnum, Category: "crawl",
			Description: "Web crawler — extracts endpoints, JS files, forms",
			InstallCmd:  "go install github.com/hakluke/hakrawler@latest",
			BinaryPath:  "hakrawler", ROI: ROIHigh, Parallel: true, Timeout: 180,
			Flags: []Flag{
				{Name: "-depth", Description: "Crawl depth", Default: "3"},
				{Name: "-subs", Description: "Include subdomains"},
				{Name: "-js", Description: "Extract JS files"},
				{Name: "-forms", Description: "Extract forms"},
			},
			Tags: []string{"crawl", "enum", "js"},
		},
		{
			ID: "gospider", Name: "gospider", Phase: PhaseEnum, Category: "crawl",
			Description: "Fast web spider — JS parser + sitemap + robots.txt",
			InstallCmd:  "go install github.com/jaeles-project/gospider@latest",
			BinaryPath:  "gospider", ROI: ROIHigh, Parallel: true, Timeout: 180,
			Flags: []Flag{
				{Name: "-s", Description: "Site URL"},
				{Name: "-t", Description: "Threads", Default: "5"},
				{Name: "-c", Description: "Concurrent", Default: "5"},
				{Name: "--json", Description: "JSON output"},
			},
			Tags: []string{"crawl", "spider", "enum"},
		},
		{
			ID: "gf", Name: "gf", Phase: PhaseEnum, Category: "pattern",
			Description: "Grep patterns for interesting parameters — XSS, SQLi, SSRF, etc.",
			InstallCmd:  "go install github.com/tomnomnom/gf@latest && git clone https://github.com/1ndianl33t/Gf-Patterns ~/.gf",
			BinaryPath:  "gf", ROI: ROICritical, Parallel: true, Timeout: 30,
			Flags: []Flag{
				{Name: "xss|sqli|ssrf|redirect|rce|idor", Description: "Pattern name", Required: true},
			},
			Tags: []string{"pattern", "filter", "enum"},
		},

		// ─────────────── PHASE 3: SCANNING ───────────────
		{
			ID: "nuclei", Name: "nuclei-ai", Phase: PhaseScan, Category: "vuln",
			Description: "AI-assisted vulnerability scanner — 9000+ templates",
			InstallCmd:  "go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest",
			BinaryPath:  "nuclei", ROI: ROICritical, Parallel: false, Timeout: 600,
			Flags: []Flag{
				{Name: "-l", Description: "Targets list"},
				{Name: "-t", Description: "Templates", Default: "nuclei-templates/"},
				{Name: "-rate-limit", Description: "Rate limit", Default: "50"},
				{Name: "-severity", Description: "Severity filter", Default: "medium,high,critical"},
				{Name: "-json-export", Description: "JSON output file"},
				{Name: "-ai", Description: "AI mode"},
			},
			Tags: []string{"vuln", "scan", "templates"},
		},
		{
			ID: "nikto", Name: "nikto", Phase: PhaseScan, Category: "web",
			Description: "Enhanced web server scanner — misconfigs, outdated software",
			InstallCmd:  "apt install nikto -y",
			BinaryPath:  "nikto", ROI: ROIMedium, Parallel: true, Timeout: 300,
			Flags: []Flag{
				{Name: "-h", Description: "Target host", Required: true},
				{Name: "-Format", Description: "Output format", Default: "json"},
				{Name: "-Tuning", Description: "Scan tuning", Default: "x6"},
				{Name: "-maxtime", Description: "Max scan time", Default: "300s"},
			},
			Tags: []string{"web", "scan", "misconfig"},
		},
		{
			ID: "ffuf", Name: "ffuf", Phase: PhaseScan, Category: "fuzz",
			Description: "Fast web fuzzer — directory/file discovery, parameter bruteforce",
			InstallCmd:  "go install github.com/ffuf/ffuf/v2@latest",
			BinaryPath:  "ffuf", ROI: ROICritical, Parallel: true, Timeout: 300,
			Flags: []Flag{
				{Name: "-u", Description: "Target URL", Required: true},
				{Name: "-w", Description: "Wordlist", Default: "/opt/wordlists/common.txt"},
				{Name: "-mc", Description: "Match codes", Default: "200,301,302,403"},
				{Name: "-rate", Description: "Rate limit", Default: "100"},
				{Name: "-json", Description: "JSON output"},
				{Name: "-recursion", Description: "Recursive fuzz"},
			},
			Tags: []string{"fuzz", "discovery", "scan"},
		},
		{
			ID: "wfuzz", Name: "wfuzz", Phase: PhaseScan, Category: "fuzz",
			Description: "Web fuzzer — advanced filter/match capabilities",
			InstallCmd:  "pip install wfuzz",
			BinaryPath:  "wfuzz", ROI: ROIHigh, Parallel: true, Timeout: 300,
			Flags: []Flag{
				{Name: "-u", Description: "Target URL", Required: true},
				{Name: "-w", Description: "Wordlist", Required: true},
				{Name: "--hc", Description: "Hide codes", Default: "404"},
				{Name: "-t", Description: "Threads", Default: "50"},
			},
			Tags: []string{"fuzz", "web", "scan"},
		},
		{
			ID: "403fuzzer", Name: "403fuzzer", Phase: PhaseScan, Category: "bypass",
			Description: "403 Forbidden bypass fuzzer — path manipulation techniques",
			InstallCmd:  "git clone https://github.com/yunemse48/403fuzzer && pip install -r requirements.txt",
			BinaryPath:  "python3 403fuzzer/403fuzzer.py", ROI: ROIHigh, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-u", Description: "Target URL", Required: true},
				{Name: "-t", Description: "Threads", Default: "10"},
			},
			Tags: []string{"bypass", "403", "scan"},
		},
		{
			ID: "nomore403", Name: "nomore403", Phase: PhaseScan, Category: "bypass",
			Description: "Advanced 403/401 bypass — headers, methods, path variants",
			InstallCmd:  "go install github.com/devploit/nomore403@latest",
			BinaryPath:  "nomore403", ROI: ROIHigh, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "--url", Description: "Target URL", Required: true},
				{Name: "--verbose", Description: "Verbose output"},
			},
			Tags: []string{"bypass", "403", "scan"},
		},
		{
			ID: "graphw00f", Name: "graphw00f", Phase: PhaseScan, Category: "graphql",
			Description: "GraphQL engine fingerprinting — identify backend implementation",
			InstallCmd:  "pip install graphw00f",
			BinaryPath:  "graphw00f", ROI: ROIHigh, Parallel: true, Timeout: 60,
			Flags: []Flag{
				{Name: "-t", Description: "Target URL", Required: true},
				{Name: "-d", Description: "Detect mode"},
				{Name: "-f", Description: "Fingerprint"},
			},
			Tags: []string{"graphql", "fingerprint", "scan"},
		},

		// ─────────────── PHASE 4: EXPLOITATION ───────────────
		{
			ID: "commix", Name: "commix", Phase: PhaseExploit, Category: "injection",
			Description: "OS command injection exploiter — automated parameter testing",
			InstallCmd:  "git clone https://github.com/commixproject/commix /opt/commix",
			BinaryPath:  "python3 /opt/commix/commix.py", ROI: ROICritical, Parallel: false, Timeout: 300,
			Flags: []Flag{
				{Name: "--url", Description: "Target URL", Required: true},
				{Name: "--level", Description: "Test level (1-3)", Default: "2"},
				{Name: "--output-dir", Description: "Output directory"},
			},
			Tags: []string{"rce", "injection", "exploit"},
		},
		{
			ID: "corsy", Name: "corsy", Phase: PhaseExploit, Category: "cors",
			Description: "CORS misconfiguration scanner — all known bypass techniques",
			InstallCmd:  "git clone https://github.com/s0md3v/Corsy && pip install -r requirements.txt",
			BinaryPath:  "python3 /opt/Corsy/corsy.py", ROI: ROIHigh, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-i", Description: "Input file"},
				{Name: "-t", Description: "Threads", Default: "10"},
				{Name: "-o", Description: "Output file"},
			},
			Tags: []string{"cors", "exploit", "misconfig"},
		},
		{
			ID: "crlfuzz", Name: "crlfuzz", Phase: PhaseExploit, Category: "injection",
			Description: "CRLF injection scanner — header injection vulnerabilities",
			InstallCmd:  "go install github.com/dwisiswant0/crlfuzz/cmd/crlfuzz@latest",
			BinaryPath:  "crlfuzz", ROI: ROIHigh, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-u", Description: "Target URL", Required: true},
				{Name: "-c", Description: "Concurrency", Default: "25"},
				{Name: "-s", Description: "Silent mode"},
			},
			Tags: []string{"crlf", "injection", "exploit"},
		},
		{
			ID: "ssrfmap", Name: "ssrfmap", Phase: PhaseExploit, Category: "ssrf",
			Description: "SSRF detection & exploitation — supports 14 protocols",
			InstallCmd:  "git clone https://github.com/swisskyrepo/SSRFmap /opt/ssrfmap && pip install -r requirements.txt",
			BinaryPath:  "python3 /opt/ssrfmap/ssrfmap.py", ROI: ROICritical, Parallel: false, Timeout: 300,
			Flags: []Flag{
				{Name: "-r", Description: "Request file", Required: true},
				{Name: "-p", Description: "Parameter"},
				{Name: "-m", Description: "Module"},
			},
			Tags: []string{"ssrf", "exploit"},
		},
		{
			ID: "smuggler", Name: "smuggler", Phase: PhaseExploit, Category: "http",
			Description: "HTTP request smuggling detection — CL.TE, TE.CL, TE.TE variants",
			InstallCmd:  "git clone https://github.com/defparam/smuggler /opt/smuggler",
			BinaryPath:  "python3 /opt/smuggler/smuggler.py", ROI: ROICritical, Parallel: false, Timeout: 300,
			Flags: []Flag{
				{Name: "-u", Description: "Target URL", Required: true},
				{Name: "-t", Description: "Threads", Default: "5"},
				{Name: "--log", Description: "Log file"},
			},
			Tags: []string{"smuggling", "http", "exploit"},
		},
		{
			ID: "jwt-tool", Name: "jwt-tool", Phase: PhaseExploit, Category: "jwt",
			Description: "JWT attack toolkit — alg confusion, none, cracking, tampering",
			InstallCmd:  "git clone https://github.com/ticarpi/jwt_tool /opt/jwt-tool && pip install -r requirements.txt",
			BinaryPath:  "python3 /opt/jwt-tool/jwt_tool.py", ROI: ROICritical, Parallel: true, Timeout: 120,
			Flags: []Flag{
				{Name: "-t", Description: "Target URL"},
				{Name: "-rh", Description: "Request headers"},
				{Name: "-M", Description: "Mode: at,ab,as,ao,ar,au,rs,er,ec,es,eo,ep,eb"},
			},
			Tags: []string{"jwt", "auth", "exploit"},
		},
		{
			ID: "race-the-web", Name: "race-the-web", Phase: PhaseExploit, Category: "race",
			Description: "Race condition testing — concurrent request campaigns",
			InstallCmd:  "go install github.com/nicowillis/race-the-web@latest",
			BinaryPath:  "race-the-web", ROI: ROIHigh, Parallel: false, Timeout: 120,
			Flags: []Flag{
				{Name: "-config", Description: "Config TOML file", Required: true},
			},
			Tags: []string{"race", "condition", "exploit"},
		},
	}

	for _, t := range tools {
		t.Enabled = true // default enabled
		r.tools[t.ID] = t
	}
}

func (r *Registry) Get(id string) (*Tool, bool) {
	t, ok := r.tools[id]
	return t, ok
}

func (r *Registry) All() []*Tool {
	tools := make([]*Tool, 0, len(r.tools))
	for _, t := range r.tools {
		tools = append(tools, t)
	}
	sort.Slice(tools, func(i, j int) bool {
		return tools[i].Phase < tools[j].Phase
	})
	return tools
}

func (r *Registry) ByPhase(phase string) []*Tool {
	var result []*Tool
	for _, t := range r.tools {
		if t.Phase == phase {
			result = append(result, t)
		}
	}
	return result
}

func (r *Registry) HandleList(w http.ResponseWriter, req *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(r.All())
}

func (r *Registry) HandleInfo(w http.ResponseWriter, req *http.Request) {
	id := chi.URLParam(req, "toolID")
	t, ok := r.Get(id)
	if !ok {
		http.Error(w, `{"error":"tool not found"}`, http.StatusNotFound)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(t)
}

func (r *Registry) HandleRunSingle(w http.ResponseWriter, req *http.Request) {
	// Single tool run — delegates to executor
	w.WriteHeader(http.StatusAccepted)
	w.Write([]byte(`{"status":"queued"}`))
}
