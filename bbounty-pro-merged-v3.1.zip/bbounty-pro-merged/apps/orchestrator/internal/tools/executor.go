package tools

import (
	"fmt"
	"path/filepath"
	"strings"
)

// BuildContext holds all context needed to construct tool commands
type BuildContext struct {
	Target   string
	ScanID   string
	OutDir   string
	PrevOuts map[string]string // toolID → output file path
	Scope    []string
}

// OutputPath returns the canonical output path for a tool's results
func OutputPath(outDir, scanID, toolID, ext string) string {
	return filepath.Join(outDir, fmt.Sprintf("%s_%s.%s", scanID[:8], toolID, ext))
}

// BuildCommand constructs the shell command for a given tool, using prior phase outputs
// as inputs where applicable. All paths use scanID-namespaced temp files.
func BuildCommand(tool *Tool, ctx BuildContext) string {
	id := tool.ID
	scanID8 := ctx.ScanID[:8]
	outDir := ctx.OutDir
	if outDir == "" {
		outDir = "/tmp"
	}

	// Canonical output files — standardised names per tool
	subsFile := filepath.Join(outDir, scanID8+"_subs.txt")
	liveFile := filepath.Join(outDir, scanID8+"_live.txt")
	liveJSON := filepath.Join(outDir, scanID8+"_live.json")
	urlsFile := filepath.Join(outDir, scanID8+"_urls.txt")
	portsFile := filepath.Join(outDir, scanID8+"_ports.json")

	target := ctx.Target

	switch id {
	// ─── Phase 1: Recon ───────────────────────────────────────────────────────

	case "subfinder":
		return fmt.Sprintf(
			`subfinder -d %s -all -silent -t 20 -timeout 30 -o %s 2>&1 | tee /dev/stderr`,
			target, subsFile,
		)

	case "assetfinder":
		return fmt.Sprintf(
			`assetfinder --subs-only %s | tee -a %s`,
			target, subsFile,
		)

	case "puredns":
		return fmt.Sprintf(
			`puredns bruteforce /opt/wordlists/subdomains-top1million-5000.txt %s `+
				`--resolvers /opt/resolvers.txt `+
				`--rate-limit 3000 `+
				`--wildcard-tests 5 `+
				`| tee -a %s`,
			target, subsFile,
		)

	case "bbot":
		outBbotDir := filepath.Join(outDir, scanID8+"_bbot")
		return fmt.Sprintf(
			`bbot -t %s -p subdomain-enum -o %s --silent 2>&1 | grep "DNS_NAME\|EMAIL\|IP_ADDRESS" | tee -a %s`,
			target, outBbotDir, subsFile,
		)

	case "whatweb":
		return fmt.Sprintf(
			`whatweb -a 3 --log-json=%s %s 2>&1`,
			filepath.Join(outDir, scanID8+"_whatweb.json"), target,
		)

	case "wafw00f":
		return fmt.Sprintf(
			`wafw00f -a -o %s https://%s 2>&1 && wafw00f -a http://%s 2>&1`,
			filepath.Join(outDir, scanID8+"_waf.json"), target, target,
		)

	case "gitleaks":
		return fmt.Sprintf(
			`gitleaks detect --source . -r %s -f json 2>&1 || true`,
			filepath.Join(outDir, scanID8+"_secrets.json"),
		)

	// ─── Phase 2: Enumeration ──────────────────────────────────────────────────

	case "httpx":
		// Deduplicate subs first, then probe
		return fmt.Sprintf(
			`sort -u %s | httpx `+
				`-silent `+
				`-title -tech-detect -status-code -content-length -response-time `+
				`-rate-limit 150 `+
				`-threads 50 `+
				`-timeout 10 `+
				`-json -o %s `+
				`2>&1 | tee %s`,
			subsFile, liveJSON, liveFile,
		)

	case "naabu":
		return fmt.Sprintf(
			`naabu -l %s `+
				`-p 80,443,8080,8443,8000,8888,9090,3000,5000,4443,7443,8181,9200,27017 `+
				`-rate 1500 `+
				`-timeout 5000 `+
				`-silent `+
				`-json -o %s `+
				`2>&1`,
			subsFile, portsFile,
		)

	case "aquatone":
		return fmt.Sprintf(
			`cat %s | aquatone `+
				`-threads 5 `+
				`-timeout 30000 `+
				`-screenshot-timeout 30000 `+
				`-out %s `+
				`2>&1`,
			liveFile, filepath.Join(outDir, scanID8+"_aquatone"),
		)

	case "hakrawler":
		return fmt.Sprintf(
			`cat %s | hakrawler `+
				`-depth 3 `+
				`-subs `+
				`-u `+
				`-insecure `+
				`2>&1 | sort -u | tee %s`,
			liveFile, urlsFile,
		)

	case "gospider":
		return fmt.Sprintf(
			`gospider -S %s `+
				`-t 5 `+
				`-c 10 `+
				`-d 3 `+
				`--sitemap `+
				`--robots `+
				`--json `+
				`-o %s `+
				`2>&1`,
			liveFile, filepath.Join(outDir, scanID8+"_gospider"),
		)

	case "gf":
		patterns := []string{"xss", "sqli", "ssrf", "redirect", "rce", "idor", "lfi", "debug_logic"}
		cmds := make([]string, 0, len(patterns))
		for _, pat := range patterns {
			out := filepath.Join(outDir, fmt.Sprintf("%s_gf_%s.txt", scanID8, pat))
			cmds = append(cmds, fmt.Sprintf("cat %s | gf %s | tee %s", urlsFile, pat, out))
		}
		return strings.Join(cmds, " ; ")

	// ─── Phase 3: Scanning ────────────────────────────────────────────────────

	case "nuclei":
		return fmt.Sprintf(
			`nuclei `+
				`-l %s `+
				`-t nuclei-templates/ `+
				`-rate-limit 50 `+
				`-bulk-size 25 `+
				`-concurrency 10 `+
				`-severity medium,high,critical `+
				`-timeout 10 `+
				`-retries 1 `+
				`-silent `+
				`-json-export %s `+
				`2>&1`,
			liveFile, filepath.Join(outDir, scanID8+"_nuclei.json"),
		)

	case "ffuf":
		return fmt.Sprintf(
			`ffuf `+
				`-u https://%s/FUZZ `+
				`-w /opt/wordlists/raft-medium.txt `+
				`-mc 200,201,204,301,302,307,401,403,405 `+
				`-fc 404 `+
				`-rate 100 `+
				`-timeout 10 `+
				`-recursion -recursion-depth 2 `+
				`-se `+
				`-json `+
				`-o %s `+
				`2>&1`,
			target, filepath.Join(outDir, scanID8+"_ffuf.json"),
		)

	case "wfuzz":
		return fmt.Sprintf(
			`wfuzz `+
				`-u https://%s/FUZZ `+
				`-w /opt/wordlists/common.txt `+
				`--hc 404,429 `+
				`-t 50 `+
				`-f %s,json `+
				`2>&1`,
			target, filepath.Join(outDir, scanID8+"_wfuzz.json"),
		)

	case "nikto":
		return fmt.Sprintf(
			`nikto `+
				`-h https://%s `+
				`-Format json `+
				`-output %s `+
				`-Tuning x6 `+
				`-maxtime 300s `+
				`-nointeractive `+
				`2>&1`,
			target, filepath.Join(outDir, scanID8+"_nikto.json"),
		)

	case "403fuzzer":
		return fmt.Sprintf(
			`python3 /opt/bbounty-tools/403fuzzer/403fuzzer.py `+
				`-u https://%s/admin `+
				`-t 10 `+
				`2>&1 | tee %s`,
			target, filepath.Join(outDir, scanID8+"_403fuzzer.txt"),
		)

	case "nomore403":
		return fmt.Sprintf(
			`nomore403 --url https://%s/admin --verbose 2>&1 | tee %s`,
			target, filepath.Join(outDir, scanID8+"_nomore403.txt"),
		)

	case "graphw00f":
		return fmt.Sprintf(
			`graphw00f -t https://%s/graphql -d -f 2>&1 | tee %s`,
			target, filepath.Join(outDir, scanID8+"_graphw00f.txt"),
		)

	// ─── Phase 4: Exploitation ────────────────────────────────────────────────

	case "commix":
		return fmt.Sprintf(
			`python3 /opt/commix/commix.py `+
				`--url="https://%s/?id=1" `+
				`--level=2 `+
				`--output-dir=%s `+
				`--batch `+
				`2>&1`,
			target, filepath.Join(outDir, scanID8+"_commix"),
		)

	case "corsy":
		return fmt.Sprintf(
			`python3 /opt/bbounty-tools/Corsy/corsy.py `+
				`-i %s `+
				`-t 10 `+
				`-o %s `+
				`2>&1`,
			liveFile, filepath.Join(outDir, scanID8+"_corsy.json"),
		)

	case "crlfuzz":
		return fmt.Sprintf(
			`crlfuzz -u https://%s/ -c 25 -s 2>&1 | tee %s`,
			target, filepath.Join(outDir, scanID8+"_crlfuzz.txt"),
		)

	case "ssrfmap":
		reqFile := filepath.Join(outDir, scanID8+"_ssrf_req.txt")
		// Write a sample request file first
		writeReqCmd := fmt.Sprintf(
			`printf 'GET /?url=SSRF_URL HTTP/1.1\r\nHost: %s\r\nUser-Agent: Mozilla/5.0\r\n\r\n' > %s`,
			target, reqFile,
		)
		return writeReqCmd + " && " + fmt.Sprintf(
			`python3 /opt/ssrfmap/ssrfmap.py -r %s -p url -m readfiles 2>&1 | tee %s`,
			reqFile, filepath.Join(outDir, scanID8+"_ssrfmap.txt"),
		)

	case "smuggler":
		return fmt.Sprintf(
			`python3 /opt/smuggler/smuggler.py `+
				`-u https://%s/ `+
				`-t 5 `+
				`--log %s `+
				`2>&1`,
			target, filepath.Join(outDir, scanID8+"_smuggler.txt"),
		)

	case "jwt-tool":
		return fmt.Sprintf(
			`python3 /opt/jwt-tool/jwt_tool.py `+
				`-t https://%s/ `+
				`-rh "Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.e30.invalid" `+
				`-M at `+
				`2>&1 | tee %s`,
			target, filepath.Join(outDir, scanID8+"_jwt.txt"),
		)

	case "race-the-web":
		cfgFile := filepath.Join(outDir, scanID8+"_race.toml")
		writeCfg := fmt.Sprintf(
			`cat > %s << 'EOF'\n[[requests]]\nurl = "https://%s/api/redeem"\nmethod = "POST"\nbody = '{"code":"DISCOUNT10"}'\ncount = 20\nEOF`,
			cfgFile, target,
		)
		return writeCfg + " && " + fmt.Sprintf(
			`race-the-web -config %s 2>&1 | tee %s`,
			cfgFile, filepath.Join(outDir, scanID8+"_race.txt"),
		)

	default:
		// Fallback: run binary with target
		return fmt.Sprintf("%s %s 2>&1", tool.BinaryPath, target)
	}
}

// ScopeFilter wraps a command with a grep filter to enforce scope boundaries.
// Applied to tools that may discover out-of-scope assets.
func ScopeFilter(cmd string, scope []string) string {
	if len(scope) == 0 {
		return cmd
	}
	// Build grep pattern: "\.example\.com|\.example2\.com"
	patterns := make([]string, len(scope))
	for i, s := range scope {
		// Escape dots, strip wildcard prefix
		s = strings.TrimPrefix(s, "*.")
		s = strings.ReplaceAll(s, ".", `\.`)
		patterns[i] = s
	}
	grepPat := strings.Join(patterns, "|")
	return fmt.Sprintf(`(%s) | grep -E '%s'`, cmd, grepPat)
}
