// Package priority — AI-assisted attack surface prioritisation for BBounty Pro
package priority

import (
	"context"
	"encoding/json"
	"fmt"
	"math"
	"sort"
	"strings"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/ai"
	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/rs/zerolog/log"
)

type Tier string

const (
	TierP1 Tier = "P1"
	TierP2 Tier = "P2"
	TierP3 Tier = "P3"
	TierP4 Tier = "P4"
)

type Target struct {
	URL          string        `json:"url"`
	Host         string        `json:"host"`
	Score        float64       `json:"score"`
	Tier         Tier          `json:"tier"`
	Signals      []Signal      `json:"signals"`
	Tech         []string      `json:"tech"`
	StatusCode   int           `json:"status_code"`
	OpenPorts    []int         `json:"open_ports,omitempty"`
	Title        string        `json:"title,omitempty"`
	ResponseTime time.Duration `json:"response_time_ms"`
	AINote       string        `json:"ai_note,omitempty"`
	ScanOrder    int           `json:"scan_order"`
}

type Signal struct {
	Name        string  `json:"name"`
	Category    string  `json:"category"`
	Score       float64 `json:"score"`
	Description string  `json:"description"`
}

var techScores = map[string]float64{
	"wordpress": 35, "wp-admin": 40, "phpmyadmin": 45,
	"grafana": 40, "jenkins": 45, "gitlab": 35,
	"jira": 35, "confluence": 30, "kibana": 40,
	"elasticsearch": 45, "mongo-express": 50, "adminer": 45,
	"laravel": 30, "spring": 35, "struts": 45,
	"drupal": 35, "joomla": 35, "magento": 40,
	"graphql": 40, "swagger": 35, "api": 25,
	"s3": 40, "kubernetes": 35, "docker": 30,
	"oauth": 30, "saml": 35, "jwt": 30, "keycloak": 40,
	"struts2": 55, "log4j": 60, "weblogic": 55, "jboss": 50,
}

var subdomainScores = map[string]float64{
	"admin": 40, "api": 30, "dev": 35, "staging": 35, "test": 30,
	"internal": 45, "intranet": 40, "vpn": 30, "jenkins": 45,
	"gitlab": 40, "jira": 35, "monitor": 35, "kibana": 40,
	"grafana": 35, "dashboard": 35, "backup": 40, "old": 35,
	"legacy": 35, "upload": 35, "payment": 40,
	"db": 50, "database": 50, "redis": 45, "elastic": 45, "mongo": 45,
}

var statusScores = map[int]float64{
	401: 20, 403: 25, 405: 15, 500: 30,
}

var portScores = map[int]float64{
	2375: 55, 2376: 45,
	6379: 45, 11211: 40,
	9200: 45, 9300: 40,
	27017: 45, 3306: 40, 5432: 40,
	6443: 40, 4848: 40, 9090: 30,
	8080: 15, 8443: 15, 8888: 20,
}

var titleKeywords = map[string]float64{
	"admin": 35, "dashboard": 30, "panel": 30, "management": 25,
	"backend": 30, "internal": 35, "phpinfo": 50, "debug": 40,
	"403": 25, "401": 20, "500": 30, "index of": 45,
}

// Scorer prioritises a list of targets by exploitation potential.
type Scorer struct {
	aiClient *ai.Client
	cache    *cache.Client
}

func NewScorer(aiClient *ai.Client, c *cache.Client) *Scorer {
	return &Scorer{aiClient: aiClient, cache: c}
}

// ScoreTarget computes the priority score for one target in-place.
func (s *Scorer) ScoreTarget(t *Target) {
	var sigs []Signal
	total := 0.0

	// 1. Technology fingerprint (40%)
	bestTech := 0.0
	for _, tech := range t.Tech {
		tl := strings.ToLower(tech)
		for pat, score := range techScores {
			if strings.Contains(tl, pat) && score > bestTech {
				bestTech = score
				sigs = append(sigs, Signal{"Tech: " + tech, "technology", score * 0.4,
					tech + " — known vulnerability surface"})
			}
		}
	}
	total += bestTech * 0.4

	// 2. Subdomain pattern (15%)
	hostLow := strings.ToLower(t.Host)
	bestSub := 0.0
	for pat, score := range subdomainScores {
		if strings.Contains(hostLow, pat) && score > bestSub {
			bestSub = score
			sigs = append(sigs, Signal{"Subdomain: " + pat, "hostname", score * 0.15,
				fmt.Sprintf("'%s' — typically high-value target", pat)})
		}
	}
	total += bestSub * 0.15

	// 3. HTTP status (20%)
	if sc, ok := statusScores[t.StatusCode]; ok {
		total += sc * 0.2
		sigs = append(sigs, Signal{fmt.Sprintf("HTTP %d", t.StatusCode), "response",
			sc * 0.2, statusDesc(t.StatusCode)})
	}

	// 4. Ports (10%)
	bestPort := 0.0
	for _, port := range t.OpenPorts {
		sc := portScores[port]
		if sc == 0 && port > 1024 && port != 80 && port != 443 {
			sc = 10
		}
		if sc > bestPort {
			bestPort = sc
			sigs = append(sigs, Signal{fmt.Sprintf("Port %d", port), "ports",
				sc * 0.1, fmt.Sprintf("Port %d exposed", port)})
		}
	}
	total += bestPort * 0.1

	// 5. Title keywords (10%)
	titLow := strings.ToLower(t.Title)
	bestTitle := 0.0
	for kw, score := range titleKeywords {
		if strings.Contains(titLow, kw) && score > bestTitle {
			bestTitle = score
			sigs = append(sigs, Signal{"Title: " + kw, "content", score * 0.1,
				"Title contains '" + kw + "'"})
		}
	}
	total += bestTitle * 0.1

	// 6. Slow response (5%)
	if t.ResponseTime > 3*time.Second {
		total += 15 * 0.05
		sigs = append(sigs, Signal{"Slow response", "response", 15 * 0.05,
			"Response >3s — possible backend processing"})
	}

	t.Score = math.Min(100, total)
	t.Tier = tierFromScore(t.Score)
	t.Signals = sigs
}

// BatchScore scores all targets, sorts by score, and triggers async AI enrichment.
func (s *Scorer) BatchScore(ctx context.Context, targets []*Target) []*Target {
	for _, t := range targets {
		s.ScoreTarget(t)
	}
	sort.Slice(targets, func(i, j int) bool {
		return targets[i].Score > targets[j].Score
	})
	for i, t := range targets {
		t.ScanOrder = i + 1
	}
	// FIXED: AI enrichment is async — never blocks the scan pipeline goroutines.
	go s.aiEnrichAsync(context.Background(), targets)
	return targets
}

// aiEnrichAsync annotates P1/P2 targets with a one-line Claude assessment.
// Runs entirely in its own goroutine; patches AINote in-place.
func (s *Scorer) aiEnrichAsync(ctx context.Context, targets []*Target) {
	if s.aiClient == nil {
		return
	}
	var top []*Target
	for _, t := range targets {
		if (t.Tier == TierP1 || t.Tier == TierP2) && len(top) < 10 {
			top = append(top, t)
		}
	}
	if len(top) == 0 {
		return
	}

	var sb strings.Builder
	sb.WriteString("Rate each target's bug bounty potential. One line per entry.\n")
	sb.WriteString("Format: [N] VULN_CLASS | SEVERITY | REASON\n\n")
	for i, t := range top {
		fmt.Fprintf(&sb, "%d. %s | Tech: %v | HTTP: %d | Score: %.0f\n",
			i+1, t.URL, t.Tech, t.StatusCode, t.Score)
		for _, sig := range t.Signals {
			fmt.Fprintf(&sb, "   - %s\n", sig.Name)
		}
	}

	resp, err := s.aiClient.Complete(ctx,
		"You are an expert bug bounty hunter. Be concise — one line per target.",
		[]ai.Message{{Role: "user", Content: sb.String()}},
		512,
	)
	if err != nil {
		log.Warn().Err(err).Msg("priority: AI enrichment failed")
		return
	}
	for i, line := range strings.Split(resp, "\n") {
		line = strings.TrimSpace(line)
		if i >= len(top) || line == "" {
			continue
		}
		prefix := fmt.Sprintf("[%d]", i+1)
		if strings.HasPrefix(line, prefix) {
			top[i].AINote = strings.TrimSpace(strings.TrimPrefix(line, prefix))
		}
	}
	log.Info().Int("count", len(top)).Msg("priority: AI enrichment complete")
}

type PrioritisedQueue struct {
	P1 []*Target `json:"p1"`
	P2 []*Target `json:"p2"`
	P3 []*Target `json:"p3"`
	P4 []*Target `json:"p4"`
}

func BuildQueue(scored []*Target) *PrioritisedQueue {
	q := &PrioritisedQueue{}
	for _, t := range scored {
		switch t.Tier {
		case TierP1:
			q.P1 = append(q.P1, t)
		case TierP2:
			q.P2 = append(q.P2, t)
		case TierP3:
			q.P3 = append(q.P3, t)
		default:
			q.P4 = append(q.P4, t)
		}
	}
	return q
}

func (s *Scorer) CacheQueue(ctx context.Context, scanID string, q *PrioritisedQueue) error {
	data, err := json.Marshal(q)
	if err != nil {
		return err
	}
	return s.cache.Raw().Set(ctx, "priority:queue:"+scanID, data, 24*time.Hour).Err()
}

func (s *Scorer) GetQueue(ctx context.Context, scanID string) (*PrioritisedQueue, error) {
	data, err := s.cache.Raw().Get(ctx, "priority:queue:"+scanID).Bytes()
	if err != nil {
		return nil, fmt.Errorf("queue not found for %s", scanID)
	}
	var q PrioritisedQueue
	return &q, json.Unmarshal(data, &q)
}

func tierFromScore(s float64) Tier {
	switch {
	case s >= 80:
		return TierP1
	case s >= 60:
		return TierP2
	case s >= 40:
		return TierP3
	default:
		return TierP4
	}
}

func statusDesc(code int) string {
	m := map[int]string{
		401: "Auth required — test bypass, default creds",
		403: "Forbidden — test 403 bypass techniques",
		405: "Method not allowed — try PUT/PATCH/DELETE",
		500: "Server error — potential injection point",
	}
	if d, ok := m[code]; ok {
		return d
	}
	return fmt.Sprintf("HTTP %d response", code)
}
