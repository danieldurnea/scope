// Package skills — 14 skill modules from BountyHunter-Pro v3.0 ULTRA
// integrated into the BBounty Pro orchestrator.
//
// Each skill is a self-contained methodology with its own tool list,
// system prompt for AI assistance, and output schema. Skills are loaded
// from /apps/skills/<skill-id>/SKILL.md at boot.
//
// Architecture:
//   1. Go orchestrator loads skill registry at startup
//   2. User selects skill via /api/v1/skills endpoint
//   3. Orchestrator routes execution: Go-native tools run inline,
//      complex Python skills shell out to apps/agents/specialist_agents/
//   4. Output streamed back via WebSocket to frontend

package skills

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"github.com/go-chi/chi/v5"
	"github.com/rs/zerolog/log"
)

// ── Skill model ───────────────────────────────────────────────────────────────

type Skill struct {
	ID           string         `json:"id"`
	Name         string         `json:"name"`
	Description  string         `json:"description"`
	Category     string         `json:"category"`
	Methodology  string         `json:"methodology"`     // OWASP, PTES, MITRE ATT&CK
	Tools        []string       `json:"tools"`            // tool IDs from registry
	SystemPrompt string         `json:"system_prompt"`    // injected into Claude
	OutputSchema string         `json:"output_schema"`    // expected JSON shape
	Runtime      SkillRuntime   `json:"runtime"`
	Version      string         `json:"version"`
}

type SkillRuntime string

const (
	RuntimeGo     SkillRuntime = "go"     // executed by orchestrator inline
	RuntimePython SkillRuntime = "python" // shelled out to specialist_agents
	RuntimeMixed  SkillRuntime = "mixed"  // both
)

// ── Registry ──────────────────────────────────────────────────────────────────

type Registry struct {
	mu     sync.RWMutex
	skills map[string]*Skill
	root   string // path to /apps/skills/
}

func NewRegistry(skillsRoot string) *Registry {
	r := &Registry{
		skills: make(map[string]*Skill),
		root:   skillsRoot,
	}
	r.loadBuiltins()
	return r
}

// loadBuiltins registers the 14 skill modules from BountyHunter-Pro v3.0 ULTRA
func (r *Registry) loadBuiltins() {
	builtins := []*Skill{
		{
			ID: "api-security", Name: "API Security Testing", Category: "web",
			Description:  "REST, GraphQL, WebSocket, SOAP API auditing with OWASP API Top 10",
			Methodology:  "OWASP API Security Top 10",
			Tools:        []string{"graphw00f", "graphql-cop", "kiterunner", "arjun"},
			Runtime:      RuntimeGo,
			Version:      "1.0",
			SystemPrompt: skillPromptAPI,
			OutputSchema: `{"endpoints": [], "auth_issues": [], "graphql": {}, "rate_limits": {}}`,
		},
		{
			ID: "bug-bounty", Name: "Bug Bounty Hunting", Category: "offensive",
			Description:  "HackerOne-optimised vulnerability finding with platform-specific filters",
			Methodology:  "OWASP Top 10 + WAHH",
			Tools:        []string{"subfinder", "httpx", "nuclei", "dalfox", "ffuf"},
			Runtime:      RuntimeGo,
			Version:      "1.0",
			SystemPrompt: skillPromptBugBounty,
			OutputSchema: `{"findings": [], "scope": {}, "platform": ""}`,
		},
		{
			ID: "cloud-security", Name: "Cloud Security", Category: "infrastructure",
			Description:  "AWS, GCP, Azure, Kubernetes security assessment",
			Methodology:  "CIS Benchmarks + Cloud Security Alliance",
			Tools:        []string{"prowler", "scout-suite", "kube-bench", "trivy"},
			Runtime:      RuntimePython,
			Version:      "1.0",
			SystemPrompt: skillPromptCloud,
			OutputSchema: `{"misconfigurations": [], "exposed_resources": []}`,
		},
		{
			ID: "devops-security", Name: "DevOps Security", Category: "infrastructure",
			Description:  "Docker, Kubernetes, CI/CD pipeline security",
			Methodology:  "DevSecOps + Supply Chain Security",
			Tools:        []string{"trivy", "hadolint", "checkov", "kubesec"},
			Runtime:      RuntimeMixed,
			Version:      "1.0",
			SystemPrompt: skillPromptDevOps,
			OutputSchema: `{"image_vulns": [], "iac_issues": [], "secrets": []}`,
		},
		{
			ID: "exploit-dev", Name: "Exploit Development", Category: "offensive",
			Description:  "Educational PoC generation — no weaponised exploits",
			Methodology:  "MITRE ATT&CK + CVE analysis",
			Tools:        []string{"searchsploit", "msfconsole-helper"},
			Runtime:      RuntimeGo,
			Version:      "1.0",
			SystemPrompt: skillPromptExploit,
			OutputSchema: `{"pocs": [], "cve_chain": []}`,
		},
		{
			ID: "iot-security", Name: "IoT Security", Category: "specialised",
			Description:  "Firmware analysis, protocol fuzzing, hardware interfaces",
			Methodology:  "OWASP IoT Top 10",
			Tools:        []string{"binwalk", "firmwalker", "mqtt-explorer"},
			Runtime:      RuntimePython,
			Version:      "1.0",
			SystemPrompt: skillPromptIoT,
			OutputSchema: `{"firmware_issues": [], "protocol_findings": []}`,
		},
		{
			ID: "malware-analysis", Name: "Malware Analysis", Category: "defensive",
			Description:  "Static + dynamic analysis, IOC extraction",
			Methodology:  "MITRE ATT&CK + Threat Intelligence",
			Tools:        []string{"yara", "capa", "die", "strings-analyzer"},
			Runtime:      RuntimePython,
			Version:      "1.0",
			SystemPrompt: skillPromptMalware,
			OutputSchema: `{"iocs": [], "ttps": [], "family": ""}`,
		},
		{
			ID: "mobile-security", Name: "Mobile Security", Category: "specialised",
			Description:  "APK + iOS app analysis, MASVS coverage",
			Methodology:  "OWASP MASVS",
			Tools:        []string{"mobsf", "apkleaks", "frida", "objection"},
			Runtime:      RuntimePython,
			Version:      "1.0",
			SystemPrompt: skillPromptMobile,
			OutputSchema: `{"manifest_issues": [], "secrets": [], "permissions": []}`,
		},
		{
			ID: "network-security", Name: "Network Security", Category: "infrastructure",
			Description:  "Port scanning, protocol analysis, network segmentation review",
			Methodology:  "PTES + Network Pentesting",
			Tools:        []string{"naabu", "nmap", "masscan", "tcpdump-helper"},
			Runtime:      RuntimeGo,
			Version:      "1.0",
			SystemPrompt: skillPromptNetwork,
			OutputSchema: `{"open_ports": [], "services": [], "vulns": []}`,
		},
		{
			ID: "osint", Name: "OSINT Gathering", Category: "recon",
			Description:  "Passive open source intelligence gathering",
			Methodology:  "OSINT Framework + STORM",
			Tools:        []string{"theharvester", "spiderfoot", "shodan-cli", "subfinder"},
			Runtime:      RuntimeMixed,
			Version:      "1.0",
			SystemPrompt: skillPromptOSINT,
			OutputSchema: `{"emails": [], "subdomains": [], "metadata": [], "leaks": []}`,
		},
		{
			ID: "red-team", Name: "Red Team Operations", Category: "offensive",
			Description:  "MITRE ATT&CK simulation, lateral movement, persistence (lab only)",
			Methodology:  "MITRE ATT&CK + Lockheed Martin Kill Chain",
			Tools:        []string{"caldera-helper", "mitre-mapper"},
			Runtime:      RuntimePython,
			Version:      "1.0",
			SystemPrompt: skillPromptRedTeam,
			OutputSchema: `{"tactics": [], "techniques": [], "procedures": []}`,
		},
		{
			ID: "report-writing", Name: "Report Writing", Category: "reporting",
			Description:  "Professional bug bounty + pentest report generation",
			Methodology:  "Industry standard with CVSS 3.1 + CWE references",
			Tools:        []string{"cvss-calculator", "report-template"},
			Runtime:      RuntimeGo,
			Version:      "1.0",
			SystemPrompt: skillPromptReporting,
			OutputSchema: `{"executive_summary": "", "findings": [], "recommendations": []}`,
		},
		{
			ID: "social-engineering", Name: "Social Engineering Test", Category: "offensive",
			Description:  "Phishing simulation, OSINT for SE — authorised tests only",
			Methodology:  "SET + GoPhish methodology",
			Tools:        []string{"theharvester", "gophish-helper"},
			Runtime:      RuntimePython,
			Version:      "1.0",
			SystemPrompt: skillPromptSocEng,
			OutputSchema: `{"targets": [], "vectors": [], "success_rate": 0}`,
		},
		{
			ID: "web-audit", Name: "Web Application Audit", Category: "web",
			Description:  "Comprehensive web app security audit (OWASP Top 10 + WSTG)",
			Methodology:  "OWASP Web Security Testing Guide",
			Tools:        []string{"nuclei", "dalfox", "sqlmap", "nikto", "wpscan"},
			Runtime:      RuntimeGo,
			Version:      "1.0",
			SystemPrompt: skillPromptWebAudit,
			OutputSchema: `{"vulnerabilities": [], "owasp_coverage": {}}`,
		},
	}
	for _, s := range builtins {
		r.skills[s.ID] = s
	}
	log.Info().Int("count", len(builtins)).Msg("skills: built-in skills loaded")
}

// LoadFromDisk reads SKILL.md files for each skill (overrides builtins if present).
func (r *Registry) LoadFromDisk() error {
	r.mu.Lock()
	defer r.mu.Unlock()

	for id, skill := range r.skills {
		mdPath := filepath.Join(r.root, id, "SKILL.md")
		data, err := os.ReadFile(mdPath)
		if err != nil {
			continue // skill has no override file — use builtin
		}
		// Append disk-loaded content to system prompt as supplementary context
		skill.SystemPrompt += "\n\n--- LOADED FROM SKILL.md ---\n" + string(data)
	}
	return nil
}

// List returns all registered skills.
func (r *Registry) List() []*Skill {
	r.mu.RLock()
	defer r.mu.RUnlock()
	out := make([]*Skill, 0, len(r.skills))
	for _, s := range r.skills {
		out = append(out, s)
	}
	return out
}

// Get returns a skill by ID.
func (r *Registry) Get(id string) (*Skill, error) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	s, ok := r.skills[id]
	if !ok {
		return nil, fmt.Errorf("skill %q not found", id)
	}
	return s, nil
}

// ── Python Bridge — execute Python-runtime skills ────────────────────────────

type PythonRunner struct {
	pythonBin   string // path to python3
	agentScript string // path to specialist agent script
}

func NewPythonRunner() *PythonRunner {
	pyBin := os.Getenv("PYTHON_BIN")
	if pyBin == "" {
		pyBin = "/usr/bin/python3"
	}
	scriptPath := os.Getenv("AGENT_SCRIPT")
	if scriptPath == "" {
		scriptPath = "/opt/bbounty-pro/apps/agents/specialist_agents/agent.py"
	}
	return &PythonRunner{pythonBin: pyBin, agentScript: scriptPath}
}

// Run executes a skill via Python agent and returns stdout.
func (p *PythonRunner) Run(ctx context.Context, skill *Skill, target string, scanID string) ([]byte, error) {
	if _, err := os.Stat(p.agentScript); err != nil {
		return nil, fmt.Errorf("python agent script not found: %s", p.agentScript)
	}

	args := []string{
		p.agentScript,
		"--skill", skill.ID,
		"--target", target,
		"--scan-id", scanID,
		"--output-format", "json",
	}

	rctx, cancel := context.WithTimeout(ctx, 30*time.Minute)
	defer cancel()

	cmd := exec.CommandContext(rctx, p.pythonBin, args...)
	cmd.Env = append(os.Environ(),
		"PYTHONUNBUFFERED=1",
		"AGENT_MODE=skill",
	)

	out, err := cmd.Output()
	if err != nil {
		if exitErr, ok := err.(*exec.ExitError); ok {
			return out, fmt.Errorf("python agent failed: %w (stderr: %s)", err, string(exitErr.Stderr))
		}
		return out, fmt.Errorf("python agent failed: %w", err)
	}
	return out, nil
}

// ── HTTP Handlers ─────────────────────────────────────────────────────────────

func (r *Registry) HandleList(w http.ResponseWriter, _ *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(r.List())
}

func (r *Registry) HandleGet(w http.ResponseWriter, req *http.Request) {
	id := chi.URLParam(req, "skillID")
	s, err := r.Get(id)
	if err != nil {
		http.Error(w, fmt.Sprintf(`{"error":%q}`, err.Error()), http.StatusNotFound)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(s)
}

// HandleExecute runs a skill against a target.
func (r *Registry) HandleExecute(runner *PythonRunner) http.HandlerFunc {
	return func(w http.ResponseWriter, req *http.Request) {
		skillID := chi.URLParam(req, "skillID")
		var body struct {
			Target string `json:"target"`
			ScanID string `json:"scan_id"`
		}
		if err := json.NewDecoder(req.Body).Decode(&body); err != nil {
			http.Error(w, `{"error":"invalid body"}`, http.StatusBadRequest)
			return
		}

		skill, err := r.Get(skillID)
		if err != nil {
			http.Error(w, fmt.Sprintf(`{"error":%q}`, err.Error()), http.StatusNotFound)
			return
		}

		// Skip Python execution if runner is unavailable for Go skills
		if skill.Runtime == RuntimeGo {
			w.Header().Set("Content-Type", "application/json")
			json.NewEncoder(w).Encode(map[string]any{
				"skill":   skill.ID,
				"runtime": "go",
				"status":  "queued — handled by Go pipeline",
			})
			return
		}

		// Async Python execution
		go func() {
			ctx, cancel := context.WithTimeout(context.Background(), 30*time.Minute)
			defer cancel()
			out, err := runner.Run(ctx, skill, body.Target, body.ScanID)
			if err != nil {
				log.Error().Err(err).Str("skill", skillID).Msg("skill execution failed")
				return
			}
			log.Info().Str("skill", skillID).Int("output_size", len(out)).Msg("skill complete")
		}()

		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusAccepted)
		json.NewEncoder(w).Encode(map[string]any{
			"skill":   skill.ID,
			"runtime": skill.Runtime,
			"status":  "running",
		})
	}
}

// ── Skill prompts (operational, security-aware, redacted PoC by default) ─────

const skillPromptAPI = `You are conducting an OWASP API Security Top 10 audit.
Focus on: BOLA, broken auth, excessive data exposure, lack of rate limiting,
BFLA, mass assignment, security misconfiguration, injection, asset management,
insufficient logging.
For GraphQL: introspection, batching, depth/complexity limits.
Output structured findings with CVSS 3.1 vectors. PoCs minimal, redact sensitive.`

const skillPromptBugBounty = `You are an elite HackerOne bug bounty hunter.
Optimise for: high signal-to-noise, platform-specific filters (no N/A patterns),
duplicate avoidance via disclosed reports, severity calibrated by program context.
Severity = Exploitability × Impact × Context. Don't over-rate by class.`

const skillPromptCloud = `Cloud security assessment using CIS Benchmarks.
Focus on: IAM misconfigurations, public storage, network exposure,
key management, logging gaps, compliance drift.
Map findings to CIS controls and provider security best practices.`

const skillPromptDevOps = `DevSecOps audit covering CI/CD, containers, IaC, supply chain.
Focus on: secrets in repos, vulnerable base images, IaC misconfigurations,
unsigned commits, missing SBOMs, dependency vulnerabilities.`

const skillPromptExploit = `Educational exploit development for AUTHORISED testing only.
Generate PoC at minimal demonstration level.
Never produce: weaponised shellcode, ROP chains, AV/EDR evasion, ransomware,
malware loaders, C2 implants. Educational alert(1) / curl-level only.`

const skillPromptIoT = `IoT security assessment per OWASP IoT Top 10.
Focus on: weak credentials, insecure network services, ecosystem interfaces,
secure update mechanism, insecure components, insufficient privacy protection,
insecure data transfer/storage, lack of device management, insecure default settings,
lack of physical hardening.`

const skillPromptMalware = `Defensive malware analysis for IR / threat intel.
Static + dynamic analysis. Extract IOCs (hashes, IPs, domains, mutexes).
Map TTPs to MITRE ATT&CK. Identify family. Never provide deobfuscation
that aids weaponisation — focus on detection signatures.`

const skillPromptMobile = `Mobile security per OWASP MASVS.
Focus on: data storage, cryptography, authentication, network communication,
platform interaction, code quality, resilience.
Never bypass DRM or app integrity controls without explicit authorisation.`

const skillPromptNetwork = `Network security assessment per PTES.
Port scanning with rate limiting. Service enumeration. Protocol analysis.
Network segmentation review. Never scan unauthorised IP ranges.`

const skillPromptOSINT = `Passive OSINT gathering. No active touching of target infrastructure.
Sources: certificate transparency, public DNS, WHOIS, search engines, leaked
credential databases (HIBP), social media (subject to ToS).
Never harvest PII for unauthorised purposes.`

const skillPromptRedTeam = `Red team simulation per MITRE ATT&CK — LAB ENVIRONMENTS ONLY.
TTPs mapped to ATT&CK matrix. Kill chain progression.
Never execute against production unless explicit ROE allows.
Never generate persistence mechanisms outside lab scope.`

const skillPromptReporting = `Professional bug bounty / pentest report writer.
Format: title with [CWE-XXX], CVSS 3.1 vector, asset URL, summary, repro steps,
PoC (minimal), impact (concrete), remediation (specific to stack), references.
Never include sensitive data extracted from victim systems.`

const skillPromptSocEng = `Authorised social engineering simulation only.
Phishing campaign design with proper rules of engagement. Track success metrics.
Never harvest real credentials. Never target individuals outside scope.
All emails marked as simulation per platform requirements.`

const skillPromptWebAudit = `Web application audit per OWASP WSTG.
Cover all OWASP Top 10 categories. Manual + tool-assisted testing.
Confirm every tool finding manually before reporting.
Severity per real impact, not vuln class.`
