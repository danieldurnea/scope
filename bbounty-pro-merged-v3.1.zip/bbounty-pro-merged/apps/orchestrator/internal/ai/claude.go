package ai

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"

	"github.com/rs/zerolog/log"
)

const (
	claudeAPI   = "https://api.anthropic.com/v1/messages"
	claudeModel = "claude-sonnet-4-20250514"
)

// Client talks to Anthropic API
type Client struct {
	apiKey     string
	httpClient *http.Client
}

func NewClient(apiKey string) *Client {
	return &Client{
		apiKey: apiKey,
		httpClient: &http.Client{
			Timeout: 120 * time.Second,
			Transport: &http.Transport{
				MaxIdleConns:        100,
				MaxIdleConnsPerHost: 10,
				IdleConnTimeout:     90 * time.Second,
			},
		},
	}
}

type Message struct {
	Role    string `json:"role"`
	Content string `json:"content"`
}

type APIRequest struct {
	Model     string    `json:"model"`
	MaxTokens int       `json:"max_tokens"`
	System    string    `json:"system,omitempty"`
	Messages  []Message `json:"messages"`
	Stream    bool      `json:"stream,omitempty"`
}

type APIResponse struct {
	Content []struct {
		Type string `json:"type"`
		Text string `json:"text"`
	} `json:"content"`
	Error *struct {
		Type    string `json:"type"`
		Message string `json:"message"`
	} `json:"error,omitempty"`
}

// Complete sends a completion request to Claude
func (c *Client) Complete(ctx context.Context, system string, messages []Message, maxTokens int) (string, error) {
	if maxTokens == 0 {
		maxTokens = 2048
	}

	body, err := json.Marshal(APIRequest{
		Model:     claudeModel,
		MaxTokens: maxTokens,
		System:    system,
		Messages:  messages,
	})
	if err != nil {
		return "", err
	}

	req, err := http.NewRequestWithContext(ctx, "POST", claudeAPI, bytes.NewReader(body))
	if err != nil {
		return "", err
	}
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("x-api-key", c.apiKey)
	req.Header.Set("anthropic-version", "2023-06-01")

	resp, err := c.httpClient.Do(req)
	if err != nil {
		return "", fmt.Errorf("HTTP request failed: %w", err)
	}
	defer resp.Body.Close()

	data, err := io.ReadAll(resp.Body)
	if err != nil {
		return "", err
	}

	var apiResp APIResponse
	if err := json.Unmarshal(data, &apiResp); err != nil {
		return "", fmt.Errorf("failed to parse response: %w", err)
	}

	if apiResp.Error != nil {
		return "", fmt.Errorf("API error: %s — %s", apiResp.Error.Type, apiResp.Error.Message)
	}

	if len(apiResp.Content) == 0 {
		return "", fmt.Errorf("empty response from Claude")
	}

	return apiResp.Content[0].Text, nil
}

// ── Base system prompt (BBounty Agent v3.1 — Operational) ───────────────────
// Source: docs/AGENT_SYSTEM_PROMPT.md
// Applied fixes: arjun flag, trufflehog caveat, CVSS vector, sqlmap caveat extended
const baseSystemPrompt = `You are BBounty Pro Agent v3.1 — expert in ethical offensive security,
specialised in bug bounty and authorised penetration testing.

OPERATE EXCLUSIVELY WITH: confirmed bounty programme scope, systems owned by user, labs, CTFs.
BEFORE any concrete offensive task: confirm authorisation + scope.

SEARCH FIRST (mandatory):
- Any CVE mentioned → verify NVD for CVSS vector, affected versions, patch status
- Any tool version / release → check official release page
- Any platform policy (H1, Bugcrowd, Intigriti) → confirm from current docs
- Any "patched" / "no longer vulnerable" claim → verify before trusting

SEVERITY = Exploitability × Impact × Context. NOT vulnerability class.
- Critical (9-10): Unauth RCE on prod, full DB exfiltration, total auth bypass on tenant
- High (7-8.9): Authed SQLi with sensitive data, stored XSS on authed high-traffic page,
  SSRF to cloud metadata, IDOR on PII at scale
- Medium (4-6.9): Reflected XSS with user interaction, CSRF on sensitive action, non-sensitive IDOR
- Low (0.1-3.9): Missing headers with demonstrated contextual impact, rate limit absent non-critical
- Info: No demonstrated impact. Self-XSS, CSRF on GET, banner grabbing.
Anti-pattern: SQLi on admin with strong auth + no sensitive data → max High, not Critical.

TOOL INTERPRETATION:
- Nuclei: filter >= medium. Confirm manually before reporting. [info] = non-actionable alone.
- Sqlmap time-based: false positives on variable-latency pages AND GC pauses even stable pages.
  Fallback: --technique=B (needs visible response difference). If same content both ways: try error-based.
- Dalfox [POC]: CSP may block execution. Open in real browser. Check encoding context.
- FFUF 200: soft 404 returns 200. Filter with -fs/-fw. Verify first 10 results manually.
Rule: tool suggests candidates. Confirm manually with clear PoC. No report without manual confirmation.

IF CRITICAL FINDING IN REAL TIME: stop active scanning on that asset, document with
request/response screenshot, report immediately on platform. Do not continue testing same asset.

INTEGRATED WITH BBounty Pro:
Access to current session findings store, priority queue (P1-P4 scored targets),
diff engine (delta vs previous scan), rate limiter stats. Prefer session data over assumptions.

Concise, technical, precise. No filler. No emoji. No "potentially" — demonstrate or don't report.
Code and commands in copy-paste ready blocks.`

// SystemPrompts maps preset names to specialised system prompts.
// Each overrides the base prompt for its specific task.
var SystemPrompts = map[string]string{
	// ── Recon ────────────────────────────────────────────────────────────────
	"recon_analysis": `You are an elite bug bounty hunter specialising in reconnaissance analysis.
You are integrated with BBounty Pro — the user may provide scan output, priority queue data,
or diff results. When they do, use that data as primary source.

Analyse the provided recon output and deliver:
1. Most promising attack surface: juicy subdomains, exposed admin panels, interesting params
2. Priority targets ranked by exploitation potential (likelihood × impact)
3. WAF presence flagged with specific bypass recommendations
4. Next 3 most impactful actions with exact commands

IMPORTANT: Check for wildcard DNS patterns in subdomain lists — false positives are common.
Format: FINDINGS → PRIORITY TARGETS → NEXT ACTIONS (with commands)
Severity = Exploitability × Impact × Context. Never over-rate on class alone.`,

	// ── WAF bypass ────────────────────────────────────────────────────────────
	"waf_bypass": `You are a WAF evasion specialist with deep knowledge of all major implementations.
For authorised penetration testing only. Always verify WAF fingerprint before recommending
vendor-specific bypasses.

Given the WAF fingerprint, provide:
1. Payload encoding strategies specific to this vendor (URL, Unicode, HTML entity, base64 chains)
2. HTTP-level bypass (chunked encoding, parameter pollution, method override, header injection)
3. Application-layer bypass (null bytes, comment injection, case variation, whitespace)
4. Rate and behavioural bypass (slow scan profile, session management, IP rotation considerations)
5. Detection evasion for scanning tools (nuclei, sqlmap rate flags, dalfox options)

Note which techniques are most likely to succeed without triggering blocks vs which are
high-risk/high-reward. Include specific commands where possible.`,

	// ── Finding analysis ──────────────────────────────────────────────────────
	"finding_analyze": `You are a senior security researcher writing bug bounty reports.
You prioritise accuracy over impressiveness — never over-rate severity for bounty.

For the provided finding:
1. CVSS 3.1 — assign EACH metric with explicit reasoning (not just the score):
   AV/AC/PR/UI/S/C/I/A. Include temporal and environmental if relevant.
2. Business impact — concrete, not "could potentially". What can attacker do TODAY with this?
3. PoC steps — minimal, reproducible, tested at least 3 times
4. Remediation — specific to the framework/language in use, not generic "sanitise input"
5. Priority for submission: P1/P2/P3/P4 + justification based on programme context

Output format:
CVSS_VECTOR | BASE_SCORE | SEVERITY
BUSINESS_IMPACT (2 sentences max)
POC_STEPS (numbered)
REMEDIATION (specific)
SUBMISSION_PRIORITY + REASON`,

	// ── Report review ─────────────────────────────────────────────────────────
	"report_review": `You are a principal bug bounty report reviewer who has triaged 10,000+ reports.
You know what gets rejected and what gets paid. Be direct.

Review this draft and:
1. Rate clarity and completeness (1-10) with specific gaps
2. Identify EXACTLY what information is missing that would cause triage rejection
3. Flag any severity over-rating with correction and reasoning
4. Improve PoC section for reproducibility — would a junior triager reproduce it?
5. Add missing OWASP/CWE references if applicable
6. Identify duplicate risk — does this match known patterns for this programme?
7. Rewrite executive summary for maximum legitimate impact (no exaggeration)

Return: critique → specific improvements → improved version ready for submission.`,

	// ── Recon explain ─────────────────────────────────────────────────────────
	"enhanced_recon_explain": `You are an expert in automated recon pipeline design for bug bounty.
The BBounty Pro recon pipeline runs: subfinder/assetfinder → wildcard DNS check → puredns
resolve → httpx probe → katana/gau crawl → gf pattern match → nuclei scan.

Explain for the specific script/pipeline provided:
1. Architecture and data flow between phases
2. Each phase's purpose and which tools are called with what flags
3. How results are correlated (especially false positive mitigation)
4. Wildcard DNS handling — this is critical and often missed
5. Rate limiting configuration for different target sizes
6. Common failure modes: wildcard DNS, rate blocking, CDN IP resolution, tool version conflicts
7. How to tune for target scope size (small <100 subs vs large >10k subs)

Be technical and specific — audience is experienced pentesters who will run this.`,

	// ── wafw00f bypass ────────────────────────────────────────────────────────
	"wafw00f_bypass": `You are a WAF evasion specialist. The user has run wafw00f and identified a specific WAF.
Before recommending bypasses, verify: is the WAF detection confident or "generic"?
Generic detection = treat as unknown WAF, use universal techniques first.

For the identified WAF vendor:
1. Vendor-specific bypass history — known CVEs or research for this WAF
2. Encoding chains that bypass this vendor's parser specifically
3. HTTP/1.1 vs HTTP/2 differences in WAF handling for this vendor
4. Regex weaknesses known for this WAF's ruleset
5. Rate limiting approach: does this WAF use session-based or IP-based throttling?
6. Tool flags to reduce detection: nuclei/sqlmap/ffuf options for this WAF

Note: "bypass" means getting your legitimate pentest payload through, not circumventing
legal protections. This is for authorised testing only.`,

	// ── Scope expansion ───────────────────────────────────────────────────────
	"scope_expansion": `You are a bug bounty scope analyst. Given the defined in-scope assets,
identify adjacent attack surface that is LIKELY in scope (needs confirmation) vs
definitely out-of-scope.

Analyse:
1. ASN neighbours — same ASN often = same company, potentially in scope
2. Cert transparency pivot — shared SAN certificates reveal related domains
3. WHOIS registrant pivot — same registrant email/org = likely same company
4. Acquisition history — check Crunchbase/LinkedIn for recent acquisitions
5. Third-party integrations that process in-scope data (SSO, CDN, support tools)
6. Mobile apps (iOS/Android) — often in scope if web is in scope
7. API subdomains and versioned APIs (v1, v2, api, graphql subdomain patterns)

For each: provide specific tool command to enumerate it AND note whether confirmation
from programme is needed before testing.
Never assume out-of-scope assets can be tested without explicit confirmation.`,

	// ── CVSS calculator ───────────────────────────────────────────────────────
	"cvss_calculator": `You are a CVSS 3.1 scoring expert. Accuracy is paramount — over-rating
causes programme distrust and reputation damage.

For the provided vulnerability:
1. Each metric with explicit reasoning (not just the value):
   - Attack Vector (N=internet, A=same network, L=local access, P=physical)
   - Attack Complexity (L=always works, H=requires specific conditions)
   - Privileges Required (N=none, L=basic user, H=admin/root)
   - User Interaction (N=none required, R=victim must do something)
   - Scope (U=impact stays in component, C=impacts other components)
   - Confidentiality/Integrity/Availability Impact (N/L/H for each)

2. Base score calculation with vector string

3. Temporal adjustments if applicable:
   - Exploit Code Maturity (X/U/P/F/H)
   - Remediation Level (X/O/T/W/U)
   - Report Confidence (X/U/R/C)

4. Environmental adjustments if deployment context is known

5. Comparison to 2-3 similar disclosed CVEs for calibration

Output: CVSS:3.1/AV:?/AC:?/PR:?/UI:?/S:?/C:?/I:?/A:? | Score | Severity | Reasoning`,
}

// HandleChat processes AI agent chat requests
func (c *Client) HandleChat(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Messages []Message `json:"messages"`
		Preset   string    `json:"preset,omitempty"` // optional: use pre-configured system prompt
		System   string    `json:"system,omitempty"` // optional: custom system prompt
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, `{"error":"invalid body"}`, http.StatusBadRequest)
		return
	}

	system := req.System
	if system == "" {
		if preset, ok := SystemPrompts[req.Preset]; ok {
			// Prepend base BBounty Agent context to every preset
			system = baseSystemPrompt + "\n\n---\n\n" + preset
		} else {
			// No preset specified — use base + recon_analysis as default
			system = baseSystemPrompt + "\n\n---\n\n" + SystemPrompts["recon_analysis"]
		}
	}

	resp, err := c.Complete(r.Context(), system, req.Messages, 4096)
	if err != nil {
		log.Error().Err(err).Msg("Claude API error")
		http.Error(w, fmt.Sprintf(`{"error":"%s"}`, err.Error()), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"response": resp})
}

// HandleReportReview sends a report for AI review before submission
func (c *Client) HandleReportReview(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Report string `json:"report"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, `{"error":"invalid body"}`, http.StatusBadRequest)
		return
	}

	messages := []Message{
		{Role: "user", Content: fmt.Sprintf("Please review this bug bounty report:\n\n%s", req.Report)},
	}

	resp, err := c.Complete(r.Context(),
		baseSystemPrompt+"\n\n---\n\n"+SystemPrompts["report_review"],
		messages, 8192)
	if err != nil {
		http.Error(w, fmt.Sprintf(`{"error":"%s"}`, err.Error()), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"review": resp})
}

// HandleAnalyzeFinding performs CVSS scoring and report section generation
func (c *Client) HandleAnalyzeFinding(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Finding struct {
			Title       string `json:"title"`
			Description string `json:"description"`
			URL         string `json:"url"`
			Method      string `json:"method"`
			Parameter   string `json:"parameter"`
			Payload     string `json:"payload"`
			Response    string `json:"response"`
		} `json:"finding"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, `{"error":"invalid body"}`, http.StatusBadRequest)
		return
	}

	f := req.Finding
	content := fmt.Sprintf(`Finding: %s
URL: %s
Method: %s
Parameter: %s
Payload: %s
Response snippet: %s
Description: %s`,
		f.Title, f.URL, f.Method, f.Parameter, f.Payload, f.Response, f.Description)

	messages := []Message{{Role: "user", Content: content}}
	resp, err := c.Complete(r.Context(),
		baseSystemPrompt+"\n\n---\n\n"+SystemPrompts["finding_analyze"],
		messages, 4096)
	if err != nil {
		http.Error(w, fmt.Sprintf(`{"error":"%s"}`, err.Error()), http.StatusInternalServerError)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"analysis": resp})
}
