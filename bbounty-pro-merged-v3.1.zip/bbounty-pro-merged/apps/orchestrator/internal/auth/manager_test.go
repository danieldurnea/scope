package auth_test

import (
	"context"
	"testing"

	"github.com/bbounty-pro/orchestrator/internal/auth"
	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/alicebob/miniredis/v2"
	"github.com/redis/go-redis/v9"
)

// newTestManager creates an auth.Manager backed by miniredis for fast unit tests.
func newTestManager(t *testing.T) (*auth.Manager, func()) {
	t.Helper()
	mr, err := miniredis.Run()
	if err != nil {
		t.Fatalf("miniredis: %v", err)
	}
	rdb := redis.NewClient(&redis.Options{Addr: mr.Addr()})
	c := cache.NewFromClient(rdb)
	mgr := auth.NewManager(c, "test-jwt-secret-32-bytes-long!!")
	return mgr, func() {
		rdb.Close()
		mr.Close()
	}
}

func TestRegister_FirstUserIsAdmin(t *testing.T) {
	mgr, cleanup := newTestManager(t)
	defer cleanup()

	pair, err := mgr.Register(context.Background(), auth.RegisterRequest{
		Username: "alice",
		Email:    "alice@example.com",
		Password: "password123",
	})
	if err != nil {
		t.Fatalf("Register: %v", err)
	}
	if pair.User.Role != auth.RoleAdmin {
		t.Errorf("first user role = %q, want admin", pair.User.Role)
	}
	if pair.AccessToken == "" {
		t.Error("access token empty")
	}
	if pair.RefreshToken == "" {
		t.Error("refresh token empty")
	}
}

func TestRegister_SecondUserNeedsInvite(t *testing.T) {
	mgr, cleanup := newTestManager(t)
	defer cleanup()

	// Register first user (admin)
	_, err := mgr.Register(context.Background(), auth.RegisterRequest{
		Username: "admin", Email: "admin@example.com", Password: "password123",
	})
	if err != nil {
		t.Fatalf("first register: %v", err)
	}

	// Second user without invite should fail
	_, err = mgr.Register(context.Background(), auth.RegisterRequest{
		Username: "bob", Email: "bob@example.com", Password: "password123",
	})
	if err == nil {
		t.Error("expected error for second user without invite")
	}
}

func TestRegister_WithInviteCode(t *testing.T) {
	mgr, cleanup := newTestManager(t)
	defer cleanup()
	ctx := context.Background()

	// Admin registers
	adminPair, _ := mgr.Register(ctx, auth.RegisterRequest{
		Username: "admin", Email: "admin@example.com", Password: "password123",
	})

	// Admin generates invite
	// We need admin claims — verify token first
	claims, err := mgr.VerifyAccessToken(adminPair.AccessToken)
	if err != nil {
		t.Fatalf("verify: %v", err)
	}
	code, err := mgr.GenerateInvite(ctx, claims.UserID, auth.RoleHunter)
	if err != nil {
		t.Fatalf("invite: %v", err)
	}

	// Hunter registers with invite
	pair, err := mgr.Register(ctx, auth.RegisterRequest{
		Username: "hunter", Email: "hunter@example.com",
		Password: "password123", InviteCode: code,
	})
	if err != nil {
		t.Fatalf("Register with invite: %v", err)
	}
	if pair.User.Role != auth.RoleHunter {
		t.Errorf("role = %q, want hunter", pair.User.Role)
	}

	// Invite should be burned (single-use)
	_, err = mgr.Register(ctx, auth.RegisterRequest{
		Username: "intruder", Email: "x@x.com",
		Password: "password123", InviteCode: code,
	})
	if err == nil {
		t.Error("invite should be single-use")
	}
}

func TestLogin_CorrectCredentials(t *testing.T) {
	mgr, cleanup := newTestManager(t)
	defer cleanup()
	ctx := context.Background()

	mgr.Register(ctx, auth.RegisterRequest{
		Username: "alice", Email: "a@a.com", Password: "mypassword",
	})

	pair, err := mgr.Login(ctx, auth.LoginRequest{Username: "alice", Password: "mypassword"})
	if err != nil {
		t.Fatalf("Login: %v", err)
	}
	if pair.User.Username != "alice" {
		t.Errorf("username = %q", pair.User.Username)
	}
}

func TestLogin_WrongPassword(t *testing.T) {
	mgr, cleanup := newTestManager(t)
	defer cleanup()
	ctx := context.Background()

	mgr.Register(ctx, auth.RegisterRequest{
		Username: "alice", Email: "a@a.com", Password: "correct",
	})

	_, err := mgr.Login(ctx, auth.LoginRequest{Username: "alice", Password: "wrong"})
	if err == nil {
		t.Error("expected error for wrong password")
	}
}

func TestRefreshToken_RotatesCorrectly(t *testing.T) {
	mgr, cleanup := newTestManager(t)
	defer cleanup()
	ctx := context.Background()

	pair, _ := mgr.Register(ctx, auth.RegisterRequest{
		Username: "alice", Email: "a@a.com", Password: "password",
	})

	// Refresh with valid token
	newPair, err := mgr.Refresh(ctx, pair.RefreshToken)
	if err != nil {
		t.Fatalf("Refresh: %v", err)
	}
	if newPair.AccessToken == pair.AccessToken {
		t.Error("expected new access token after refresh")
	}

	// Old refresh token should be burned
	_, err = mgr.Refresh(ctx, pair.RefreshToken)
	if err == nil {
		t.Error("expected error reusing refresh token")
	}
}

func TestVerifyAccessToken_ValidAndInvalid(t *testing.T) {
	mgr, cleanup := newTestManager(t)
	defer cleanup()
	ctx := context.Background()

	pair, _ := mgr.Register(ctx, auth.RegisterRequest{
		Username: "alice", Email: "a@a.com", Password: "password",
	})

	claims, err := mgr.VerifyAccessToken(pair.AccessToken)
	if err != nil {
		t.Fatalf("VerifyAccessToken: %v", err)
	}
	if claims.Username != "alice" {
		t.Errorf("username = %q", claims.Username)
	}
	if claims.Role != auth.RoleAdmin {
		t.Errorf("role = %q", claims.Role)
	}

	_, err = mgr.VerifyAccessToken("not.a.jwt.token")
	if err == nil {
		t.Error("expected error for invalid token")
	}
}

func TestRegister_ShortPasswordRejected(t *testing.T) {
	mgr, cleanup := newTestManager(t)
	defer cleanup()

	_, err := mgr.Register(context.Background(), auth.RegisterRequest{
		Username: "alice", Email: "a@a.com", Password: "short",
	})
	if err == nil {
		t.Error("expected error for password < 8 chars")
	}
}

func TestRegister_ShortUsernameRejected(t *testing.T) {
	mgr, cleanup := newTestManager(t)
	defer cleanup()

	_, err := mgr.Register(context.Background(), auth.RegisterRequest{
		Username: "ab", Email: "a@a.com", Password: "password123",
	})
	if err == nil {
		t.Error("expected error for username < 3 chars")
	}
}
