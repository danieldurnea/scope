package roe_test

import (
	"testing"

	"github.com/bbounty-pro/orchestrator/internal/roe"
)

func TestGate_Validate(t *testing.T) {
	g := roe.NewGate()

	tests := []struct {
		name     string
		target   string
		scope    []string
		excluded []string
		wantErr  bool
	}{
		{
			name:    "in scope exact",
			target:  "api.example.com",
			scope:   []string{"api.example.com"},
			wantErr: false,
		},
		{
			name:    "in scope wildcard",
			target:  "sub.example.com",
			scope:   []string{"*.example.com"},
			wantErr: false,
		},
		{
			name:    "root matches wildcard",
			target:  "example.com",
			scope:   []string{"*.example.com"},
			wantErr: false,
		},
		{
			name:    "out of scope",
			target:  "evil.com",
			scope:   []string{"*.example.com"},
			wantErr: true,
		},
		{
			name:     "explicitly excluded",
			target:   "billing.example.com",
			scope:    []string{"*.example.com"},
			excluded: []string{"billing.example.com"},
			wantErr:  true,
		},
		{
			name:    "empty scope refuses",
			target:  "example.com",
			scope:   []string{},
			wantErr: true,
		},
		{
			name:    "empty target refuses",
			target:  "",
			scope:   []string{"*.example.com"},
			wantErr: true,
		},
		{
			name:    "url with protocol",
			target:  "https://app.example.com/login",
			scope:   []string{"*.example.com"},
			wantErr: false,
		},
		{
			name:    "CIDR scope",
			target:  "192.168.1.50",
			scope:   []string{"192.168.1.0/24"},
			wantErr: false,
		},
		{
			name:    "CIDR out of range",
			target:  "10.0.0.1",
			scope:   []string{"192.168.1.0/24"},
			wantErr: true,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			err := g.Validate(tt.target, tt.scope, tt.excluded)
			if (err != nil) != tt.wantErr {
				t.Errorf("Validate(%q) error = %v, wantErr = %v", tt.target, err, tt.wantErr)
			}
		})
	}
}

func TestGate_CheckInScope(t *testing.T) {
	g := roe.NewGate()

	if !g.CheckInScope("https://api.target.com", []string{"*.target.com"}, nil) {
		t.Error("expected in scope")
	}
	if g.CheckInScope("https://evil.com", []string{"*.target.com"}, nil) {
		t.Error("expected out of scope")
	}
}

func TestMatchesScope(t *testing.T) {
	// Test via Gate.Validate which calls matchesScope internally
	g := roe.NewGate()

	// Sub-sub domain
	if err := g.Validate("deep.sub.example.com", []string{"*.example.com"}, nil); err != nil {
		t.Errorf("deep subdomain should match *.example.com: %v", err)
	}

	// Pattern with protocol
	if err := g.Validate("admin.example.com", []string{"https://admin.example.com"}, nil); err != nil {
		t.Errorf("should match scope with protocol: %v", err)
	}
}
