package cache

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"github.com/redis/go-redis/v9"
	"github.com/rs/zerolog/log"
)

// Client wraps redis.Client with typed helpers.
type Client struct {
	rdb *redis.Client
}

// MustConnect creates a Redis client or fatals.
func MustConnect(redisURL string) *Client {
	opts, err := redis.ParseURL(redisURL)
	if err != nil {
		log.Fatal().Err(err).Str("url", redisURL).Msg("invalid Redis URL")
	}
	opts.PoolSize        = 20
	opts.MinIdleConns    = 5
	opts.MaxRetries      = 3
	opts.DialTimeout     = 5 * time.Second
	opts.ReadTimeout     = 3 * time.Second
	opts.WriteTimeout    = 3 * time.Second

	rdb := redis.NewClient(opts)

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := rdb.Ping(ctx).Err(); err != nil {
		log.Fatal().Err(err).Msg("Redis ping failed")
	}
	log.Info().Str("addr", opts.Addr).Msg("Redis connected")
	return &Client{rdb: rdb}
}

// Raw returns the underlying redis.Client for advanced operations.
func (c *Client) Raw() *redis.Client { return c.rdb }

// SetJSON marshals v to JSON and stores it with optional TTL (0 = no expiry).
func (c *Client) SetJSON(ctx context.Context, key string, v any, ttl time.Duration) error {
	data, err := json.Marshal(v)
	if err != nil {
		return fmt.Errorf("cache.SetJSON marshal: %w", err)
	}
	return c.rdb.Set(ctx, key, data, ttl).Err()
}

// GetJSON retrieves a key and unmarshals into dest.
// Returns redis.Nil if key does not exist.
func (c *Client) GetJSON(ctx context.Context, key string, dest any) error {
	data, err := c.rdb.Get(ctx, key).Bytes()
	if err != nil {
		return err // caller checks redis.Nil
	}
	return json.Unmarshal(data, dest)
}

// Publish sends a JSON-encoded payload to a Redis pub/sub channel.
func (c *Client) Publish(ctx context.Context, channel string, payload any) error {
	data, err := json.Marshal(payload)
	if err != nil {
		return err
	}
	return c.rdb.Publish(ctx, channel, data).Err()
}

// Del removes one or more keys.
func (c *Client) Del(ctx context.Context, keys ...string) error {
	return c.rdb.Del(ctx, keys...).Err()
}
