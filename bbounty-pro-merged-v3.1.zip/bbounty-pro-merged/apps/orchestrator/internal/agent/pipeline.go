package agent

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"sync"
	"sync/atomic"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/bbounty-pro/orchestrator/internal/findings"
	"github.com/bbounty-pro/orchestrator/internal/roe"
	"github.com/bbounty-pro/orchestrator/internal/tools"
	"github.com/bbounty-pro/orchestrator/internal/ws"
	"github.com/go-chi/chi/v5"
	"github.com/google/uuid"
	"github.com/rs/zerolog/log"
	"golang.org/x/sync/errgroup"
	"golang.org/x/time/rate"
)

// ── Constants ─────────────────────────────────────────────────────────────────

const (
	outputBase  = "/tmp/bbounty-scans"
	maxRetries  = 2
)

// ── Phase + Status ────────────────────────────────────────────────────────────

type Phase      string
type ScanStatus string

const (
	PhaseAnalyze Phase = "ANALYZE"
	PhasePlan    Phase = "PLAN"
	PhaseExecute Phase = "EXECUTE"
	PhaseIterate Phase = "ITERATE"
)

const (
	StatusQueued  ScanStatus = "queued"
	StatusRunning ScanStatus = "running"
	StatusPaused  ScanStatus = "paused"
	StatusDone    ScanStatus = "done"
	StatusFailed  ScanStatus = "failed"
	StatusAborted ScanStatus = "aborted"
)

// ── LiveStats is broadcast in real-time ───────────────────────────────────────

type LiveStats struct {
	ScanID    string     `json:"scan_id"`
	Phase     Phase      `json:"phase"`
	Status    ScanStatus `json:"status"`
	Subs      int64      `json:"subs"`
	Live      int64      `json:"live"`
	URLs      int64      `json:"urls"`
	Vulns     int64      `json:"vulns"`
	Progress  float64    `json:"progress"`
	StartedAt time.Time  `json:"started_at"`
	Elapsed   float64    `json:"elapsed_sec"`
}

// ── ScanRequest from API ──────────────────────────────────────────────────────

type ScanRequest struct {
	Target     string   `json:"target"`
	Program    string   `json:"program"`
	Tester     string   `json:"tester"`
	Scope      []string `json:"scope"`
	Excluded   []string `json:"excluded"`
	Platform   string   `json:"platform"`
	ToolIDs    []string `json:"tool_ids"`
	MaxConc    int      `json:"max_concurrent"`
	OwnerID    string   `json:"owner_id"` // set from JWT claims
}

// ── activeScan tracks a running scan ──────────────────────────────────────────

type activeScan struct {
	req      ScanRequest
	cancelFn context.CancelFunc
	mu       sync.RWMutex

	// FIXED: atomic fields — use atomic.Int64 (Go 1.19+) instead of raw int64.
	subs  atomic.Int64
	live  atomic.Int64
	urls  atomic.Int64
	vulns atomic.Int64

	phase  Phase
	status ScanStatus
}

func (s *activeScan) stats(scanID string) LiveStats {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return LiveStats{
		ScanID:  scanID,
		Phase:   s.phase,
		Status:  s.status,
		Subs:    s.subs.Load(),
		Live:    s.live.Load(),
		URLs:    s.urls.Load(),
		Vulns:   s.vulns.Load(),
	}
}

// ── Pipeline ──────────────────────────────────────────────────────────────────

type Pipeline struct {
	registry *tools.Registry
	hub      *ws.Hub
	gate     *roe.Gate
	findings *findings.Store
	cache    *cache.Client

	scans   map[string]*activeScan
	scansMu sync.RWMutex
}

func NewPipeline(
	r *tools.Registry, h *ws.Hub, g *roe.Gate,
	f *findings.Store, c *cache.Client,
) *Pipeline {
	return &Pipeline{
		registry: r, hub: h, gate: g,
		findings: f, cache: c,
		scans:    make(map[string]*activeScan),
	}
}

// HandleStart validates ROE, creates a scan, and launches the pipeline.
func (p *Pipeline) HandleStart(w http.ResponseWriter, r *http.Request) {
	var req ScanRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, `{"error":"invalid body"}`, http.StatusBadRequest)
		return
	}
	if err := p.gate.Validate(req.Target, req.Scope, req.Excluded); err != nil {
		http.Error(w, fmt.Sprintf(`{"error":"ROE violation: %s"}`, err), http.StatusForbidden)
		return
	}
	if req.MaxConc <= 0 {
		req.MaxConc = 8
	}

	scanID := uuid.New().String()
	ctx, cancel := context.WithCancel(context.Background())

	scan := &activeScan{
		req:      req,
		cancelFn: cancel,
		phase:    PhaseAnalyze,
		status:   StatusQueued,
	}

	p.scansMu.Lock()
	p.scans[scanID] = scan
	p.scansMu.Unlock()

	go p.run(ctx, scanID, scan)

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusAccepted)
	json.NewEncoder(w).Encode(map[string]string{
		"scan_id": scanID,
		"ws_url":  fmt.Sprintf("/ws/pipeline/%s", scanID),
	})
}

// run executes the 4-phase pipeline.
func (p *Pipeline) run(ctx context.Context, scanID string, scan *activeScan) {
	start := time.Now()

	defer func() {
		scan.mu.Lock()
		scan.status = StatusDone
		scan.mu.Unlock()
		p.broadcastStats(scanID, scan, start)
		go CleanOldOutputs(72 * time.Hour) // async cleanup
		log.Info().Str("scan", scanID).Dur("elapsed", time.Since(start)).Msg("scan complete")
	}()

	phases := []struct {
		phase   Phase
		toolSet string
		runFn   func(context.Context, string, *activeScan, *Semaphore) error
	}{
		{PhaseAnalyze, tools.PhaseRecon,   p.runPhase},
		{PhasePlan,    tools.PhaseEnum,    p.runPhase},
		{PhaseExecute, tools.PhaseScan,    p.runPhase},
		{PhaseIterate, tools.PhaseExploit, p.runPhase},
	}

	sem := NewSemaphore(scan.req.MaxConc)

	for _, ph := range phases {
		select {
		case <-ctx.Done():
			scan.mu.Lock(); scan.status = StatusAborted; scan.mu.Unlock()
			return
		default:
		}

		scan.mu.Lock()
		scan.phase = ph.phase
		scan.status = StatusRunning
		scan.mu.Unlock()

		p.broadcastStats(scanID, scan, start)
		p.broadcastEvent(scanID, "phase_start", map[string]string{"phase": string(ph.phase)})

		toolList := p.filterTools(scan.req.ToolIDs, ph.toolSet)
		if err := p.runPhase(ctx, scanID, scan, sem, toolList); err != nil {
			p.broadcastEvent(scanID, "phase_error", map[string]string{
				"phase": string(ph.phase), "error": err.Error(),
			})
		}
	}
}

// runPhase executes all tools in a phase with the shared semaphore.
func (p *Pipeline) runPhase(
	ctx context.Context, scanID string, scan *activeScan,
	sem *Semaphore, toolList []*tools.Tool,
) error {
	// Budget rate: 20 req/s default, shared across all tools in this phase.
	limiter := rate.NewLimiter(20, 20)
	g, gctx := errgroup.WithContext(ctx)

	for _, tool := range toolList {
		tool := tool // capture
		if !tool.Parallel {
			// Serial tools run sequentially within the phase.
			if err := p.executeTool(gctx, scanID, scan, tool, limiter, sem); err != nil {
				log.Warn().Err(err).Str("tool", tool.ID).Msg("tool error")
			}
			continue
		}
		g.Go(func() error {
			return p.executeTool(gctx, scanID, scan, tool, limiter, sem)
		})
	}
	return g.Wait()
}

// executeTool runs a single tool with retry and live streaming.
func (p *Pipeline) executeTool(
	ctx context.Context, scanID string, scan *activeScan,
	tool *tools.Tool, limiter *rate.Limiter, sem *Semaphore,
) error {
	if err := sem.Acquire(ctx); err != nil {
		return err
	}
	defer sem.Release()

	if err := limiter.Wait(ctx); err != nil {
		return err
	}

	outDir := filepath.Join(outputBase, scanID[:8])
	os.MkdirAll(outDir, 0o755)

	// FIXED: use tools.BuildCommand() — single source of truth, no duplicates.
	cmd := tools.BuildCommand(tool, tools.BuildContext{
		Target: scan.req.Target,
		ScanID: scanID,
		OutDir: outDir,
		Scope:  scan.req.Scope,
	})
	if tool.Phase == tools.PhaseRecon || tool.Phase == tools.PhaseEnum {
		cmd = tools.ScopeFilter(cmd, scan.req.Scope)
	}

	p.broadcastEvent(scanID, "tool_start", map[string]string{
		"tool_id": tool.ID, "tool": tool.Name, "phase": tool.Phase,
	})

	var lastErr error
	for attempt := 0; attempt <= maxRetries; attempt++ {
		if attempt > 0 {
			select {
			case <-ctx.Done():
				return ctx.Err()
			case <-time.After(time.Duration(attempt*5) * time.Second):
			}
		}
		var buf bytes.Buffer
		lastErr = p.shell(ctx, cmd, tool, scanID, &buf)
		if buf.Len() > 0 {
			if found, err := tools.Parse(tool.ID, &buf, scanID); err == nil {
				p.saveFindings(ctx, scanID, scan, found)
			}
		}
		if lastErr == nil || ctx.Err() != nil {
			break
		}
	}

	p.broadcastEvent(scanID, "tool_done", map[string]string{
		"tool_id": tool.ID, "status": errStatus(lastErr),
	})
	return lastErr
}

// shell runs a bash command, streaming output to WS and capturing for parsing.
func (p *Pipeline) shell(
	ctx context.Context, cmd string, tool *tools.Tool,
	scanID string, buf *bytes.Buffer,
) error {
	timeout := time.Duration(tool.Timeout) * time.Second
	if timeout == 0 {
		timeout = 5 * time.Minute
	}
	tctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()

	var execCmd *exec.Cmd
	if os.Getenv("DOCKER_MODE") == "true" {
		container := os.Getenv("KALI_CONTAINER")
		if container == "" {
			container = "bbounty-kali"
		}
		execCmd = exec.CommandContext(tctx, "docker", "exec", "-i", container, "/bin/bash", "-c", cmd)
	} else {
		execCmd = exec.CommandContext(tctx, "/bin/bash", "-c", cmd)
	}

	tw := &teeWriter{hub: p.hub, scanID: scanID, toolID: tool.ID, buf: buf}
	execCmd.Stdout = tw
	execCmd.Stderr = tw

	if err := execCmd.Start(); err != nil {
		return fmt.Errorf("start %s: %w", tool.Name, err)
	}
	return execCmd.Wait()
}

// saveFindings persists new findings and updates stats atomically.
func (p *Pipeline) saveFindings(ctx context.Context, scanID string, scan *activeScan, items []*findings.Finding) {
	for _, f := range items {
		if err := p.findings.Save(ctx, f); err != nil {
			log.Warn().Err(err).Str("title", f.Title).Msg("finding: save failed")
			continue
		}
		scan.vulns.Add(1)
		p.broadcastEvent(scanID, "new_finding", map[string]any{
			"id": f.ID, "title": f.Title,
			"severity": string(f.Severity), "url": f.URL,
		})
	}
}

// ── teeWriter: write to WS hub AND capture buffer ─────────────────────────────

type teeWriter struct {
	hub    *ws.Hub
	scanID string
	toolID string
	buf    *bytes.Buffer
	lines  int
}

func (t *teeWriter) Write(p []byte) (int, error) {
	t.buf.Write(p)
	// Throttle WS broadcast: every 3rd chunk to avoid flooding slow clients.
	t.lines++
	if t.lines%3 == 0 {
		d := make([]byte, len(p))
		copy(d, p)
		t.hub.BroadcastTerminal(t.scanID, t.toolID, d)
	}
	return len(p), nil
}

// ── Output management ─────────────────────────────────────────────────────────

// CleanOldOutputs removes scan directories older than ttl.
func CleanOldOutputs(ttl time.Duration) {
	entries, err := os.ReadDir(outputBase)
	if err != nil {
		return
	}
	cutoff := time.Now().Add(-ttl)
	for _, e := range entries {
		if !e.IsDir() {
			continue
		}
		info, err := e.Info()
		if err != nil || !info.ModTime().Before(cutoff) {
			continue
		}
		path := filepath.Join(outputBase, e.Name())
		if err := os.RemoveAll(path); err != nil {
			log.Warn().Err(err).Str("path", path).Msg("cleanup failed")
		}
	}
}

// ── Broadcast helpers ─────────────────────────────────────────────────────────

func (p *Pipeline) broadcastStats(scanID string, scan *activeScan, start time.Time) {
	s := scan.stats(scanID)
	s.StartedAt = start
	s.Elapsed = time.Since(start).Seconds()
	data, _ := json.Marshal(s)
	p.hub.BroadcastStats(scanID, data)
}

func (p *Pipeline) broadcastEvent(scanID, event string, payload any) {
	data, _ := json.Marshal(map[string]any{
		"event": event, "payload": payload,
		"ts": time.Now().UnixMilli(),
	})
	p.hub.BroadcastPipeline(scanID, data)
}

// ── HTTP Handlers ─────────────────────────────────────────────────────────────

func (p *Pipeline) HandleStop(w http.ResponseWriter, r *http.Request) {
	scanID := r.URL.Query().Get("scan_id")
	p.scansMu.RLock()
	scan, ok := p.scans[scanID]
	p.scansMu.RUnlock()
	if !ok {
		http.Error(w, `{"error":"not found"}`, http.StatusNotFound)
		return
	}
	scan.cancelFn()
	w.Write([]byte(`{"status":"stopping"}`))
}

func (p *Pipeline) HandlePause(w http.ResponseWriter, _ *http.Request) {
	w.Write([]byte(`{"status":"paused"}`))
}

func (p *Pipeline) HandleStatus(w http.ResponseWriter, r *http.Request) {
	scanID := chi.URLParam(r, "scanID")
	p.scansMu.RLock()
	scan, ok := p.scans[scanID]
	p.scansMu.RUnlock()
	if !ok {
		http.Error(w, `{"error":"not found"}`, http.StatusNotFound)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(scan.stats(scanID))
}

func (p *Pipeline) HandleStats(w http.ResponseWriter, r *http.Request) {
	p.HandleStatus(w, r)
}

func (p *Pipeline) DrainAll(ctx context.Context) {
	p.scansMu.RLock()
	defer p.scansMu.RUnlock()
	for _, scan := range p.scans {
		scan.cancelFn()
	}
	select {
	case <-ctx.Done():
	case <-time.After(10 * time.Second):
	}
}

// ── Utilities ─────────────────────────────────────────────────────────────────

func (p *Pipeline) filterTools(requested []string, phase string) []*tools.Tool {
	all := p.registry.ByPhase(phase)
	if len(requested) == 0 {
		return all
	}
	want := make(map[string]bool, len(requested))
	for _, id := range requested {
		want[id] = true
	}
	var out []*tools.Tool
	for _, t := range all {
		if want[t.ID] {
			out = append(out, t)
		}
	}
	return out
}

func (p *Pipeline) parseStats(line string, scan *activeScan) {
	l := line
	if len(l) > 500 {
		l = l[:500]
	}
	if containsAny(l, "found", "discovered") && containsAny(l, "subdomain", ".") {
		scan.subs.Add(1)
	}
	if containsAny(l, "http://", "https://") {
		scan.urls.Add(1)
	}
	if containsAny(l, "[critical]", "[high]", "[medium]") {
		scan.vulns.Add(1)
	}
}

func containsAny(s string, subs ...string) bool {
	for _, sub := range subs {
		if len(s) >= len(sub) {
			// Case-insensitive contains without strings import loop
			for i := 0; i <= len(s)-len(sub); i++ {
				if equalFold(s[i:i+len(sub)], sub) {
					return true
				}
			}
		}
	}
	return false
}

func equalFold(a, b string) bool {
	if len(a) != len(b) {
		return false
	}
	for i := 0; i < len(a); i++ {
		ca, cb := a[i], b[i]
		if ca >= 'A' && ca <= 'Z' {
			ca += 32
		}
		if cb >= 'A' && cb <= 'Z' {
			cb += 32
		}
		if ca != cb {
			return false
		}
	}
	return true
}

func errStatus(err error) string {
	if err == nil {
		return "success"
	}
	return "error"
}

// ── Streaming io.ReadCloser helpers ───────────────────────────────────────────

// Ensure teeWriter implements io.Writer.
var _ io.Writer = (*teeWriter)(nil)
