package main

import (
	"context"
	"encoding/json"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/agent"
	"github.com/bbounty-pro/orchestrator/internal/ai"
	"github.com/bbounty-pro/orchestrator/internal/auth"
	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/bbounty-pro/orchestrator/internal/diff"
	"github.com/bbounty-pro/orchestrator/internal/findings"
	"github.com/bbounty-pro/orchestrator/internal/priority"
	"github.com/bbounty-pro/orchestrator/internal/ratelimit"
	"github.com/bbounty-pro/orchestrator/internal/roe"
	"github.com/bbounty-pro/orchestrator/internal/skills"
	"github.com/bbounty-pro/orchestrator/internal/tools"
	"github.com/bbounty-pro/orchestrator/internal/vps"
	"github.com/bbounty-pro/orchestrator/internal/ws"

	"github.com/go-chi/chi/v5"
	"github.com/go-chi/chi/v5/middleware"
	"github.com/go-chi/cors"
	"github.com/rs/zerolog"
	"github.com/rs/zerolog/log"
	"github.com/spf13/viper"
)

func main() {
	if os.Getenv("ENV") != "production" {
		log.Logger = log.Output(zerolog.ConsoleWriter{Out: os.Stderr, TimeFormat: time.RFC3339})
	}

	// VPS-only enforcement
	if err := vps.EnforceMode(); err != nil {
		log.Fatal().Err(err).Msg("VPS enforcement failed — set ALLOW_LOCAL=true for dev")
	}

	viper.AutomaticEnv()
	viper.SetDefault("BIND_ADDR",      "0.0.0.0")
	viper.SetDefault("PORT",           "8080")
	viper.SetDefault("REDIS_URL",      "redis://redis:6379")
	viper.SetDefault("MAX_CONCURRENT", 8)
	viper.SetDefault("FRONTEND_URL",   "")
	viper.SetDefault("SKILLS_ROOT",    "/opt/bbounty-pro/apps/skills")

	if viper.GetString("JWT_SECRET") == "" {
		log.Fatal().Msg("JWT_SECRET required — generate with: openssl rand -hex 32")
	}

	// Core deps
	redisClient   := cache.MustConnect(viper.GetString("REDIS_URL"))
	wsHub         := ws.NewHub(redisClient)
	registry      := tools.NewRegistry()
	roeGate       := roe.NewGate()
	findingsStore := findings.NewStore(redisClient)
	aiClient      := ai.NewClient(viper.GetString("ANTHROPIC_API_KEY"))

	// Feature modules
	authMgr     := auth.NewManager(redisClient, viper.GetString("JWT_SECRET"))
	rateLimReg  := ratelimit.NewRegistry(redisClient)
	scorer      := priority.NewScorer(aiClient, redisClient)
	diffEngine  := diff.NewEngine(redisClient)
	pipeline    := agent.NewPipeline(registry, wsHub, roeGate, findingsStore, redisClient)

	// 14 skill modules from BountyHunter-Pro v3.0 ULTRA
	skillRegistry := skills.NewRegistry(viper.GetString("SKILLS_ROOT"))
	if err := skillRegistry.LoadFromDisk(); err != nil {
		log.Warn().Err(err).Msg("skills: disk load failed — using built-ins")
	}
	pythonRunner := skills.NewPythonRunner()

	// Background workers
	go wsHub.Run()
	go func() {
		t := time.NewTicker(6 * time.Hour)
		defer t.Stop()
		for range t.C {
			agent.CleanOldOutputs(72 * time.Hour)
		}
	}()

	r := chi.NewRouter()
	r.Use(middleware.RequestID)
	r.Use(middleware.RealIP)
	r.Use(middleware.Recoverer)
	r.Use(middleware.Compress(5))

	allowedOrigins := []string{"http://localhost:3000"}
	if u := viper.GetString("FRONTEND_URL"); u != "" {
		allowedOrigins = []string{u}
	}
	r.Use(cors.Handler(cors.Options{
		AllowedOrigins:   allowedOrigins,
		AllowedMethods:   []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
		AllowedHeaders:   []string{"Accept", "Authorization", "Content-Type", "X-Request-ID"},
		AllowCredentials: true,
		MaxAge:           300,
	}))

	r.Get("/healthz", func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]any{
			"status":    "ok",
			"version":   "3.0.0-MERGED",
			"public_ip": vps.PublicIP(),
			"vps_mode":  os.Getenv("ALLOW_LOCAL") != "true",
		})
	})

	// Auth
	r.Route("/auth", func(r chi.Router) {
		r.Post("/register", authMgr.HandleRegister)
		r.Post("/login",    authMgr.HandleLogin)
		r.Post("/refresh",  authMgr.HandleRefresh)
		r.Group(func(r chi.Router) {
			r.Use(authMgr.Middleware)
			r.Get("/me",        authMgr.HandleMe)
			r.Post("/invite",   authMgr.HandleInvite)
			r.Get("/team",      authMgr.HandleTeam)
			r.Put("/team/{id}", authMgr.HandleUpdateMember)
		})
	})

	// Protected API
	r.Route("/api/v1", func(r chi.Router) {
		r.Use(authMgr.Middleware)
		hunterAdmin := authMgr.RequireRole(auth.RoleAdmin, auth.RoleHunter)

		// Scan
		r.With(hunterAdmin).Post("/scan/start", pipeline.HandleStart)
		r.With(hunterAdmin).Post("/scan/stop",  pipeline.HandleStop)
		r.With(hunterAdmin).Post("/scan/pause", pipeline.HandlePause)
		r.Get("/scan/status/{scanID}",          pipeline.HandleStatus)

		// Tools
		r.Get("/tools",               registry.HandleList)
		r.Get("/tools/{toolID}/info", registry.HandleInfo)
		r.With(hunterAdmin).Post("/tools/{toolID}/run", registry.HandleRunSingle)

		// Skills (14 modules)
		r.Get("/skills",            skillRegistry.HandleList)
		r.Get("/skills/{skillID}",  skillRegistry.HandleGet)
		r.With(hunterAdmin).Post("/skills/{skillID}/execute",
			skillRegistry.HandleExecute(pythonRunner))

		// ROE
		r.Post("/roe/validate",    roeGate.HandleValidate)
		r.Post("/roe/check-scope", roeGate.HandleCheckScope)

		// Findings
		r.Get("/findings/{scanID}",        findingsStore.HandleList)
		r.With(hunterAdmin).Post("/findings",     findingsStore.HandleCreate)
		r.With(hunterAdmin).Put("/findings/{id}", findingsStore.HandleUpdate)
		r.With(authMgr.RequireRole(auth.RoleAdmin)).
			Delete("/findings/{id}", findingsStore.HandleDelete)
		r.Post("/findings/{id}/analyze", aiClient.HandleAnalyzeFinding)

		// AI
		r.Post("/ai/chat",          aiClient.HandleChat)
		r.Post("/ai/report-review", aiClient.HandleReportReview)

		// Dashboards
		r.Get("/stats/{scanID}",    pipeline.HandleStats)
		r.Get("/ratelimit/stats",   rateLimReg.HandleStats)
		r.Get("/priority/{scanID}", func(w http.ResponseWriter, r *http.Request) {
			scanID := chi.URLParam(r, "scanID")
			q, err := scorer.GetQueue(r.Context(), scanID)
			if err != nil {
				http.Error(w, `{"error":"queue not ready"}`, http.StatusNotFound)
				return
			}
			w.Header().Set("Content-Type", "application/json")
			json.NewEncoder(w).Encode(q)
		})

		// Diff
		r.Get("/diff/latest",  diffEngine.HandleLatestDiff)
		r.Get("/diff/history", diffEngine.HandleScanHistory)
		r.Get("/diff/compare", func(w http.ResponseWriter, r *http.Request) {
			q := r.URL.Query()
			old, new_, target := q.Get("old"), q.Get("new"), q.Get("target")
			if old == "" || new_ == "" || target == "" {
				http.Error(w, `{"error":"old, new, target required"}`, http.StatusBadRequest)
				return
			}
			oldSnap, err1 := diffEngine.GetSnapshot(r.Context(), target, old)
			newSnap, err2 := diffEngine.GetSnapshot(r.Context(), target, new_)
			if err1 != nil || err2 != nil {
				http.Error(w, `{"error":"snapshot not found"}`, http.StatusNotFound)
				return
			}
			w.Header().Set("Content-Type", "application/json")
			json.NewEncoder(w).Encode(diffEngine.Compare(r.Context(), oldSnap, newSnap))
		})
	})

	// WebSocket
	r.Group(func(r chi.Router) {
		r.Use(authMgr.WSMiddleware)
		r.Get("/ws/terminal/{scanID}/{toolID}", wsHub.HandleTerminal)
		r.Get("/ws/stats/{scanID}",             wsHub.HandleStats)
		r.Get("/ws/pipeline/{scanID}",          wsHub.HandlePipeline)
	})

	addr := viper.GetString("BIND_ADDR") + ":" + viper.GetString("PORT")
	srv := &http.Server{
		Addr:              addr,
		Handler:           r,
		ReadTimeout:       10 * time.Second,
		WriteTimeout:      0,
		IdleTimeout:       120 * time.Second,
		ReadHeaderTimeout: 5 * time.Second,
	}

	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	go func() {
		log.Info().
			Str("addr", srv.Addr).
			Str("public_ip", vps.PublicIP()).
			Msg("🚀 BBounty Pro v3 MERGED — orchestrator + 14 skills + Python agents")
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatal().Err(err).Msg("server error")
		}
	}()

	<-ctx.Done()
	log.Info().Msg("Shutting down...")
	shutdownCtx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	pipeline.DrainAll(shutdownCtx)
	if err := srv.Shutdown(shutdownCtx); err != nil {
		log.Error().Err(err).Msg("shutdown error")
	}
	log.Info().Msg("Server stopped cleanly")
}
