"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";
import { Shield, AlertTriangle, CheckCircle, X, Plus } from "lucide-react";
import { useScanStore } from "@/lib/store";

const PLATFORMS = [
  { id: "hackerone",  label: "HackerOne",  color: "#54b35f" },
  { id: "bugcrowd",  label: "Bugcrowd",   color: "#f26222" },
  { id: "intigriti", label: "Intigriti",  color: "#1b2d5b" },
  { id: "private",   label: "Private",    color: "#7c6aff" },
] as const;

interface ROEData {
  target: string;
  program: string;
  tester: string;
  scope: string[];
  excluded: string[];
  platform: string;
}

interface Props {
  onConfirm: () => void;
}

export function ROEGate({ onConfirm }: Props) {
  const { setROE } = useScanStore();
  const [data, setData] = useState<ROEData>({
    target: "",
    program: "",
    tester: "",
    scope: [""],
    excluded: [],
    platform: "hackerone",
  });
  const [validating, setValidating] = useState(false);
  const [validationResult, setValidationResult] = useState<{
    valid: boolean;
    reasons: string[];
    warnings: string[];
  } | null>(null);
  const [agreed, setAgreed] = useState(false);

  const setField = <K extends keyof ROEData>(k: K, v: ROEData[K]) =>
    setData(prev => ({ ...prev, [k]: v }));

  const addScope = () => setField("scope", [...data.scope, ""]);
  const removeScope = (i: number) =>
    setField("scope", data.scope.filter((_, idx) => idx !== i));
  const updateScope = (i: number, v: string) =>
    setField("scope", data.scope.map((s, idx) => (idx === i ? v : s)));

  const addExcluded = () => setField("excluded", [...data.excluded, ""]);
  const removeExcluded = (i: number) =>
    setField("excluded", data.excluded.filter((_, idx) => idx !== i));
  const updateExcluded = (i: number, v: string) =>
    setField("excluded", data.excluded.map((s, idx) => (idx === i ? v : s)));

  const validate = async () => {
    setValidating(true);
    try {
      const res = await fetch("/api/v1/roe/validate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          target:   data.target,
          program:  data.program,
          tester:   data.tester,
          scope:    data.scope.filter(Boolean),
          excluded: data.excluded.filter(Boolean),
          platform: data.platform,
        }),
      });
      const json = await res.json();
      setValidationResult(json);
    } catch {
      setValidationResult({
        valid: false,
        reasons: ["Backend unreachable — check orchestrator is running"],
        warnings: [],
      });
    } finally {
      setValidating(false);
    }
  };

  const canConfirm =
    data.target &&
    data.scope.some(Boolean) &&
    agreed &&
    validationResult?.valid;

  const handleConfirm = () => {
    if (!canConfirm) return;
    setROE({
      target:   data.target,
      program:  data.program,
      tester:   data.tester,
      scope:    data.scope.filter(Boolean),
      excluded: data.excluded.filter(Boolean),
      platform: data.platform,
    });
    onConfirm();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#040608]/90 backdrop-blur-sm">
      <div className="w-full max-w-2xl mx-4 bg-[#0a1015] border border-[#1a2a32] rounded-xl overflow-hidden shadow-2xl shadow-black/60">
        {/* Header */}
        <div className="flex items-center gap-3 px-6 py-4 border-b border-[#1a2a32] bg-[#080c0e]">
          <Shield size={18} className="text-[#ff9b3a]" strokeWidth={2} />
          <div>
            <div className="text-sm font-bold text-[#c8d8e0] tracking-wide">RULES OF ENGAGEMENT</div>
            <div className="text-[10px] text-[#2a5a6a] tracking-widest">
              ROE GATE — REQUIRED BEFORE SCAN INITIATION
            </div>
          </div>
          <div className="ml-auto flex items-center gap-2">
            <AlertTriangle size={14} className="text-[#ff9b3a]" />
            <span className="text-[10px] text-[#ff9b3a] font-semibold tracking-widest">
              AUTHORIZED TESTING ONLY
            </span>
          </div>
        </div>

        <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* Platform selector */}
          <div>
            <label className="block text-[10px] text-[#4a6a7a] tracking-widest mb-2">
              PLATFORM
            </label>
            <div className="flex gap-2">
              {PLATFORMS.map(p => (
                <button
                  key={p.id}
                  onClick={() => setField("platform", p.id)}
                  className={cn(
                    "px-4 py-2 rounded-lg text-xs font-semibold border transition-all duration-150",
                    data.platform === p.id
                      ? "border-current text-current bg-current/10"
                      : "border-[#1a2a32] text-[#4a6a7a] hover:border-[#2a4a5a]"
                  )}
                  style={{
                    color: data.platform === p.id ? p.color : undefined,
                    borderColor: data.platform === p.id ? p.color : undefined,
                  }}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Target + Program row */}
          <div className="grid grid-cols-2 gap-4">
            <Field
              label="TARGET DOMAIN"
              placeholder="target.com"
              value={data.target}
              onChange={v => setField("target", v)}
              required
            />
            <Field
              label="PROGRAM NAME"
              placeholder="Acme Corp Bug Bounty"
              value={data.program}
              onChange={v => setField("program", v)}
            />
          </div>

          {/* Tester */}
          <Field
            label="TESTER HANDLE"
            placeholder="@yourhandle"
            value={data.tester}
            onChange={v => setField("tester", v)}
          />

          {/* Scope */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-[10px] text-[#4a6a7a] tracking-widest">
                IN-SCOPE <span className="text-[#ff3a5c]">*</span>
              </label>
              <button
                onClick={addScope}
                className="flex items-center gap-1 text-[10px] text-[#2a7a6a] hover:text-[#00e5cc] transition-colors"
              >
                <Plus size={11} /> ADD
              </button>
            </div>
            <div className="space-y-2">
              {data.scope.map((s, i) => (
                <div key={i} className="flex gap-2">
                  <input
                    value={s}
                    onChange={e => updateScope(i, e.target.value)}
                    placeholder="*.example.com or 192.168.1.0/24"
                    className={inputClass}
                  />
                  {data.scope.length > 1 && (
                    <button
                      onClick={() => removeScope(i)}
                      className="p-2 text-[#4a3a3a] hover:text-[#ff3a5c] transition-colors"
                    >
                      <X size={13} />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Excluded */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-[10px] text-[#4a6a7a] tracking-widest">EXCLUDED</label>
              <button
                onClick={addExcluded}
                className="flex items-center gap-1 text-[10px] text-[#4a3a3a] hover:text-[#ff9b3a] transition-colors"
              >
                <Plus size={11} /> ADD
              </button>
            </div>
            <div className="space-y-2">
              {data.excluded.map((s, i) => (
                <div key={i} className="flex gap-2">
                  <input
                    value={s}
                    onChange={e => updateExcluded(i, e.target.value)}
                    placeholder="billing.example.com"
                    className={cn(inputClass, "border-[#4a2a2a] focus:border-[#ff9b3a]/50")}
                  />
                  <button
                    onClick={() => removeExcluded(i)}
                    className="p-2 text-[#4a3a3a] hover:text-[#ff3a5c] transition-colors"
                  >
                    <X size={13} />
                  </button>
                </div>
              ))}
              {data.excluded.length === 0 && (
                <div className="text-[11px] text-[#2a4a5a] italic px-1">
                  No exclusions — all in-scope targets will be tested
                </div>
              )}
            </div>
          </div>

          {/* Validation result */}
          {validationResult && (
            <div
              className={cn(
                "rounded-lg p-4 border text-xs space-y-2",
                validationResult.valid
                  ? "border-[#1a4a3a] bg-[#0a1f19]"
                  : "border-[#4a1a1a] bg-[#1a0a0a]"
              )}
            >
              <div className="flex items-center gap-2 font-semibold">
                {validationResult.valid ? (
                  <><CheckCircle size={14} className="text-[#00e5cc]" />
                    <span className="text-[#00e5cc]">ROE VALIDATED — Target is in scope</span></>
                ) : (
                  <><AlertTriangle size={14} className="text-[#ff3a5c]" />
                    <span className="text-[#ff3a5c]">VALIDATION FAILED</span></>
                )}
              </div>
              {validationResult.reasons.map((r, i) => (
                <div key={i} className="text-[#ff9b3a] pl-5">⚠ {r}</div>
              ))}
              {validationResult.warnings.map((w, i) => (
                <div key={i} className="text-[#4a8a9a] pl-5">ℹ {w}</div>
              ))}
            </div>
          )}

          {/* Legal agreement */}
          <label className="flex items-start gap-3 cursor-pointer group">
            <div
              onClick={() => setAgreed(!agreed)}
              className={cn(
                "mt-0.5 w-4 h-4 rounded border flex-shrink-0 flex items-center justify-center",
                "transition-all duration-150",
                agreed
                  ? "bg-[#00e5cc] border-[#00e5cc]"
                  : "border-[#2a4a5a] group-hover:border-[#4a8a9a]"
              )}
            >
              {agreed && <span className="text-[#080c0e] text-[10px] font-black">✓</span>}
            </div>
            <span className="text-[11px] text-[#4a6a7a] leading-relaxed">
              I confirm I have explicit written authorization to test the specified targets.
              I will strictly adhere to the defined scope and excluded domains.
              Unauthorized access is illegal — I accept full responsibility for my actions.
            </span>
          </label>
        </div>

        {/* Footer actions */}
        <div className="flex items-center gap-3 px-6 py-4 border-t border-[#1a2a32] bg-[#080c0e]">
          <button
            onClick={validate}
            disabled={!data.target || !data.scope.some(Boolean) || validating}
            className={cn(
              "px-5 py-2.5 rounded-lg text-xs font-semibold border transition-all duration-150",
              "border-[#2a4a5a] text-[#4a8a9a] hover:border-[#4a8a9a] hover:text-[#8ab4c4]",
              "disabled:opacity-40 disabled:cursor-not-allowed"
            )}
          >
            {validating ? "Validating..." : "Validate ROE"}
          </button>

          <button
            onClick={handleConfirm}
            disabled={!canConfirm}
            className={cn(
              "ml-auto px-8 py-2.5 rounded-lg text-xs font-bold tracking-widest uppercase",
              "transition-all duration-150",
              canConfirm
                ? "bg-[#00e5cc] text-[#080c0e] hover:bg-[#20ffec] shadow-lg shadow-[#00e5cc]/20"
                : "bg-[#0a2a22] text-[#2a5a4a] cursor-not-allowed border border-[#1a3a2a]"
            )}
          >
            Confirm & Enter →
          </button>
        </div>
      </div>
    </div>
  );
}

const inputClass =
  "flex-1 bg-[#080c0e] border border-[#1a2a32] rounded-lg px-3 py-2 text-xs text-[#c8d8e0] " +
  "placeholder-[#2a4a5a] font-mono focus:outline-none focus:border-[#00e5cc]/40 " +
  "transition-colors duration-150";

function Field({
  label, placeholder, value, onChange, required,
}: {
  label: string;
  placeholder: string;
  value: string;
  onChange: (v: string) => void;
  required?: boolean;
}) {
  return (
    <div>
      <label className="block text-[10px] text-[#4a6a7a] tracking-widest mb-1.5">
        {label} {required && <span className="text-[#ff3a5c]">*</span>}
      </label>
      <input
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        className={inputClass}
      />
    </div>
  );
}
