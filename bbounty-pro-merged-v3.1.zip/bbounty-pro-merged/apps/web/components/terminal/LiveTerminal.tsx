"use client";

import { useEffect, useRef, useState, useCallback } from "react";
import { cn } from "@/lib/utils";
import { Maximize2, X, Download, Search } from "lucide-react";

interface Props {
  scanID: string | null;
  toolID?: string;
  className?: string;
}

// Tool tab for multi-terminal view
interface TermTab {
  toolID: string;
  label: string;
  hasActivity: boolean;
  errorCount: number;
}

export function LiveTerminal({ scanID, toolID, className }: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const termRef = useRef<any>(null);
  const fitAddonRef = useRef<any>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [activeTool, setActiveTool] = useState(toolID || "subfinder");
  const [tabs, setTabs] = useState<TermTab[]>([
    { toolID: "subfinder",  label: "subfinder",  hasActivity: false, errorCount: 0 },
    { toolID: "httpx",      label: "httpx",      hasActivity: false, errorCount: 0 },
    { toolID: "nuclei",     label: "nuclei-ai",  hasActivity: false, errorCount: 0 },
    { toolID: "ffuf",       label: "ffuf",       hasActivity: false, errorCount: 0 },
  ]);

  // Initialize xterm.js lazily (client-only)
  const initTerminal = useCallback(async () => {
    if (!containerRef.current || termRef.current) return;

    const { Terminal } = await import("@xterm/xterm");
    const { FitAddon } = await import("@xterm/addon-fit");
    const { WebLinksAddon } = await import("@xterm/addon-web-links");
    await import("@xterm/xterm/css/xterm.css");

    const term = new Terminal({
      theme: {
        background:    "#080c0e",
        foreground:    "#c8d8e0",
        cursor:        "#00e5cc",
        cursorAccent:  "#080c0e",
        black:         "#0a1015",
        red:           "#ff3a5c",
        green:         "#00e5cc",
        yellow:        "#ff9b3a",
        blue:          "#7c6aff",
        magenta:       "#e040fb",
        cyan:          "#00bcd4",
        white:         "#c8d8e0",
        brightBlack:   "#2a4a5a",
        brightRed:     "#ff5a7c",
        brightGreen:   "#20ffec",
        brightYellow:  "#ffbb5a",
        brightBlue:    "#9c8aff",
        brightMagenta: "#f060fb",
        brightCyan:    "#40dcf4",
        brightWhite:   "#e8f8ff",
        selectionBackground: "#00e5cc22",
      },
      fontFamily: '"JetBrains Mono", "Fira Code", "Cascadia Code", Menlo, monospace',
      fontSize: 12,
      lineHeight: 1.4,
      letterSpacing: 0.5,
      cursorBlink: true,
      cursorStyle: "block",
      scrollback: 10000,
      fastScrollModifier: "shift",
      convertEol: true,
      allowTransparency: true,
    });

    const fitAddon = new FitAddon();
    const webLinksAddon = new WebLinksAddon();

    term.loadAddon(fitAddon);
    term.loadAddon(webLinksAddon);
    term.open(containerRef.current);
    fitAddon.fit();

    termRef.current = term;
    fitAddonRef.current = fitAddon;

    // Welcome message
    term.writeln("\x1b[36m╔══════════════════════════════════════════════════╗\x1b[0m");
    term.writeln("\x1b[36m║  \x1b[1;32mBBOUNTY PRO\x1b[0;36m · Live Tool Terminal · v2.0        ║\x1b[0m");
    term.writeln("\x1b[36m╚══════════════════════════════════════════════════╝\x1b[0m");
    term.writeln("");

    return term;
  }, []);

  // Connect WebSocket for a specific tool
  const connectWS = useCallback((tid: string) => {
    if (!scanID) return;

    // Close existing connection
    if (wsRef.current) {
      wsRef.current.close();
    }

    const proto = window.location.protocol === "https:" ? "wss" : "ws";
    const wsURL = `${proto}://${window.location.hostname}:8080/ws/terminal/${scanID}/${tid}`;

    const ws = new WebSocket(wsURL);
    ws.binaryType = "arraybuffer";
    wsRef.current = ws;

    ws.onopen = () => {
      setIsConnected(true);
      termRef.current?.writeln(`\x1b[32m[+] Connected to ${tid} stream\x1b[0m`);
    };

    ws.onmessage = (evt) => {
      if (!termRef.current) return;
      // Binary frames for terminal data (xterm binary protocol)
      if (evt.data instanceof ArrayBuffer) {
        termRef.current.write(new Uint8Array(evt.data));
      } else {
        termRef.current.write(evt.data);
      }

      // Mark tab as active
      setTabs(prev => prev.map(t =>
        t.toolID === tid ? { ...t, hasActivity: true } : t
      ));
    };

    ws.onclose = () => {
      setIsConnected(false);
      termRef.current?.writeln(`\x1b[33m[~] Stream ended for ${tid}\x1b[0m`);
    };

    ws.onerror = () => {
      setIsConnected(false);
      termRef.current?.writeln(`\x1b[31m[!] WebSocket error for ${tid}\x1b[0m`);
      setTabs(prev => prev.map(t =>
        t.toolID === tid ? { ...t, errorCount: t.errorCount + 1 } : t
      ));
    };
  }, [scanID]);

  // Boot terminal on mount
  useEffect(() => {
    initTerminal().then(() => {
      if (scanID) connectWS(activeTool);
    });

    return () => {
      wsRef.current?.close();
      termRef.current?.dispose();
      termRef.current = null;
    };
  }, []);

  // Reconnect on tool tab switch
  useEffect(() => {
    if (termRef.current && scanID) {
      termRef.current.clear();
      connectWS(activeTool);
    }
  }, [activeTool, scanID]);

  // Resize observer
  useEffect(() => {
    if (!containerRef.current) return;
    const ro = new ResizeObserver(() => {
      fitAddonRef.current?.fit();
    });
    ro.observe(containerRef.current);
    return () => ro.disconnect();
  }, []);

  const downloadLog = () => {
    if (!termRef.current) return;
    const buffer = termRef.current.buffer.active;
    let text = "";
    for (let i = 0; i < buffer.length; i++) {
      const line = buffer.getLine(i);
      if (line) text += line.translateToString(true) + "\n";
    }
    const blob = new Blob([text], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${activeTool}-${scanID?.slice(0, 8)}.log`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className={cn("flex flex-col h-full bg-[#080c0e]", className)}>
      {/* Tool tabs */}
      <div className="flex items-center border-b border-[#1a2a32] bg-[#0a1015] overflow-x-auto">
        <div className="flex flex-1">
          {tabs.map(tab => (
            <button
              key={tab.toolID}
              onClick={() => setActiveTool(tab.toolID)}
              className={cn(
                "flex items-center gap-2 px-4 py-2 text-[11px] font-mono border-r border-[#1a2a32] whitespace-nowrap",
                "transition-colors duration-150",
                activeTool === tab.toolID
                  ? "bg-[#080c0e] text-[#00e5cc]"
                  : "text-[#4a6a7a] hover:text-[#8ab4c4] hover:bg-[#0c1820]"
              )}
            >
              {tab.hasActivity && (
                <span className="w-1.5 h-1.5 rounded-full bg-[#00e5cc] animate-pulse" />
              )}
              {tab.errorCount > 0 && (
                <span className="w-1.5 h-1.5 rounded-full bg-[#ff3a5c]" />
              )}
              {tab.label}
              {tab.errorCount > 0 && (
                <span className="text-[9px] text-[#ff3a5c]">({tab.errorCount})</span>
              )}
            </button>
          ))}
        </div>

        {/* Terminal controls */}
        <div className="flex items-center gap-1 px-3 border-l border-[#1a2a32]">
          <div className={cn(
            "w-2 h-2 rounded-full mr-2",
            isConnected ? "bg-[#00e5cc] animate-pulse" : "bg-[#4a3a3a]"
          )} />
          <button
            onClick={downloadLog}
            className="p-1.5 text-[#2a5a6a] hover:text-[#8ab4c4] transition-colors"
            title="Download log"
          >
            <Download size={13} />
          </button>
        </div>
      </div>

      {/* Terminal canvas */}
      <div ref={containerRef} className="flex-1 overflow-hidden p-2" />
    </div>
  );
}
