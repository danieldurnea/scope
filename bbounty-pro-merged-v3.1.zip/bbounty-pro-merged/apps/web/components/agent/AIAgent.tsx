"use client";

import { useState, useRef, useEffect } from "react";
import { cn } from "@/lib/utils";
import { Send, Bot, User, Zap, Loader2 } from "lucide-react";

interface Message {
  role: "user" | "assistant";
  content: string;
  ts: number;
}

const QUICK_PROMPTS = [
  {
    id: "recon_analysis",
    label: "Analyze recon output",
    icon: "🔍",
    prompt: "Analyze the latest reconnaissance output and identify the most promising attack vectors. Prioritize by exploitation potential.",
  },
  {
    id: "waf_bypass",
    label: "wafw00f bypass techniques",
    icon: "🛡️",
    prompt: "Explain wafw00f bypass techniques for the detected WAF. Give me specific payload encoding strategies and HTTP-level bypasses.",
  },
  {
    id: "enhanced_recon_explain",
    label: "Explain enhanced_recon.py",
    icon: "📜",
    prompt: "Explain the enhanced_recon.py script architecture: data flow, phases, tool orchestration, and how to tune it for large targets.",
  },
  {
    id: "scope_expansion",
    label: "Expand scope coverage",
    icon: "🗺️",
    prompt: "Based on the current scope, identify adjacent assets, subsidiaries, and third-party integrations that could be tested. Provide specific tool commands.",
  },
  {
    id: "cvss_calculator",
    label: "CVSS score this finding",
    icon: "📊",
    prompt: "Calculate the CVSS 3.1 score for my latest finding. Walk through each metric with reasoning and compare to similar disclosed CVEs.",
  },
  {
    id: "report_review",
    label: "Review draft report",
    icon: "📋",
    prompt: "Review my current findings report. Identify gaps, strengthen impact statements, and suggest improvements before I submit.",
  },
  {
    id: "jwt_attacks",
    label: "JWT attack methodology",
    icon: "🔑",
    prompt: "Walk me through JWT attack methodology: algorithm confusion, none algorithm, key injection, and how to test with jwt-tool commands.",
  },
  {
    id: "403_bypass",
    label: "403/401 bypass strategies",
    icon: "🚪",
    prompt: "Give me comprehensive 403/401 bypass techniques: path manipulation, header injection, method override, and specific nomore403/403fuzzer commands.",
  },
] as const;

type PresetID = typeof QUICK_PROMPTS[number]["id"];

export function AIAgent() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [preset, setPreset] = useState<PresetID>("recon_analysis");
  const bottomRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const sendMessage = async (content: string) => {
    if (!content.trim() || loading) return;

    const userMsg: Message = { role: "user", content, ts: Date.now() };
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("/api/v1/ai/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          preset,
          messages: [...messages, userMsg].map(m => ({
            role: m.role,
            content: m.content,
          })),
        }),
      });
      const json = await res.json();
      setMessages(prev => [
        ...prev,
        { role: "assistant", content: json.response, ts: Date.now() },
      ]);
    } catch (err) {
      setMessages(prev => [
        ...prev,
        {
          role: "assistant",
          content: "⚠ Failed to reach AI agent. Check your ANTHROPIC_API_KEY.",
          ts: Date.now(),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage(input);
    }
  };

  const useQuickPrompt = (p: typeof QUICK_PROMPTS[number]) => {
    setPreset(p.id);
    sendMessage(p.prompt);
  };

  return (
    <div className="flex h-full">
      {/* Left sidebar — quick prompts */}
      <div className="w-64 border-r border-[#1a2a32] bg-[#0a1015] flex flex-col flex-shrink-0">
        <div className="px-4 py-3 border-b border-[#1a2a32]">
          <div className="flex items-center gap-2">
            <Zap size={13} className="text-[#00e5cc]" />
            <span className="text-[10px] font-bold text-[#4a8a9a] tracking-widest">QUICK PROMPTS</span>
          </div>
          <div className="text-[9px] text-[#1a3a4a] mt-0.5">Zen Methodology · 8 templates</div>
        </div>

        <div className="flex-1 overflow-y-auto p-2 space-y-1">
          {QUICK_PROMPTS.map(p => (
            <button
              key={p.id}
              onClick={() => useQuickPrompt(p)}
              disabled={loading}
              className={cn(
                "w-full text-left px-3 py-2.5 rounded-lg text-xs transition-all duration-150",
                "flex items-start gap-2.5 group",
                preset === p.id
                  ? "bg-[#0a1f19] border border-[#1a4a3a] text-[#00e5cc]"
                  : "text-[#4a6a7a] hover:bg-[#0c1820] hover:text-[#8ab4c4] border border-transparent"
              )}
            >
              <span className="flex-shrink-0 text-sm leading-none">{p.icon}</span>
              <span className="leading-tight">{p.label}</span>
            </button>
          ))}
        </div>

        {/* Active preset indicator */}
        <div className="px-3 py-2 border-t border-[#1a2a32]">
          <div className="text-[9px] text-[#2a4a5a] tracking-widest">ACTIVE SYSTEM PROMPT</div>
          <div className="text-[10px] text-[#00e5cc] mt-0.5 font-mono">
            {QUICK_PROMPTS.find(p => p.id === preset)?.label}
          </div>
        </div>
      </div>

      {/* Chat area */}
      <div className="flex flex-col flex-1 min-w-0">
        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <Bot size={40} className="text-[#1a2a32] mb-4" />
              <div className="text-[#2a4a5a] text-sm font-semibold">AI Bug Bounty Agent</div>
              <div className="text-[#1a2a32] text-xs mt-1 max-w-xs">
                Select a quick prompt on the left or type your question below.
                The agent is configured with Zen methodology expertise.
              </div>
            </div>
          )}

          {messages.map((msg, i) => (
            <div
              key={i}
              className={cn(
                "flex gap-3 max-w-4xl",
                msg.role === "user" ? "ml-auto flex-row-reverse" : ""
              )}
            >
              {/* Avatar */}
              <div
                className={cn(
                  "w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5",
                  msg.role === "user"
                    ? "bg-[#1a2a32]"
                    : "bg-[#0a1f19] border border-[#1a4a3a]"
                )}
              >
                {msg.role === "user" ? (
                  <User size={12} className="text-[#4a8a9a]" />
                ) : (
                  <Bot size={12} className="text-[#00e5cc]" />
                )}
              </div>

              {/* Bubble */}
              <div
                className={cn(
                  "rounded-xl px-4 py-3 text-xs leading-relaxed max-w-3xl",
                  msg.role === "user"
                    ? "bg-[#0a1820] border border-[#1a3a4a] text-[#8ab4c4]"
                    : "bg-[#0a1015] border border-[#1a2a32] text-[#c8d8e0]"
                )}
              >
                {msg.role === "assistant" ? (
                  <MarkdownContent content={msg.content} />
                ) : (
                  <span>{msg.content}</span>
                )}
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex gap-3">
              <div className="w-7 h-7 rounded-full flex items-center justify-center bg-[#0a1f19] border border-[#1a4a3a]">
                <Bot size={12} className="text-[#00e5cc]" />
              </div>
              <div className="bg-[#0a1015] border border-[#1a2a32] rounded-xl px-4 py-3">
                <Loader2 size={14} className="text-[#00e5cc] animate-spin" />
              </div>
            </div>
          )}

          <div ref={bottomRef} />
        </div>

        {/* Input area */}
        <div className="border-t border-[#1a2a32] p-4 bg-[#080c0e]">
          <div className="flex gap-3 items-end">
            <textarea
              ref={textareaRef}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask about recon results, vulnerabilities, bypass techniques... (Shift+Enter for newline)"
              rows={2}
              className={cn(
                "flex-1 bg-[#0a1015] border border-[#1a2a32] rounded-xl px-4 py-3",
                "text-xs text-[#c8d8e0] placeholder-[#2a4a5a] font-mono resize-none",
                "focus:outline-none focus:border-[#00e5cc]/30 transition-colors"
              )}
            />
            <button
              onClick={() => sendMessage(input)}
              disabled={!input.trim() || loading}
              className={cn(
                "p-3 rounded-xl transition-all duration-150",
                "flex items-center justify-center",
                input.trim() && !loading
                  ? "bg-[#00e5cc] text-[#080c0e] hover:bg-[#20ffec] shadow-lg shadow-[#00e5cc]/20"
                  : "bg-[#0a1015] text-[#1a2a32] border border-[#1a2a32] cursor-not-allowed"
              )}
            >
              {loading ? (
                <Loader2 size={16} className="animate-spin" />
              ) : (
                <Send size={16} strokeWidth={2.5} />
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// Simple markdown renderer for code blocks and bold
function MarkdownContent({ content }: { content: string }) {
  // Split by code blocks
  const parts = content.split(/(```[\s\S]*?```)/g);

  return (
    <div className="space-y-2">
      {parts.map((part, i) => {
        if (part.startsWith("```")) {
          const lines = part.slice(3, -3).split("\n");
          const lang = lines[0] || "";
          const code = lines.slice(1).join("\n");
          return (
            <pre
              key={i}
              className="bg-[#080c0e] border border-[#1a2a32] rounded-lg p-3 text-[#00e5cc] overflow-x-auto"
            >
              {lang && (
                <div className="text-[9px] text-[#2a5a6a] mb-2 font-bold tracking-widest">
                  {lang.toUpperCase()}
                </div>
              )}
              <code>{code}</code>
            </pre>
          );
        }
        // Render **bold** and inline `code`
        const rendered = part
          .replace(/\*\*(.*?)\*\*/g, "<strong class='text-[#c8d8e0] font-bold'>$1</strong>")
          .replace(/`(.*?)`/g, "<code class='bg-[#080c0e] text-[#00e5cc] px-1 rounded'>$1</code>")
          .replace(/\n/g, "<br/>");
        return (
          <span key={i} dangerouslySetInnerHTML={{ __html: rendered }} />
        );
      })}
    </div>
  );
}
