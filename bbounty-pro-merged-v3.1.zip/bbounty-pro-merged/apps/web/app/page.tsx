"use client";

import { useState, useEffect } from "react";
import { PipelineHeader } from "@/components/pipeline/PipelineHeader";
import { StatsBar } from "@/components/pipeline/StatsBar";
import { ROEGate } from "@/components/roe/ROEGate";
import { ToolGrid } from "@/components/arsenal/ToolGrid";
import { LiveTerminal } from "@/components/terminal/LiveTerminal";
import { FindingsTable } from "@/components/findings/FindingsTable";
import { AIAgent } from "@/components/agent/AIAgent";
import { ReportTab } from "@/components/report/ReportTab";
import { PriorityDashboard } from "@/components/priority/PriorityDashboard";
import { DiffViewer } from "@/components/diff/DiffViewer";
import { RateLimitMonitor } from "@/components/priority/RateLimitMonitor";
import { useScanStore } from "@/lib/store";
import { useAuth } from "@/hooks/useAuth";
import { cn } from "@/lib/utils";
import {
  Shield, Zap, Target, FileText, Bot, Terminal,
  LayoutDashboard, GitCompare, Brain, Activity, Users, LogOut,
} from "lucide-react";
import { useRouter } from "next/navigation";

type Tab =
  | "pipeline" | "arsenal"   | "terminal"
  | "findings" | "priority"  | "diff"
  | "agent"    | "report"    | "ratelimit";

const TABS: { id: Tab; label: string; icon: typeof Shield; adminOnly?: boolean }[] = [
  { id: "pipeline",  label: "Pipeline",   icon: LayoutDashboard },
  { id: "arsenal",   label: "Arsenal",    icon: Zap },
  { id: "terminal",  label: "Terminal",   icon: Terminal },
  { id: "findings",  label: "Findings",   icon: Target },
  { id: "priority",  label: "Priority",   icon: Brain },
  { id: "diff",      label: "Delta",      icon: GitCompare },
  { id: "agent",     label: "AI Agent",   icon: Bot },
  { id: "report",    label: "Report",     icon: FileText },
  { id: "ratelimit", label: "Rate Limit", icon: Activity, adminOnly: true },
];

export default function DashboardPage() {
  const [activeTab, setActiveTab]   = useState<Tab>("pipeline");
  const [roeConfirmed, setRoeConfirmed] = useState(false);
  const { scanID, isScanning, stats, phase, roe } = useScanStore();
  const { user, loading, isAdmin, isHunter, logout } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!loading && !user) router.push("/login");
  }, [user, loading, router]);

  if (loading || !user) {
    return (
      <div className="min-h-screen bg-[#080c0e] flex items-center justify-center">
        <div className="text-[#00e5cc] text-sm font-mono animate-pulse tracking-widest">
          AUTHENTICATING...
        </div>
      </div>
    );
  }

  const visibleTabs = TABS.filter(t => !t.adminOnly || isAdmin);

  return (
    <div className="min-h-screen bg-[#080c0e] text-[#c8d8e0] font-mono overflow-hidden">
      {!roeConfirmed && <ROEGate onConfirm={() => setRoeConfirmed(true)} />}

      <div className={cn("flex flex-col h-screen",
        !roeConfirmed && "blur-sm pointer-events-none select-none")}>
        <PipelineHeader phase={phase} isScanning={isScanning} scanID={scanID} />
        <StatsBar stats={stats} />

        {/* Nav */}
        <nav className="flex items-stretch border-b border-[#1a2a32] bg-[#0a1015] overflow-x-auto">
          <div className="flex flex-1">
            {visibleTabs.map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setActiveTab(id)}
                className={cn(
                  "flex items-center gap-2 px-4 py-3 text-xs font-semibold",
                  "uppercase tracking-widest border-b-2 -mb-px whitespace-nowrap",
                  "transition-all duration-150",
                  activeTab === id
                    ? "border-[#00e5cc] text-[#00e5cc]"
                    : "border-transparent text-[#4a6a7a] hover:text-[#8ab4c4]"
                )}
              >
                <Icon size={13} strokeWidth={2.5} />
                {label}
                {id === "findings" && stats.vulns > 0 && (
                  <span className="ml-1 px-1.5 py-0.5 text-[10px] bg-[#ff3a5c]/20 text-[#ff3a5c] rounded border border-[#ff3a5c]/30">
                    {stats.vulns}
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* User row */}
          <div className="flex items-center gap-3 px-4 border-l border-[#1a2a32] flex-shrink-0">
            {isAdmin && (
              <button
                onClick={() => router.push("/team")}
                className="p-1.5 text-[#2a5a6a] hover:text-[#4a8a9a] transition-colors"
                title="Team management"
              >
                <Users size={14} />
              </button>
            )}
            <div className="text-[10px]">
              <span className="text-[#4a8a9a]">{user.username}</span>
              <span className="text-[#1a3a4a] mx-1">·</span>
              <span className={cn("font-bold",
                user.role === "admin"  && "text-[#ff3a5c]",
                user.role === "hunter" && "text-[#00e5cc]",
                user.role === "viewer" && "text-[#4a6a7a]"
              )}>
                {user.role}
              </span>
            </div>
            <button
              onClick={logout}
              className="p-1.5 text-[#2a4a5a] hover:text-[#ff3a5c] transition-colors"
              title="Sign out"
            >
              <LogOut size={13} />
            </button>
          </div>
        </nav>

        {/* Content */}
        <main className="flex-1 overflow-hidden">
          {activeTab === "pipeline"  && <PipelineView isHunter={isHunter} />}
          {activeTab === "arsenal"   && <ToolGrid />}
          {activeTab === "terminal"  && <LiveTerminal scanID={scanID} />}
          {activeTab === "findings"  && <FindingsTable scanID={scanID} />}
          {activeTab === "priority"  && <PriorityDashboard scanID={scanID} />}
          {activeTab === "diff"      && <DiffViewer target={roe?.target} scanID={scanID} />}
          {activeTab === "agent"     && <AIAgent />}
          {activeTab === "report"    && <ReportTab scanID={scanID} />}
          {activeTab === "ratelimit" && <RateLimitMonitor />}
        </main>
      </div>
    </div>
  );
}

// ── Pipeline overview tab ──────────────────────────────────────────────────────

function PipelineView({ isHunter }: { isHunter: boolean }) {
  const { phase, isScanning } = useScanStore();

  const phases = [
    {
      id: "ANALYZE", label: "Analyze", color: "#00e5cc",
      desc: "Recon · OSINT · Fingerprinting",
      tools: ["subfinder", "assetfinder", "bbot", "whatweb", "wafw00f", "gitleaks"],
    },
    {
      id: "PLAN", label: "Plan", color: "#7c6aff",
      desc: "Enumeration · Port Scan · Crawl",
      tools: ["httpx", "naabu", "aquatone", "hakrawler", "gospider", "gf"],
    },
    {
      id: "EXECUTE", label: "Execute", color: "#ff9b3a",
      desc: "Vulnerability Scanning · Fuzzing",
      tools: ["nuclei", "ffuf", "wfuzz", "nikto", "403fuzzer", "nomore403", "graphw00f"],
    },
    {
      id: "ITERATE", label: "Iterate", color: "#ff3a5c",
      desc: "Exploitation · Validation",
      tools: ["commix", "corsy", "crlfuzz", "ssrfmap", "smuggler", "jwt-tool", "race-the-web"],
    },
  ];

  const currentIdx = phases.findIndex(p => p.id === phase);

  return (
    <div className="h-full overflow-y-auto p-6">
      <div className="grid grid-cols-4 gap-4 mb-6">
        {phases.map((p, i) => {
          const isActive = p.id === phase && isScanning;
          const isDone   = currentIdx > i && isScanning;
          return (
            <div
              key={p.id}
              className={cn(
                "relative border rounded-lg p-4 transition-all duration-300",
                isActive ? "border-current bg-current/5 shadow-lg shadow-current/10"
                  : isDone ? "border-[#1a4a3a] bg-[#0a1f19]/50"
                  : "border-[#1a2a32] bg-[#0a1015]/50"
              )}
              style={{ color: isActive ? p.color : undefined }}
            >
              <div className={cn("text-[10px] font-bold tracking-[0.3em] mb-1",
                isActive ? "opacity-100" : "opacity-40")}>
                PHASE {i + 1}
              </div>
              <div className="text-lg font-bold mb-0.5">
                {isActive && <span className="animate-pulse mr-1">▶</span>}
                {isDone   && <span className="mr-1 text-[#00e5cc]">✓</span>}
                {p.label}
              </div>
              <div className="text-[11px] text-[#4a6a7a] mb-3">{p.desc}</div>
              <div className="flex flex-wrap gap-1">
                {p.tools.map(t => (
                  <span key={t} className={cn(
                    "text-[10px] px-1.5 py-0.5 rounded border",
                    isActive ? "border-current/30 bg-current/10"
                      : isDone ? "border-[#1a4a3a] text-[#2a7a5a]"
                      : "border-[#1a2a32] text-[#2a4a5a]"
                  )}>
                    {t}
                  </span>
                ))}
              </div>
              {isActive && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 rounded-b-lg overflow-hidden">
                  <div
                    className="h-full w-full"
                    style={{
                      background: `linear-gradient(90deg, transparent, ${p.color}, transparent)`,
                      animation: "slide 2s linear infinite",
                    }}
                  />
                </div>
              )}
            </div>
          );
        })}
      </div>

      <style>{`
        @keyframes slide { from { transform: translateX(-100%); } to { transform: translateX(100%); } }
      `}</style>

      {isHunter ? (
        isScanning ? (
          <div className="flex gap-3">
            <button
              onClick={() => useScanStore.getState().pauseScan()}
              className="px-5 py-2.5 rounded-lg border border-[#ff9b3a]/40 text-[#ff9b3a] text-sm font-semibold hover:bg-[#ff9b3a]/10 transition-colors"
            >
              ⏸ Pause
            </button>
            <button
              onClick={() => useScanStore.getState().stopScan()}
              className="px-5 py-2.5 rounded-lg border border-[#ff3a5c]/40 text-[#ff3a5c] text-sm font-semibold hover:bg-[#ff3a5c]/10 transition-colors"
            >
              ⏹ Stop
            </button>
          </div>
        ) : (
          <button
            onClick={() => useScanStore.getState().startScan()}
            className="flex items-center gap-2 px-8 py-3 rounded-lg font-bold text-sm tracking-widest uppercase bg-[#00e5cc] text-[#080c0e] hover:bg-[#20ffec] transition-all shadow-lg shadow-[#00e5cc]/20 active:scale-95"
          >
            <Zap size={16} strokeWidth={2.5} />
            Launch Scan
          </button>
        )
      ) : (
        <div className="text-[11px] text-[#2a4a5a] italic">
          Viewer access — scans can be observed but not launched.
        </div>
      )}
    </div>
  );
}
