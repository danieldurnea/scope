"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Shield, Eye, EyeOff, Loader2, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";

type AuthMode = "login" | "register";

export default function LoginPage() {
  const router = useRouter();
  const [mode, setMode] = useState<AuthMode>("login");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const [form, setForm] = useState({
    username: "",
    email: "",
    password: "",
    inviteCode: "",
  });

  const setField = (k: keyof typeof form) =>
    (e: React.ChangeEvent<HTMLInputElement>) =>
      setForm(p => ({ ...p, [k]: e.target.value }));

  const submit = async () => {
    setError("");
    setLoading(true);
    try {
      const endpoint = mode === "login" ? "/auth/login" : "/auth/register";
      const body =
        mode === "login"
          ? { username: form.username, password: form.password }
          : {
              username: form.username,
              email: form.email,
              password: form.password,
              invite_code: form.inviteCode || undefined,
            };

      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Request failed");

      // Store tokens
      localStorage.setItem("access_token", json.access_token);
      localStorage.setItem("refresh_token", json.refresh_token);
      localStorage.setItem("user", JSON.stringify(json.user));

      router.push("/");
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") submit();
  };

  return (
    <div className="min-h-screen bg-[#080c0e] flex items-center justify-center p-4">
      {/* Background grid */}
      <div
        className="fixed inset-0 opacity-[0.03]"
        style={{
          backgroundImage:
            "linear-gradient(#00e5cc 1px, transparent 1px), linear-gradient(90deg, #00e5cc 1px, transparent 1px)",
          backgroundSize: "40px 40px",
        }}
      />

      <div className="w-full max-w-sm relative">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-xl bg-[#0a1f19] border border-[#00e5cc]/20 mb-4 shadow-lg shadow-[#00e5cc]/10">
            <Shield size={28} className="text-[#00e5cc]" strokeWidth={1.5} />
          </div>
          <div className="text-xl font-bold tracking-[0.1em] text-[#c8d8e0]">
            BBOUNTY<span className="text-[#00e5cc]">·PRO</span>
          </div>
          <div className="text-[10px] text-[#2a5a6a] tracking-[0.3em] mt-1">
            AI-POWERED BUG BOUNTY AGENT
          </div>
        </div>

        {/* Card */}
        <div className="bg-[#0a1015] border border-[#1a2a32] rounded-xl overflow-hidden shadow-2xl shadow-black/60">
          {/* Mode tabs */}
          <div className="flex border-b border-[#1a2a32]">
            {(["login", "register"] as const).map(m => (
              <button
                key={m}
                onClick={() => { setMode(m); setError(""); }}
                className={cn(
                  "flex-1 py-3 text-xs font-semibold tracking-widest uppercase transition-all",
                  mode === m
                    ? "text-[#00e5cc] border-b-2 border-[#00e5cc] bg-[#00e5cc]/5"
                    : "text-[#2a5a6a] hover:text-[#4a8a9a]"
                )}
              >
                {m === "login" ? "Sign In" : "Register"}
              </button>
            ))}
          </div>

          <div className="p-6 space-y-4" onKeyDown={handleKeyDown}>
            {/* Username */}
            <Field
              label="USERNAME"
              type="text"
              value={form.username}
              onChange={setField("username")}
              placeholder="hunter"
              autoFocus
            />

            {/* Email (register only) */}
            {mode === "register" && (
              <Field
                label="EMAIL"
                type="email"
                value={form.email}
                onChange={setField("email")}
                placeholder="hunter@example.com"
              />
            )}

            {/* Password */}
            <div>
              <label className="block text-[10px] text-[#4a6a7a] tracking-widest mb-1.5">
                PASSWORD
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={form.password}
                  onChange={setField("password")}
                  placeholder={mode === "register" ? "min. 8 characters" : "••••••••"}
                  className={inputCls + " pr-10"}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#2a5a6a] hover:text-[#4a8a9a]"
                >
                  {showPassword ? <EyeOff size={14} /> : <Eye size={14} />}
                </button>
              </div>
            </div>

            {/* Invite code (register, non-first users) */}
            {mode === "register" && (
              <Field
                label="INVITE CODE (required for team members)"
                type="text"
                value={form.inviteCode}
                onChange={setField("inviteCode")}
                placeholder="Leave empty if you're the first user"
              />
            )}

            {/* Error */}
            {error && (
              <div className="flex items-start gap-2 p-3 rounded-lg bg-[#1f0a0e] border border-[#ff3a5c]/30 text-xs text-[#ff3a5c]">
                <AlertTriangle size={13} className="flex-shrink-0 mt-0.5" />
                {error}
              </div>
            )}

            {/* Submit */}
            <button
              onClick={submit}
              disabled={loading || !form.username || !form.password}
              className={cn(
                "w-full py-3 rounded-lg text-sm font-bold tracking-widest uppercase transition-all",
                "disabled:opacity-40 disabled:cursor-not-allowed",
                "bg-[#00e5cc] text-[#080c0e] hover:bg-[#20ffec]",
                "shadow-lg shadow-[#00e5cc]/20 hover:shadow-[#00e5cc]/40",
                "active:scale-[0.98]"
              )}
            >
              {loading ? (
                <Loader2 size={16} className="animate-spin mx-auto" />
              ) : mode === "login" ? (
                "Sign In →"
              ) : (
                "Create Account →"
              )}
            </button>

            {/* Info */}
            {mode === "register" && (
              <p className="text-[10px] text-[#2a4a5a] text-center leading-relaxed">
                First account created becomes <span className="text-[#00e5cc]">admin</span>.
                Subsequent accounts need an invite code from an admin.
              </p>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="text-center mt-4 text-[10px] text-[#1a2a32]">
          Authorized testing only · BBounty Pro v2.1
        </div>
      </div>
    </div>
  );
}

const inputCls =
  "w-full bg-[#080c0e] border border-[#1a2a32] rounded-lg px-3 py-2.5 " +
  "text-xs text-[#c8d8e0] placeholder-[#1a3a4a] font-mono " +
  "focus:outline-none focus:border-[#00e5cc]/40 transition-colors";

function Field({
  label, type, value, onChange, placeholder, autoFocus,
}: {
  label: string;
  type: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  placeholder?: string;
  autoFocus?: boolean;
}) {
  return (
    <div>
      <label className="block text-[10px] text-[#4a6a7a] tracking-widest mb-1.5">
        {label}
      </label>
      <input
        type={type}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        autoFocus={autoFocus}
        className={inputCls}
      />
    </div>
  );
}
