"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";
import { Users, UserPlus, Copy, CheckCircle, Shield, Eye, Zap, Trash2 } from "lucide-react";
import useSWR, { mutate } from "swr";

const fetcher = (url: string) =>
  fetch(url, {
    headers: { Authorization: `Bearer ${localStorage.getItem("access_token")}` },
  }).then(r => r.json());

interface TeamMember {
  id: string;
  username: string;
  email: string;
  role: "admin" | "hunter" | "viewer";
  active: boolean;
  created_at: string;
  last_login_at?: string;
}

const ROLE_META = {
  admin:  { label: "Admin",  color: "#ff3a5c", icon: Shield, desc: "Full access + team management" },
  hunter: { label: "Hunter", color: "#00e5cc", icon: Zap,    desc: "Run scans, manage own findings" },
  viewer: { label: "Viewer", color: "#4a8a9a", icon: Eye,    desc: "Read-only access to all findings" },
};

export default function TeamPage() {
  const { data: members = [], isLoading } = useSWR<TeamMember[]>("/auth/team", fetcher);
  const [inviteRole, setInviteRole] = useState<"hunter" | "viewer">("hunter");
  const [inviteCode, setInviteCode] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [generating, setGenerating] = useState(false);

  const generateInvite = async () => {
    setGenerating(true);
    try {
      const res = await fetch("/auth/invite", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("access_token")}`,
        },
        body: JSON.stringify({ role: inviteRole }),
      });
      const json = await res.json();
      setInviteCode(json.invite_code);
    } finally {
      setGenerating(false);
    }
  };

  const copyInvite = () => {
    if (!inviteCode) return;
    const url = `${window.location.origin}/login?invite=${inviteCode}&role=${inviteRole}`;
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const updateMember = async (id: string, updates: Partial<TeamMember>) => {
    await fetch(`/auth/team/${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${localStorage.getItem("access_token")}`,
      },
      body: JSON.stringify(updates),
    });
    mutate("/auth/team");
  };

  return (
    <div className="min-h-screen bg-[#080c0e] p-6">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center gap-3">
          <Users size={20} className="text-[#00e5cc]" />
          <div>
            <div className="text-sm font-bold text-[#c8d8e0] tracking-wide">TEAM MANAGEMENT</div>
            <div className="text-[10px] text-[#2a5a6a] tracking-widest">
              {members.length} member{members.length !== 1 ? "s" : ""}
            </div>
          </div>
        </div>

        {/* Invite section */}
        <div className="bg-[#0a1015] border border-[#1a2a32] rounded-xl p-5">
          <div className="flex items-center gap-2 mb-4">
            <UserPlus size={15} className="text-[#00e5cc]" />
            <span className="text-xs font-bold text-[#c8d8e0] tracking-wide">INVITE TEAM MEMBER</span>
          </div>

          <div className="flex items-end gap-3 flex-wrap">
            <div>
              <label className="block text-[10px] text-[#4a6a7a] tracking-widest mb-1.5">ROLE</label>
              <div className="flex gap-2">
                {(["hunter", "viewer"] as const).map(role => {
                  const meta = ROLE_META[role];
                  return (
                    <button
                      key={role}
                      onClick={() => setInviteRole(role)}
                      className={cn(
                        "px-3 py-2 rounded-lg text-xs font-semibold border transition-all",
                        inviteRole === role
                          ? "border-current bg-current/10"
                          : "border-[#1a2a32] text-[#4a6a7a]"
                      )}
                      style={{ color: inviteRole === role ? meta.color : undefined }}
                    >
                      {meta.label}
                    </button>
                  );
                })}
              </div>
            </div>

            <button
              onClick={generateInvite}
              disabled={generating}
              className={cn(
                "px-5 py-2 rounded-lg text-xs font-bold tracking-widest",
                "bg-[#00e5cc] text-[#080c0e] hover:bg-[#20ffec]",
                "disabled:opacity-50 transition-all"
              )}
            >
              {generating ? "Generating..." : "Generate Invite Link"}
            </button>
          </div>

          {inviteCode && (
            <div className="mt-4 p-3 bg-[#080c0e] border border-[#00e5cc]/20 rounded-lg">
              <div className="text-[10px] text-[#2a5a6a] mb-1.5">INVITE LINK (valid 48h)</div>
              <div className="flex items-center gap-2">
                <code className="flex-1 text-[11px] text-[#00e5cc] font-mono truncate">
                  {window.location.origin}/login?invite={inviteCode}&role={inviteRole}
                </code>
                <button
                  onClick={copyInvite}
                  className="flex-shrink-0 p-1.5 rounded border border-[#1a2a32] text-[#4a6a7a] hover:text-[#00e5cc] transition-colors"
                >
                  {copied ? <CheckCircle size={13} className="text-[#00e5cc]" /> : <Copy size={13} />}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Member list */}
        <div className="bg-[#0a1015] border border-[#1a2a32] rounded-xl overflow-hidden">
          <div className="px-5 py-3 border-b border-[#1a2a32] text-[10px] text-[#2a5a6a] tracking-widest font-semibold">
            MEMBERS
          </div>

          {isLoading ? (
            <div className="p-8 text-center text-[#2a4a5a] text-sm">Loading...</div>
          ) : (
            <div className="divide-y divide-[#0f1e28]">
              {members.map(member => {
                const roleMeta = ROLE_META[member.role] || ROLE_META.viewer;
                const RoleIcon = roleMeta.icon;

                return (
                  <div
                    key={member.id}
                    className={cn(
                      "flex items-center gap-4 px-5 py-4 transition-colors",
                      !member.active && "opacity-50"
                    )}
                  >
                    {/* Avatar */}
                    <div className="w-8 h-8 rounded-full bg-[#0c1820] border border-[#1a2a32] flex items-center justify-center flex-shrink-0">
                      <span className="text-xs font-bold text-[#4a8a9a]">
                        {member.username.slice(0, 2).toUpperCase()}
                      </span>
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-semibold text-[#c8d8e0]">{member.username}</span>
                        {!member.active && (
                          <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#1a0a0a] border border-[#4a1a1a] text-[#4a3a3a]">
                            DEACTIVATED
                          </span>
                        )}
                      </div>
                      <div className="text-[11px] text-[#2a5a6a]">{member.email}</div>
                    </div>

                    {/* Role selector */}
                    <select
                      value={member.role}
                      onChange={e => updateMember(member.id, { role: e.target.value as any })}
                      className={cn(
                        "text-[11px] font-semibold px-2 py-1 rounded border bg-transparent",
                        "focus:outline-none cursor-pointer transition-colors"
                      )}
                      style={{ color: roleMeta.color, borderColor: roleMeta.color + "40" }}
                    >
                      {Object.entries(ROLE_META).map(([r, m]) => (
                        <option key={r} value={r}>{m.label}</option>
                      ))}
                    </select>

                    {/* Last login */}
                    <div className="text-[10px] text-[#2a4a5a] w-24 text-right">
                      {member.last_login_at
                        ? new Date(member.last_login_at).toLocaleDateString()
                        : "Never"}
                    </div>

                    {/* Deactivate */}
                    <button
                      onClick={() => updateMember(member.id, { active: !member.active })}
                      className="p-1.5 text-[#2a4a5a] hover:text-[#ff3a5c] transition-colors"
                      title={member.active ? "Deactivate" : "Reactivate"}
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Role legend */}
        <div className="grid grid-cols-3 gap-3">
          {Object.entries(ROLE_META).map(([role, meta]) => {
            const Icon = meta.icon;
            return (
              <div key={role} className="bg-[#0a1015] border border-[#1a2a32] rounded-lg p-3">
                <div className="flex items-center gap-2 mb-1">
                  <Icon size={12} style={{ color: meta.color }} />
                  <span className="text-[10px] font-bold tracking-wide" style={{ color: meta.color }}>
                    {meta.label.toUpperCase()}
                  </span>
                </div>
                <div className="text-[10px] text-[#2a5a6a] leading-relaxed">{meta.desc}</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
