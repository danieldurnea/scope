"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import { useRouter } from "next/navigation";

export interface AuthUser {
  id: string;
  username: string;
  email: string;
  role: "admin" | "hunter" | "viewer";
  active: boolean;
}

interface TokenStore {
  accessToken: string;
  refreshToken: string;
  expiresAt: string; // ISO timestamp
  user: AuthUser;
}

// ── Storage helpers (sessionStorage for security, not localStorage) ──────────
// Note: sessionStorage is cleared when tab closes — tokens don't persist.
// For persistent sessions, switch to httpOnly cookies (server-side).

function saveTokens(tokens: TokenStore) {
  sessionStorage.setItem("bbounty_auth", JSON.stringify(tokens));
}

function loadTokens(): TokenStore | null {
  try {
    const raw = sessionStorage.getItem("bbounty_auth");
    if (!raw) return null;
    return JSON.parse(raw) as TokenStore;
  } catch {
    return null;
  }
}

function clearTokens() {
  sessionStorage.removeItem("bbounty_auth");
}

function isExpired(expiresAt: string): boolean {
  return Date.now() >= new Date(expiresAt).getTime() - 60_000; // 60s buffer
}

// ── useAuth hook ──────────────────────────────────────────────────────────────

export function useAuth() {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);
  const refreshTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const router = useRouter();

  // Schedule a proactive token refresh before expiry
  const scheduleRefresh = useCallback((expiresAt: string, refreshToken: string) => {
    if (refreshTimerRef.current) {
      clearTimeout(refreshTimerRef.current);
    }
    const msUntilExpiry = new Date(expiresAt).getTime() - Date.now();
    const refreshAt = Math.max(msUntilExpiry - 120_000, 5000); // 2min before expiry

    refreshTimerRef.current = setTimeout(async () => {
      try {
        const res = await fetch("/auth/refresh", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ refresh_token: refreshToken }),
        });
        if (!res.ok) throw new Error("refresh failed");
        const tokens = await res.json();
        saveTokens(tokens);
        setUser(tokens.user);
        scheduleRefresh(tokens.expires_at, tokens.refresh_token);
      } catch {
        clearTokens();
        setUser(null);
        router.push("/login");
      }
    }, refreshAt);
  }, [router]);

  // Bootstrap: load persisted session
  useEffect(() => {
    const tokens = loadTokens();
    if (!tokens) {
      setLoading(false);
      return;
    }
    if (isExpired(tokens.expiresAt)) {
      // Expired — try refresh immediately
      fetch("/auth/refresh", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ refresh_token: tokens.refreshToken }),
      })
        .then(r => r.ok ? r.json() : Promise.reject())
        .then(newTokens => {
          saveTokens(newTokens);
          setUser(newTokens.user);
          scheduleRefresh(newTokens.expires_at, newTokens.refresh_token);
        })
        .catch(() => {
          clearTokens();
          router.push("/login");
        })
        .finally(() => setLoading(false));
    } else {
      setUser(tokens.user);
      scheduleRefresh(tokens.expiresAt, tokens.refreshToken);
      setLoading(false);
    }

    return () => {
      if (refreshTimerRef.current) clearTimeout(refreshTimerRef.current);
    };
  }, [scheduleRefresh, router]);

  // Returns the current Bearer token, refreshing if needed
  const getToken = useCallback((): string => {
    const tokens = loadTokens();
    return tokens?.accessToken ?? "";
  }, []);

  const login = useCallback(async (username: string, password: string) => {
    const res = await fetch("/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error ?? "Login failed");
    }
    const tokens = await res.json();
    saveTokens({
      accessToken:  tokens.access_token,
      refreshToken: tokens.refresh_token,
      expiresAt:    tokens.expires_at,
      user:         tokens.user,
    });
    setUser(tokens.user);
    scheduleRefresh(tokens.expires_at, tokens.refresh_token);
    return tokens.user as AuthUser;
  }, [scheduleRefresh]);

  const register = useCallback(async (
    username: string, email: string, password: string, inviteCode?: string
  ) => {
    const res = await fetch("/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, email, password, invite_code: inviteCode }),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err.error ?? "Registration failed");
    }
    const tokens = await res.json();
    saveTokens({
      accessToken:  tokens.access_token,
      refreshToken: tokens.refresh_token,
      expiresAt:    tokens.expires_at,
      user:         tokens.user,
    });
    setUser(tokens.user);
    scheduleRefresh(tokens.expires_at, tokens.refresh_token);
    return tokens.user as AuthUser;
  }, [scheduleRefresh]);

  const logout = useCallback(() => {
    clearTokens();
    setUser(null);
    if (refreshTimerRef.current) clearTimeout(refreshTimerRef.current);
    router.push("/login");
  }, [router]);

  const isAdmin   = user?.role === "admin";
  const isHunter  = user?.role === "hunter" || user?.role === "admin";
  const isViewer  = user !== null; // all authenticated users can view

  return {
    user,
    loading,
    isAdmin,
    isHunter,
    isViewer,
    getToken,
    login,
    register,
    logout,
  };
}

// ── authFetch — typed fetch with auto Bearer token ────────────────────────────

export async function authFetch<T>(
  path: string,
  init?: RequestInit
): Promise<T> {
  const tokens = loadTokens();
  const res = await fetch(path, {
    ...init,
    headers: {
      "Content-Type": "application/json",
      ...(tokens ? { Authorization: `Bearer ${tokens.accessToken}` } : {}),
      ...(init?.headers ?? {}),
    },
  });

  if (res.status === 401) {
    clearTokens();
    window.location.href = "/login";
    throw new Error("Session expired");
  }

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error ?? `HTTP ${res.status}`);
  }

  if (res.status === 204) return undefined as T;
  return res.json();
}

// ── authSWRFetcher — for useSWR with auth ────────────────────────────────────

export const authSWRFetcher = (url: string) => authFetch(url);

// ── withAuth HOC for page-level protection ────────────────────────────────────
// Usage: export default withAuth(MyPage, { requireRole: "admin" })

export function withAuth<P extends object>(
  Component: React.ComponentType<P>,
  options?: { requireRole?: "admin" | "hunter" }
) {
  return function AuthGuard(props: P) {
    const { user, loading, isAdmin, isHunter } = useAuth();
    const router = useRouter();

    useEffect(() => {
      if (loading) return;
      if (!user) {
        router.push("/login");
        return;
      }
      if (options?.requireRole === "admin" && !isAdmin) {
        router.push("/");
      }
      if (options?.requireRole === "hunter" && !isHunter) {
        router.push("/");
      }
    }, [user, loading, isAdmin, isHunter, router]);

    if (loading) {
      return (
        <div className="min-h-screen bg-[#080c0e] flex items-center justify-center">
          <div className="text-[#00e5cc] text-sm animate-pulse">Loading...</div>
        </div>
      );
    }

    if (!user) return null;

    return <Component {...props} />;
  };
}
