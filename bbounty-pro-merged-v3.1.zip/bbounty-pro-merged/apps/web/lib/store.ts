import { create } from "zustand";
import { subscribeWithSelector } from "zustand/middleware";

interface LiveStats {
  subs: number;
  live: number;
  urls: number;
  vulns: number;
  elapsed: number;
}

interface ROEConfig {
  target: string;
  program: string;
  tester: string;
  scope: string[];
  excluded: string[];
  platform: string;
}

type Phase = "ANALYZE" | "PLAN" | "EXECUTE" | "ITERATE" | "IDLE";

interface ScanState {
  scanID: string | null;
  isScanning: boolean;
  isPaused: boolean;
  phase: Phase;
  stats: LiveStats;
  roe: ROEConfig | null;
  selectedTools: string[];
  wsConnected: boolean;

  // Actions
  setROE: (roe: ROEConfig) => void;
  setSelectedTools: (tools: string[]) => void;
  startScan: () => Promise<void>;
  stopScan: () => Promise<void>;
  pauseScan: () => Promise<void>;
  updateStats: (stats: Partial<LiveStats>) => void;
  setPhase: (phase: Phase) => void;
  setWsConnected: (v: boolean) => void;
  reset: () => void;
}

const DEFAULT_STATS: LiveStats = {
  subs: 0, live: 0, urls: 0, vulns: 0, elapsed: 0,
};

export const useScanStore = create<ScanState>()(
  subscribeWithSelector((set, get) => ({
    scanID: null,
    isScanning: false,
    isPaused: false,
    phase: "IDLE",
    stats: { ...DEFAULT_STATS },
    roe: null,
    selectedTools: [],
    wsConnected: false,

    setROE: (roe) => set({ roe }),

    setSelectedTools: (tools) => set({ selectedTools: tools }),

    startScan: async () => {
      const { roe, selectedTools } = get();
      if (!roe) return;

      try {
        const res = await fetch("/api/v1/scan/start", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            target:    roe.target,
            program:   roe.program,
            tester:    roe.tester,
            scope:     roe.scope,
            excluded:  roe.excluded,
            platform:  roe.platform,
            tool_ids:  selectedTools,
            max_concurrent: 8,
          }),
        });

        if (!res.ok) throw new Error("Failed to start scan");
        const json = await res.json();

        set({
          scanID:     json.scan_id,
          isScanning: true,
          isPaused:   false,
          phase:      "ANALYZE",
          stats:      { ...DEFAULT_STATS },
        });

        // Connect WebSocket for pipeline events
        get().connectPipelineWS(json.scan_id);
        get().connectStatsWS(json.scan_id);
      } catch (err) {
        console.error("Failed to start scan:", err);
      }
    },

    stopScan: async () => {
      const { scanID } = get();
      if (!scanID) return;
      await fetch(`/api/v1/scan/stop?scan_id=${scanID}`, { method: "POST" });
      set({ isScanning: false, phase: "IDLE" });
    },

    pauseScan: async () => {
      const { scanID, isPaused } = get();
      if (!scanID) return;
      await fetch(`/api/v1/scan/pause?scan_id=${scanID}`, { method: "POST" });
      set({ isPaused: !isPaused });
    },

    updateStats: (stats) =>
      set(s => ({ stats: { ...s.stats, ...stats } })),

    setPhase: (phase) => set({ phase }),

    setWsConnected: (wsConnected) => set({ wsConnected }),

    reset: () => set({
      scanID: null, isScanning: false, isPaused: false,
      phase: "IDLE", stats: { ...DEFAULT_STATS },
    }),

    // Internal: connect WebSocket for pipeline phase events
    connectPipelineWS: (scanID: string) => {
      const proto = window.location.protocol === "https:" ? "wss" : "ws";
      const ws = new WebSocket(`${proto}://${window.location.hostname}:8080/ws/pipeline/${scanID}`);

      ws.onopen = () => set({ wsConnected: true });
      ws.onclose = () => set({ wsConnected: false });

      ws.onmessage = (evt) => {
        try {
          const msg = JSON.parse(evt.data);
          if (msg.event === "phase_start") {
            set({ phase: msg.payload.phase as Phase });
          }
          if (msg.event === "tool_done" && msg.payload.status === "success") {
            // Could trigger UI notifications here
          }
        } catch { /* ignore parse errors */ }
      };
    },

    // Internal: connect WebSocket for live stats
    connectStatsWS: (scanID: string) => {
      const proto = window.location.protocol === "https:" ? "wss" : "ws";
      const ws = new WebSocket(`${proto}://${window.location.hostname}:8080/ws/stats/${scanID}`);

      ws.onmessage = (evt) => {
        try {
          const stats = JSON.parse(evt.data);
          set({
            stats: {
              subs:    stats.subs    || 0,
              live:    stats.live    || 0,
              urls:    stats.urls    || 0,
              vulns:   stats.vulns   || 0,
              elapsed: stats.elapsed || 0,
            },
            phase: stats.phase || get().phase,
          });
        } catch { /* ignore */ }
      };
    },
  }) as any)
);
