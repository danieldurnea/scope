#!/usr/bin/env bash
# =============================================================================
#  BBounty Pro v3 — Native Kali Linux Installer
#  =============================================================================
#  Installs and configures the entire stack on Kali Linux WITHOUT Docker:
#    - Redis (apt package, systemd-managed)
#    - Go 1.23 (latest stable from go.dev)
#    - Bun (Next.js runtime)
#    - PostgreSQL 16 (optional, for long-term findings)
#    - 100+ security tools (ProjectDiscovery suite, OWASP, custom)
#    - Builds and installs the orchestrator as a systemd service
#    - Builds the frontend and serves via systemd
#
#  Target: Kali Linux 2024.x+ / Debian 12+ / Ubuntu 22.04+
#
#  Usage:
#    sudo bash install-kali-native.sh           # full install
#    sudo bash install-kali-native.sh --tools-only      # only sec tools
#    sudo bash install-kali-native.sh --no-postgres     # skip Postgres
#    sudo bash install-kali-native.sh --uninstall       # clean removal
# =============================================================================
set -euo pipefail

# ── Colors & helpers ─────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

step()  { echo -e "\n${CYAN}${BOLD}[*]${NC} ${BOLD}$*${NC}"; }
ok()    { echo -e "  ${GREEN}✓${NC} $*"; }
warn()  { echo -e "  ${YELLOW}!${NC} $*"; }
err()   { echo -e "  ${RED}✗${NC} $*" >&2; }
die()   { err "$*"; exit 1; }

# ── Pre-flight ───────────────────────────────────────────────────────────────
[[ $EUID -ne 0 ]] && die "Run as root: sudo bash $0"

INSTALL_DIR="${INSTALL_DIR:-/opt/bbounty-pro}"
BBOUNTY_USER="${BBOUNTY_USER:-bbounty}"
LOG_FILE="/var/log/bbounty-install.log"
GO_VERSION="${GO_VERSION:-1.23.4}"
NODE_VERSION="${NODE_VERSION:-22}"

mkdir -p "$(dirname "$LOG_FILE")"
exec > >(tee -a "$LOG_FILE") 2>&1

# ── Argument parsing ─────────────────────────────────────────────────────────
TOOLS_ONLY=false
NO_POSTGRES=false
UNINSTALL=false

for arg in "$@"; do
  case $arg in
    --tools-only)  TOOLS_ONLY=true  ;;
    --no-postgres) NO_POSTGRES=true ;;
    --uninstall)   UNINSTALL=true   ;;
    -h|--help)
      sed -n '2,18p' "$0" | sed 's/^# \?//'
      exit 0
      ;;
    *) die "Unknown argument: $arg" ;;
  esac
done

# =============================================================================
#  UNINSTALL PATH
# =============================================================================
if $UNINSTALL; then
  step "Uninstalling BBounty Pro"
  systemctl stop bbounty-orchestrator bbounty-web 2>/dev/null || true
  systemctl disable bbounty-orchestrator bbounty-web 2>/dev/null || true
  rm -f /etc/systemd/system/bbounty-orchestrator.service
  rm -f /etc/systemd/system/bbounty-web.service
  systemctl daemon-reload
  rm -rf "$INSTALL_DIR"
  if id "$BBOUNTY_USER" &>/dev/null; then
    userdel -r "$BBOUNTY_USER" 2>/dev/null || true
  fi
  ok "Removed BBounty Pro (Redis/Postgres/tools left intact)"
  exit 0
fi

# =============================================================================
#  STEP 1: System update + base packages
# =============================================================================
step "Updating system packages"
apt-get update -qq
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
  curl wget git unzip jq build-essential pkg-config \
  ca-certificates gnupg openssl \
  python3 python3-pip python3-venv pipx \
  redis-server libpcap-dev libssl-dev libffi-dev \
  whois dnsutils net-tools iputils-ping \
  software-properties-common
ok "Base packages installed"

# =============================================================================
#  STEP 2: Install Go 1.23
# =============================================================================
step "Installing Go ${GO_VERSION}"
if [[ -x /usr/local/go/bin/go ]] && /usr/local/go/bin/go version | grep -q "$GO_VERSION"; then
  ok "Go ${GO_VERSION} already installed"
else
  cd /tmp
  ARCH="$(dpkg --print-architecture)"
  case $ARCH in
    amd64) GO_ARCH=amd64 ;;
    arm64) GO_ARCH=arm64 ;;
    *)     die "Unsupported architecture: $ARCH" ;;
  esac
  curl -fsSLo go.tar.gz "https://go.dev/dl/go${GO_VERSION}.linux-${GO_ARCH}.tar.gz"
  rm -rf /usr/local/go
  tar -C /usr/local -xzf go.tar.gz
  rm go.tar.gz
  cat > /etc/profile.d/golang.sh << 'EOF'
export PATH="/usr/local/go/bin:$HOME/go/bin:$PATH"
export GOPATH="$HOME/go"
EOF
  export PATH="/usr/local/go/bin:$PATH"
  ok "Go installed: $(/usr/local/go/bin/go version)"
fi

# =============================================================================
#  STEP 3: Install Node.js + Bun
# =============================================================================
step "Installing Node.js ${NODE_VERSION} and Bun"
if ! command -v node &>/dev/null || [[ "$(node -v | sed 's/v//;s/\..*//')" -lt "$NODE_VERSION" ]]; then
  curl -fsSL "https://deb.nodesource.com/setup_${NODE_VERSION}.x" | bash -
  apt-get install -y -qq nodejs
fi
ok "Node.js: $(node -v)"

if ! command -v bun &>/dev/null; then
  curl -fsSL https://bun.sh/install | bash
  export PATH="$HOME/.bun/bin:$PATH"
  cat > /etc/profile.d/bun.sh << 'EOF'
export PATH="$HOME/.bun/bin:$PATH"
EOF
fi
ok "Bun: $(/root/.bun/bin/bun --version 2>/dev/null || bun --version 2>/dev/null || echo 'installed')"

# =============================================================================
#  STEP 4: Configure Redis
# =============================================================================
if ! $TOOLS_ONLY; then
  step "Configuring Redis"
  systemctl enable --now redis-server
  # Bind only to localhost for security; orchestrator runs on same host
  if ! grep -q "^bind 127.0.0.1" /etc/redis/redis.conf; then
    sed -i 's/^bind .*/bind 127.0.0.1 ::1/' /etc/redis/redis.conf
    systemctl restart redis-server
  fi
  if redis-cli ping | grep -q PONG; then
    ok "Redis: PONG (port 6379, bound to localhost)"
  else
    die "Redis ping failed"
  fi
fi

# =============================================================================
#  STEP 5: Configure PostgreSQL (optional)
# =============================================================================
if ! $TOOLS_ONLY && ! $NO_POSTGRES; then
  step "Configuring PostgreSQL 16"
  apt-get install -y -qq postgresql postgresql-contrib
  systemctl enable --now postgresql

  PG_PASS=$(openssl rand -hex 24)
  sudo -u postgres psql -tc "SELECT 1 FROM pg_database WHERE datname='bbounty'" \
    | grep -q 1 || sudo -u postgres psql << SQL
CREATE DATABASE bbounty;
CREATE USER bbounty WITH PASSWORD '${PG_PASS}';
GRANT ALL PRIVILEGES ON DATABASE bbounty TO bbounty;
\c bbounty
GRANT ALL ON SCHEMA public TO bbounty;
SQL
  echo "$PG_PASS" > /root/.bbounty-pg-pass
  chmod 600 /root/.bbounty-pg-pass
  ok "PostgreSQL ready (password saved to /root/.bbounty-pg-pass)"
fi

# =============================================================================
#  STEP 6: Install security tools
# =============================================================================
step "Installing 100+ security tools"

# Install golang-based tools to /opt/bbounty-tools/bin (in PATH)
TOOLS_DIR=/opt/bbounty-tools
mkdir -p "$TOOLS_DIR/bin"
export GOBIN="$TOOLS_DIR/bin"
export GOPATH="$TOOLS_DIR/go"
mkdir -p "$GOPATH"
export PATH="$TOOLS_DIR/bin:/usr/local/go/bin:$PATH"

go_install() {
  local pkg=$1
  local name="${pkg##*/}"
  name="${name%@*}"
  if [[ -x "$TOOLS_DIR/bin/$name" ]]; then
    ok "  $name (cached)"
  else
    echo "  Installing $name..."
    GOBIN="$TOOLS_DIR/bin" /usr/local/go/bin/go install -ldflags="-s -w" "$pkg" 2>&1 \
      | grep -E "^(error|cannot)" || true
    [[ -x "$TOOLS_DIR/bin/$name" ]] && ok "  $name"
  fi
}

# ── Reconnaissance ────────────────────────────────────────────────────────
echo -e "\n  ${BOLD}Recon tools:${NC}"
go_install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest
go_install github.com/tomnomnom/assetfinder@latest
go_install github.com/owasp-amass/amass/v4/...@latest
go_install github.com/projectdiscovery/dnsx/cmd/dnsx@latest
go_install github.com/projectdiscovery/chaos-client/cmd/chaos@latest
go_install github.com/d3mondev/puredns/v2@latest
go_install github.com/projectdiscovery/shuffledns/cmd/shuffledns@latest

# ── HTTP probing ─────────────────────────────────────────────────────────
echo -e "\n  ${BOLD}HTTP/Probing:${NC}"
go_install github.com/projectdiscovery/httpx/cmd/httpx@latest
go_install github.com/projectdiscovery/naabu/v2/cmd/naabu@latest
go_install github.com/projectdiscovery/katana/cmd/katana@latest
go_install github.com/lc/gau/v2/cmd/gau@latest
go_install github.com/tomnomnom/waybackurls@latest
go_install github.com/jaeles-project/gospider@latest
go_install github.com/hakluke/hakrawler@latest

# ── Vulnerability scanning ──────────────────────────────────────────────
echo -e "\n  ${BOLD}Vulnerability scanners:${NC}"
go_install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest
go_install github.com/hahwul/dalfox/v2@latest
go_install github.com/ffuf/ffuf/v2@latest
go_install github.com/OJ/gobuster/v3@latest
go_install github.com/dwisiswant0/crlfuzz/cmd/crlfuzz@latest
go_install github.com/edoardottt/cariddi/cmd/cariddi@latest

# ── Parameter discovery + enumeration ───────────────────────────────────
echo -e "\n  ${BOLD}Parameters/enumeration:${NC}"
go_install github.com/Emoe/kxss@latest
go_install github.com/tomnomnom/qsreplace@latest
go_install github.com/tomnomnom/gf@latest
go_install github.com/tomnomnom/anew@latest
go_install github.com/tomnomnom/unfurl@latest
go_install github.com/tomnomnom/meg@latest
go_install github.com/devanshbatham/paramspider@latest 2>/dev/null || warn "  paramspider deferred to pip"

# ── Subdomain takeover ───────────────────────────────────────────────────
echo -e "\n  ${BOLD}Takeover detection:${NC}"
go_install github.com/LukaSikic/subzy@latest
go_install github.com/haccer/subjack@latest

# ── Secrets / git tools ──────────────────────────────────────────────────
echo -e "\n  ${BOLD}Secrets:${NC}"
go_install github.com/zricethezav/gitleaks/v8@latest
go_install github.com/trufflesecurity/trufflehog/v3@latest

# Update nuclei templates
echo -e "\n  ${BOLD}Updating nuclei templates...${NC}"
"$TOOLS_DIR/bin/nuclei" -update-templates -silent 2>/dev/null || warn "  template update failed"
ok "  nuclei templates"

# ── Python tools (via pipx isolation) ────────────────────────────────────
echo -e "\n  ${BOLD}Python tools (pipx):${NC}"
PIPX_HOME="$TOOLS_DIR/pipx" PIPX_BIN_DIR="$TOOLS_DIR/bin" pipx ensurepath 2>/dev/null || true

pip_install() {
  local pkg=$1
  echo "  Installing $pkg..."
  PIPX_HOME="$TOOLS_DIR/pipx" PIPX_BIN_DIR="$TOOLS_DIR/bin" \
    pipx install --force "$pkg" 2>&1 | grep -E "(error|installed)" || true
}

pip_install arjun
pip_install paramspider
pip_install xnLinkFinder
pip_install dirsearch
pip_install corscanner
pip_install graphw00f
pip_install graphql-cop || true
pip_install ssrfmap || true

# ── APT-installable tools ────────────────────────────────────────────────
echo -e "\n  ${BOLD}APT tools (Kali repos):${NC}"
APT_TOOLS=(
  nmap masscan dnsrecon
  whatweb wafw00f wpscan nikto sqlmap
  hydra john hashcat
  metasploit-framework
  jq xmlstarlet
)
for t in "${APT_TOOLS[@]}"; do
  if dpkg -s "$t" &>/dev/null; then
    ok "  $t (already installed)"
  else
    if apt-get install -y -qq "$t" 2>/dev/null; then
      ok "  $t"
    else
      warn "  $t not found in apt (skipping)"
    fi
  fi
done

# ── Wordlists ────────────────────────────────────────────────────────────
echo -e "\n  ${BOLD}Wordlists:${NC}"
WORDLISTS=/opt/bbounty-tools/wordlists
mkdir -p "$WORDLISTS"
if [[ ! -d "$WORDLISTS/SecLists" ]]; then
  echo "  Cloning SecLists..."
  git clone --depth 1 https://github.com/danielmiessler/SecLists.git "$WORDLISTS/SecLists" 2>&1 | tail -1
fi
ok "  SecLists at $WORDLISTS/SecLists"

# Symlink bins into /usr/local/bin for global access
ln -sf "$TOOLS_DIR/bin/"* /usr/local/bin/ 2>/dev/null || true

if $TOOLS_ONLY; then
  ok "Tools-only install complete"
  exit 0
fi

# =============================================================================
#  STEP 7: Create dedicated user + workspace
# =============================================================================
step "Creating service user '${BBOUNTY_USER}'"
if ! id "$BBOUNTY_USER" &>/dev/null; then
  useradd -r -s /bin/bash -d "$INSTALL_DIR" -m "$BBOUNTY_USER"
  ok "User '$BBOUNTY_USER' created"
else
  ok "User '$BBOUNTY_USER' exists"
fi

# =============================================================================
#  STEP 8: Copy / fetch project source
# =============================================================================
step "Setting up project at ${INSTALL_DIR}"
SRC_DIR="${SRC_DIR:-$(pwd)}"

if [[ -d "$SRC_DIR/apps/orchestrator" && -d "$SRC_DIR/apps/web" ]]; then
  ok "Source detected at $SRC_DIR"
  if [[ "$SRC_DIR" != "$INSTALL_DIR" ]]; then
    rsync -a --delete --exclude=node_modules --exclude=.next --exclude=bin "$SRC_DIR/" "$INSTALL_DIR/"
  fi
else
  warn "No source at $SRC_DIR — clone manually:"
  warn "  git clone <repo> $INSTALL_DIR"
  exit 1
fi

cd "$INSTALL_DIR"
chown -R "$BBOUNTY_USER:$BBOUNTY_USER" "$INSTALL_DIR"

# =============================================================================
#  STEP 9: Generate .env (preserves existing if present)
# =============================================================================
step "Configuring environment"
if [[ ! -f "$INSTALL_DIR/.env" ]]; then
  cp "$INSTALL_DIR/.env.example" "$INSTALL_DIR/.env"

  JWT=$(openssl rand -hex 32)
  sed -i "s|^JWT_SECRET=.*|JWT_SECRET=${JWT}|" "$INSTALL_DIR/.env"
  sed -i "s|^MODE=.*|MODE=local|" "$INSTALL_DIR/.env" 2>/dev/null || \
    echo "MODE=local" >> "$INSTALL_DIR/.env"
  sed -i "s|^BIND_ADDR=.*|BIND_ADDR=127.0.0.1|" "$INSTALL_DIR/.env"
  sed -i "s|^FRONTEND_URL=.*|FRONTEND_URL=http://127.0.0.1:3000|" "$INSTALL_DIR/.env"
  sed -i "s|^REDIS_URL=.*|REDIS_URL=redis://127.0.0.1:6379|" "$INSTALL_DIR/.env"
  sed -i "s|^DOCKER_MODE=.*|DOCKER_MODE=false|" "$INSTALL_DIR/.env"
  sed -i "s|^ENV=.*|ENV=local|" "$INSTALL_DIR/.env"

  if [[ -f /root/.bbounty-pg-pass ]]; then
    PG_PASS=$(cat /root/.bbounty-pg-pass)
    sed -i "s|^POSTGRES_PASSWORD=.*|POSTGRES_PASSWORD=${PG_PASS}|" "$INSTALL_DIR/.env"
    sed -i "s|^POSTGRES_HOST=.*|POSTGRES_HOST=127.0.0.1|" "$INSTALL_DIR/.env"
  fi

  ok ".env generated (Anthropic API key still needed — edit $INSTALL_DIR/.env)"
else
  ok ".env already exists (preserved)"
fi
chown "$BBOUNTY_USER:$BBOUNTY_USER" "$INSTALL_DIR/.env"
chmod 600 "$INSTALL_DIR/.env"

# =============================================================================
#  STEP 10: Build Go orchestrator
# =============================================================================
step "Building Go orchestrator"
cd "$INSTALL_DIR/apps/orchestrator"
sudo -u "$BBOUNTY_USER" -H bash -c "
  export PATH='/usr/local/go/bin:\$PATH'
  export GOPATH='\$HOME/go'
  go mod tidy
  CGO_ENABLED=0 go build -ldflags='-s -w' -o '$INSTALL_DIR/bin/orchestrator' ./cmd/server
"
ok "Orchestrator: $(ls -lh $INSTALL_DIR/bin/orchestrator | awk '{print $5}')"

# =============================================================================
#  STEP 11: Build frontend
# =============================================================================
step "Building Next.js frontend"
cd "$INSTALL_DIR/apps/web"
sudo -u "$BBOUNTY_USER" -H bash -c "
  export PATH='\$HOME/.bun/bin:/usr/local/go/bin:\$PATH'
  if [[ ! -d node_modules ]]; then
    bun install --no-progress 2>&1 | tail -3
  fi
  bun run build 2>&1 | tail -5
"
ok "Frontend built"

# =============================================================================
#  STEP 12: Install Python agent dependencies
# =============================================================================
step "Setting up Python agent venv"
if [[ -f "$INSTALL_DIR/apps/agents/python_runtime/requirements.txt" ]]; then
  python3 -m venv "$INSTALL_DIR/apps/agents/python_runtime/venv"
  "$INSTALL_DIR/apps/agents/python_runtime/venv/bin/pip" install --quiet --upgrade pip
  "$INSTALL_DIR/apps/agents/python_runtime/venv/bin/pip" install --quiet \
    -r "$INSTALL_DIR/apps/agents/python_runtime/requirements.txt"
  chown -R "$BBOUNTY_USER:$BBOUNTY_USER" "$INSTALL_DIR/apps/agents"
  ok "Python venv ready"
else
  warn "No requirements.txt — skipping Python setup"
fi

# =============================================================================
#  STEP 13: Install systemd services
# =============================================================================
step "Installing systemd services"

cat > /etc/systemd/system/bbounty-orchestrator.service << EOF
[Unit]
Description=BBounty Pro Orchestrator (Go)
After=network.target redis-server.service postgresql.service
Requires=redis-server.service

[Service]
Type=simple
User=${BBOUNTY_USER}
Group=${BBOUNTY_USER}
WorkingDirectory=${INSTALL_DIR}
EnvironmentFile=${INSTALL_DIR}/.env
ExecStart=${INSTALL_DIR}/bin/orchestrator
Restart=on-failure
RestartSec=5
StandardOutput=append:/var/log/bbounty-orchestrator.log
StandardError=append:/var/log/bbounty-orchestrator.log

# Hardening
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ReadWritePaths=${INSTALL_DIR} /var/log /tmp
ProtectHome=true
ProtectKernelTunables=true
ProtectKernelModules=true
ProtectControlGroups=true
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/bbounty-web.service << EOF
[Unit]
Description=BBounty Pro Frontend (Next.js)
After=network.target bbounty-orchestrator.service

[Service]
Type=simple
User=${BBOUNTY_USER}
Group=${BBOUNTY_USER}
WorkingDirectory=${INSTALL_DIR}/apps/web
EnvironmentFile=${INSTALL_DIR}/.env
Environment="PATH=/home/${BBOUNTY_USER}/.bun/bin:/usr/local/bin:/usr/bin"
ExecStart=/usr/bin/env bun run start
Restart=on-failure
RestartSec=5
StandardOutput=append:/var/log/bbounty-web.log
StandardError=append:/var/log/bbounty-web.log

[Install]
WantedBy=multi-user.target
EOF

# Install bun for the bbounty user too
sudo -u "$BBOUNTY_USER" -H bash -c '
  if [[ ! -x ~/.bun/bin/bun ]]; then
    curl -fsSL https://bun.sh/install | bash 2>&1 | tail -2
  fi
' || warn "Bun setup for $BBOUNTY_USER failed (will use system bun)"

# Log files
touch /var/log/bbounty-orchestrator.log /var/log/bbounty-web.log
chown "$BBOUNTY_USER:$BBOUNTY_USER" /var/log/bbounty-*.log

systemctl daemon-reload
systemctl enable bbounty-orchestrator bbounty-web
ok "Services installed (not started — fill in .env first)"

# =============================================================================
#  FINAL: summary
# =============================================================================
clear
cat << EOF

${BOLD}${GREEN}╔═════════════════════════════════════════════════════════════╗${NC}
${BOLD}${GREEN}║           BBounty Pro v3 — Native Kali Install Complete    ║${NC}
${BOLD}${GREEN}╚═════════════════════════════════════════════════════════════╝${NC}

${BOLD}Project:${NC}        ${INSTALL_DIR}
${BOLD}Service user:${NC}   ${BBOUNTY_USER}
${BOLD}Mode:${NC}           local (MODE=local in .env)
${BOLD}Logs:${NC}           /var/log/bbounty-*.log
${BOLD}Tools:${NC}          /opt/bbounty-tools/bin (symlinked to /usr/local/bin)
${BOLD}Wordlists:${NC}      /opt/bbounty-tools/wordlists/SecLists

${BOLD}${YELLOW}NEXT STEPS:${NC}

1. Edit your environment file:
   ${CYAN}sudoedit ${INSTALL_DIR}/.env${NC}
   - Set ANTHROPIC_API_KEY (required for AI features)

2. Start the services:
   ${CYAN}systemctl start bbounty-orchestrator${NC}
   ${CYAN}systemctl start bbounty-web${NC}

3. Check status:
   ${CYAN}systemctl status bbounty-orchestrator${NC}
   ${CYAN}journalctl -u bbounty-orchestrator -f${NC}

4. Open in browser:
   ${CYAN}http://127.0.0.1:3000${NC}

5. First registered account becomes admin.

${BOLD}Useful commands:${NC}
   ${CYAN}make local-dev${NC}      — start in dev mode (foreground, hot reload)
   ${CYAN}make local-stop${NC}     — stop services
   ${CYAN}make local-logs${NC}     — tail orchestrator + web logs
   ${CYAN}make health${NC}         — check all services + tools

${BOLD}Tool sanity check:${NC}
   ${CYAN}bash ${INSTALL_DIR}/scripts/health-check.sh${NC}

EOF
