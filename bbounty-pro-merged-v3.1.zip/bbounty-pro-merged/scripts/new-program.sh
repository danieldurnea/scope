#!/usr/bin/env bash
# BBounty Pro — New Program Workspace Creator
# Mirrors: danieldurnea/BugBounty/scripts/new-program.sh (enhanced)
# Usage: ./scripts/new-program.sh <program-name> [target-domain]
set -euo pipefail

PROGRAM="${1:?Usage: $0 <program-name> [target-domain]}"
TARGET="${2:-}"
BASE_DIR="${BB_WORKSPACE:-$HOME/pentesting}"
PROGRAM_DIR="$BASE_DIR/$PROGRAM"

GREEN='\033[0;32m'; CYAN='\033[0;36m'; YELLOW='\033[1;33m'; NC='\033[0m'; BOLD='\033[1m'

echo -e "${BOLD}${CYAN}Creating workspace: $PROGRAM${NC}"

# ─── Directory structure ──────────────────────────────────────────────────────
mkdir -p "$PROGRAM_DIR"/{recon,findings,reports,screenshots,exploits,notes}
mkdir -p "$PROGRAM_DIR"/recon/{subs,live,urls,ports,vulns,js,params}

echo -e "${GREEN}✓${NC} Directories created: $PROGRAM_DIR"

# ─── target-info.md (mirrors danieldurnea docs/target-template.md) ─────────
cat > "$PROGRAM_DIR/target-info.md" << TARGETEOF
# Target: $PROGRAM
$([ -n "$TARGET" ] && echo "**Domain:** $TARGET")
**Created:** $(date +%Y-%m-%d)
**Platform:** <!-- HackerOne / Bugcrowd / Intigriti / Private -->
**Program URL:** 

## Scope

### In-Scope
\`\`\`
$([ -n "$TARGET" ] && echo "*.${TARGET}" || echo "# Add in-scope domains/IPs here")
\`\`\`

### Out-of-Scope
\`\`\`
# Add explicitly excluded assets here
\`\`\`

### Special Rules
- Rate limit: _____ req/sec
- Test accounts: Y / N
- DoS testing: NOT allowed
- Automated scanning: Y / N (check program rules)

## Bounty Information
| Severity | Reward Range |
|----------|-------------|
| Critical | \$___–\$___ |
| High     | \$___–\$___ |
| Medium   | \$___–\$___ |
| Low      | \$0–\$___ |

## Notes
<!-- Add program-specific notes here -->

## Progress
- [ ] Recon completed
- [ ] Subs enumerated
- [ ] HTTP probed
- [ ] Crawled
- [ ] Nuclei scanned
- [ ] Manual testing
- [ ] Findings documented
- [ ] Reports submitted
TARGETEOF
echo -e "${GREEN}✓${NC} target-info.md created"

# ─── .env (local scan config) ─────────────────────────────────────────────────
cat > "$PROGRAM_DIR/.env" << ENVEOF
# $PROGRAM — Scan Configuration
TARGET="${TARGET}"
PROGRAM="${PROGRAM}"
SCOPE="$([ -n "$TARGET" ] && echo "*.${TARGET}" || echo "")"
EXCLUDED=""
PLATFORM="hackerone"
TESTER="${USER}"
OUTDIR="$PROGRAM_DIR/recon"
RATE_LIMIT=30
THREADS=10
NOTIFY_WEBHOOK=
ENVEOF
echo -e "${GREEN}✓${NC} .env created"

# ─── findings template (mirrors danieldurnea docs/findings.md) ─────────────
cat > "$PROGRAM_DIR/findings/FINDINGS_TEMPLATE.md" << FINDEOF
# Findings — $PROGRAM

## Finding Template

---

### TITLE_HERE

**Severity:** CRITICAL / HIGH / MEDIUM / LOW  
**CVSS:** ___._ (CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H)  
**CWE:** CWE-XXX  
**Status:** New  
**URL:** \`https://...\`  
**Parameter:** \`param_name\`  
**Discovered by:** tool_name  

#### Description
_One paragraph explaining the vulnerability._

#### Impact
_Business impact — what can an attacker actually do?_

#### Steps to Reproduce
1. Navigate to \`URL\`
2. Send request with payload:
   \`\`\`
   GET /endpoint?param=PAYLOAD HTTP/1.1
   Host: target.com
   \`\`\`
3. Observe: _response showing vulnerability_

#### Proof of Concept
\`\`\`
# Copy-pasteable exploit
\`\`\`

#### Remediation
_Specific, actionable fix. Not just "sanitize input"._

#### References
- [CWE-XXX](https://cwe.mitre.org/data/definitions/XXX.html)
- [OWASP: ...](https://owasp.org/...)
FINDEOF
echo -e "${GREEN}✓${NC} Findings template created"

# ─── daily workflow (mirrors danieldurnea docs/workflow.md) ───────────────────
cat > "$PROGRAM_DIR/notes/WORKFLOW.md" << WFEOF
# Daily Workflow — $PROGRAM

## AI Responsibilities (automated overnight)
- Run recon pipeline: subfinder → httpx → nuclei
- Crawl new URLs and check for new parameters
- Monitor for new subdomains
- Scan with Nuclei templates (critical/high first)

## Human Responsibilities  
- Review AI findings and triage
- Manual business logic testing
- Chaining vulnerabilities
- Writing reports

## Morning Checklist
- [ ] Check delta (new subs, new vulns)
- [ ] Triage nuclei findings
- [ ] Review JS secrets
- [ ] Plan manual tests for today

## Stop Conditions
- [ ] Scope ambiguous → clarify before testing
- [ ] Action could cause harm → stop and consult
- [ ] Accessing real user data → stop immediately
- [ ] Legal/ethical concerns → stop and escalate
WFEOF
echo -e "${GREEN}✓${NC} Workflow guide created"

# ─── Quick-start script ────────────────────────────────────────────────────────
cat > "$PROGRAM_DIR/start-recon.sh" << RECONEOF
#!/usr/bin/env bash
# Quick recon for $PROGRAM
source .env
set -euo pipefail

echo "🎯 Starting recon for \$TARGET"
echo "📁 Output: \$OUTDIR"
echo ""

# Load the BBounty Pro recon pipeline
OUTDIR="\$OUTDIR/$(date +%Y%m%d_%H%M%S)" \\
SCOPE="\$SCOPE" \\
RATE_LIMIT="\$RATE_LIMIT" \\
    bash ~/bbounty-pro/scripts/recon-pipeline.sh "\$TARGET"
RECONEOF
chmod +x "$PROGRAM_DIR/start-recon.sh"
echo -e "${GREEN}✓${NC} Quick-start script created"

# ─── Git init ────────────────────────────────────────────────────────────────
cd "$PROGRAM_DIR"
git init -q
cat > .gitignore << GITEOF
.env
recon/
screenshots/
*.json
*.log
GITEOF
git add -A
git commit -q -m "init: $PROGRAM workspace" 2>/dev/null || true
echo -e "${GREEN}✓${NC} Git repository initialized"

# ─── Summary ──────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}${GREEN}Workspace ready! 🎯${NC}"
echo ""
echo -e "  ${CYAN}Location:${NC}  $PROGRAM_DIR"
echo -e "  ${CYAN}Target:${NC}    ${TARGET:-not set — edit target-info.md}"
echo ""
echo -e "  ${CYAN}Next steps:${NC}"
echo -e "    1. Edit ${BOLD}$PROGRAM_DIR/target-info.md${NC} — add scope"
echo -e "    2. cd $PROGRAM_DIR && ./start-recon.sh"
echo -e "    3. Open BBounty Pro agent: ${BOLD}http://localhost:3000${NC}"
echo ""
