#!/usr/bin/env bash
# BBounty Pro v3 MERGED — One-command VPS Installer
# Usage: curl -fsSL <repo>/scripts/install-vps.sh | bash
# Or:    bash install-vps.sh
set -euo pipefail

GREEN='\033[0;32m'; CYAN='\033[0;36m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'; BOLD='\033[1m'

check_root() {
  if [[ $EUID -ne 0 ]]; then
    echo -e "${RED}Run with sudo or as root.${NC}"
    exit 1
  fi
}

check_vps() {
  # Detect if running in a Docker container (already containerised)
  if grep -q docker /proc/1/cgroup 2>/dev/null; then
    echo -e "${RED}Cannot install inside a container. Run on the host VPS.${NC}"
    exit 1
  fi
  # Detect public IP
  local pub_ip
  pub_ip=$(curl -sf --max-time 5 https://api.ipify.org || echo "")
  if [[ -z "$pub_ip" ]]; then
    echo -e "${YELLOW}Warning: cannot detect public IP. Continuing anyway.${NC}"
  else
    echo -e "${GREEN}✓${NC} VPS public IP: ${BOLD}$pub_ip${NC}"
  fi
}

install_deps() {
  echo -e "${CYAN}[1/7]${NC} Installing system dependencies..."
  apt-get update -qq
  DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
    curl git ufw fail2ban unattended-upgrades \
    ca-certificates gnupg openssl jq
  echo -e "${GREEN}✓${NC} Dependencies installed"
}

install_docker() {
  if command -v docker &>/dev/null; then
    echo -e "${GREEN}✓${NC} Docker already installed: $(docker --version)"
    return
  fi
  echo -e "${CYAN}[2/7]${NC} Installing Docker..."
  curl -fsSL https://get.docker.com | sh
  systemctl enable --now docker
  echo -e "${GREEN}✓${NC} Docker installed"
}

setup_firewall() {
  echo -e "${CYAN}[3/7]${NC} Configuring UFW firewall..."
  ufw --force reset >/dev/null
  ufw default deny incoming
  ufw default allow outgoing
  ufw allow 22/tcp comment 'SSH'
  ufw allow 80/tcp comment 'HTTP'
  ufw allow 443/tcp comment 'HTTPS'
  ufw --force enable
  systemctl enable --now fail2ban
  echo -e "${GREEN}✓${NC} Firewall: 22, 80, 443 open"
}

install_caddy() {
  if command -v caddy &>/dev/null; then
    echo -e "${GREEN}✓${NC} Caddy already installed"
    return
  fi
  echo -e "${CYAN}[4/7]${NC} Installing Caddy reverse proxy..."
  apt install -y debian-keyring debian-archive-keyring apt-transport-https
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | \
    gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
  curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | \
    tee /etc/apt/sources.list.d/caddy-stable.list
  apt update -qq && apt install -y caddy
  echo -e "${GREEN}✓${NC} Caddy installed"
}

clone_project() {
  echo -e "${CYAN}[5/7]${NC} Cloning project to /opt/bbounty-pro..."
  if [[ -d /opt/bbounty-pro ]]; then
    echo -e "${YELLOW}!${NC} /opt/bbounty-pro exists — pulling latest"
    cd /opt/bbounty-pro && git pull
  else
    git clone "${BBOUNTY_REPO:-https://github.com/your-org/bbounty-pro.git}" /opt/bbounty-pro
  fi
  cd /opt/bbounty-pro
}

configure_env() {
  echo -e "${CYAN}[6/7]${NC} Configuring environment..."
  cd /opt/bbounty-pro

  if [[ ! -f .env ]]; then
    cp .env.example .env
  fi

  # Generate JWT secret
  if ! grep -q "^JWT_SECRET=.\+$" .env; then
    local jwt
    jwt=$(openssl rand -hex 32)
    sed -i "s|^JWT_SECRET=.*|JWT_SECRET=$jwt|" .env
    echo -e "${GREEN}✓${NC} JWT_SECRET generated"
  fi

  # Postgres password
  if ! grep -q "^POSTGRES_PASSWORD=.\+$" .env; then
    local pg
    pg=$(openssl rand -hex 24)
    sed -i "s|^POSTGRES_PASSWORD=.*|POSTGRES_PASSWORD=$pg|" .env
    echo -e "${GREEN}✓${NC} Postgres password generated"
  fi

  # Prompt for required values
  echo ""
  echo -e "${BOLD}Required configuration:${NC}"

  if ! grep -q "^ANTHROPIC_API_KEY=sk-" .env; then
    read -rp "Anthropic API key (starts with sk-ant-): " api_key
    if [[ -z "$api_key" ]]; then
      echo -e "${YELLOW}⚠️  No API key — AI features disabled. Set ANTHROPIC_API_KEY later in .env${NC}"
    else
      sed -i "s|^ANTHROPIC_API_KEY=.*|ANTHROPIC_API_KEY=$api_key|" .env
    fi
  fi

  if ! grep -q "^FRONTEND_URL=https://" .env; then
    read -rp "Your domain (e.g., bounty.yourdomain.com): " domain
    if [[ -n "$domain" ]]; then
      sed -i "s|^FRONTEND_URL=.*|FRONTEND_URL=https://$domain|" .env
      sed -i "s|^VPS_DOMAIN=.*|VPS_DOMAIN=$domain|" .env
      sed -i "s|^NEXT_PUBLIC_WS_HOST=.*|NEXT_PUBLIC_WS_HOST=$domain|" .env
      sed -i "s|^NEXT_PUBLIC_API_HOST=.*|NEXT_PUBLIC_API_HOST=$domain|" .env

      # Configure Caddy
      cat > /etc/caddy/Caddyfile <<CADDYEOF
$domain {
    reverse_proxy /api/* localhost:8080
    reverse_proxy /ws/* localhost:8080
    reverse_proxy /auth/* localhost:8080
    reverse_proxy /healthz localhost:8080
    reverse_proxy /* localhost:3000

    header {
        Strict-Transport-Security "max-age=31536000; includeSubDomains; preload"
        X-Content-Type-Options "nosniff"
        X-Frame-Options "DENY"
        Referrer-Policy "strict-origin-when-cross-origin"
        -Server
    }
    encode gzip zstd
}
CADDYEOF
      systemctl reload caddy || systemctl restart caddy
      echo -e "${GREEN}✓${NC} Caddy configured for $domain (auto-SSL)"
    fi
  fi

  chmod 600 .env
  echo -e "${GREEN}✓${NC} Environment ready (.env permissions: 600)"
}

start_stack() {
  echo -e "${CYAN}[7/7]${NC} Starting BBounty Pro stack..."
  cd /opt/bbounty-pro

  docker compose -f infra/docker-compose.yml pull --quiet
  docker compose -f infra/docker-compose.yml up -d --build

  # Wait for health
  echo -n "Waiting for orchestrator to start"
  for i in {1..30}; do
    if curl -sf http://localhost:8080/healthz | grep -q '"ok"'; then
      echo ""
      echo -e "${GREEN}✓${NC} Orchestrator healthy"
      return
    fi
    echo -n "."
    sleep 2
  done
  echo ""
  echo -e "${YELLOW}⚠️  Orchestrator not responding yet. Check: docker compose logs${NC}"
}

print_summary() {
  local domain=$(grep -E '^VPS_DOMAIN=' .env | cut -d= -f2)
  echo ""
  echo -e "${BOLD}${GREEN}═══════════════════════════════════════════════════════${NC}"
  echo -e "${BOLD}${GREEN}     BBounty Pro v3 Merged — Installed Successfully     ${NC}"
  echo -e "${BOLD}${GREEN}═══════════════════════════════════════════════════════${NC}"
  echo ""
  if [[ -n "$domain" ]]; then
    echo -e "  ${CYAN}URL:${NC}            https://$domain"
  else
    echo -e "  ${CYAN}URL:${NC}            http://$(curl -sf https://api.ipify.org):3000"
  fi
  echo -e "  ${CYAN}Project:${NC}        /opt/bbounty-pro"
  echo -e "  ${CYAN}Logs:${NC}           docker compose -f /opt/bbounty-pro/infra/docker-compose.yml logs -f"
  echo -e "  ${CYAN}Health:${NC}         curl http://localhost:8080/healthz"
  echo ""
  echo -e "${BOLD}Next steps:${NC}"
  echo "  1. Open the URL in your browser"
  echo "  2. Click Register — first account becomes admin"
  echo "  3. Generate invite codes for team via /team"
  echo "  4. Confirm ROE before first scan"
  echo ""
  echo -e "${YELLOW}Authorized testing only. Scanning unauthorized targets is illegal.${NC}"
  echo ""
}

main() {
  echo -e "${BOLD}${CYAN}"
  echo "╔════════════════════════════════════════════════════════╗"
  echo "║     BBounty Pro v3 Merged — VPS Installer              ║"
  echo "║     14 skills + Python agents + VPS-only enforcement   ║"
  echo "╚════════════════════════════════════════════════════════╝"
  echo -e "${NC}"

  check_root
  check_vps
  install_deps
  install_docker
  setup_firewall
  install_caddy
  clone_project
  configure_env
  start_stack
  print_summary
}

main "$@"
