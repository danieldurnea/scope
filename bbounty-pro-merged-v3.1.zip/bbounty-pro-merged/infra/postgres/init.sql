-- BBounty Pro — PostgreSQL schema
-- Findings and scan history (long-term storage, Redis is the hot cache)

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";  -- trigram index for fast text search

-- ─── Scans ────────────────────────────────────────────────────────────────────
CREATE TABLE scans (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    target      TEXT NOT NULL,
    program     TEXT,
    tester      TEXT,
    platform    TEXT,
    scope       TEXT[],
    excluded    TEXT[],
    status      TEXT NOT NULL DEFAULT 'queued'
                    CHECK (status IN ('queued','running','paused','done','failed','aborted')),
    phase       TEXT DEFAULT 'IDLE',
    subs_count  INTEGER DEFAULT 0,
    live_count  INTEGER DEFAULT 0,
    urls_count  INTEGER DEFAULT 0,
    vulns_count INTEGER DEFAULT 0,
    started_at  TIMESTAMPTZ DEFAULT NOW(),
    finished_at TIMESTAMPTZ,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_scans_target    ON scans (target);
CREATE INDEX idx_scans_status    ON scans (status);
CREATE INDEX idx_scans_created   ON scans (created_at DESC);

-- ─── Findings ─────────────────────────────────────────────────────────────────
CREATE TABLE findings (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    scan_id     UUID REFERENCES scans(id) ON DELETE CASCADE,
    title       TEXT NOT NULL,
    url         TEXT NOT NULL,
    severity    TEXT NOT NULL DEFAULT 'medium'
                    CHECK (severity IN ('critical','high','medium','low','info')),
    category    TEXT,
    parameter   TEXT,
    payload     TEXT,
    response    TEXT,
    status      TEXT NOT NULL DEFAULT 'new'
                    CHECK (status IN ('new','confirmed','duplicate','invalid','resolved')),
    cvss        NUMERIC(4,1),
    cvss_vector TEXT,
    source      TEXT DEFAULT 'manual',
    ai_analysis TEXT,
    tags        TEXT[],
    created_at  TIMESTAMPTZ DEFAULT NOW(),
    updated_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_findings_scan_id   ON findings (scan_id);
CREATE INDEX idx_findings_severity  ON findings (severity);
CREATE INDEX idx_findings_status    ON findings (status);
CREATE INDEX idx_findings_created   ON findings (created_at DESC);
-- Full text search on title + url
CREATE INDEX idx_findings_title_trgm ON findings USING gin(title gin_trgm_ops);
CREATE INDEX idx_findings_url_trgm   ON findings USING gin(url   gin_trgm_ops);

-- Auto-update updated_at trigger
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER findings_updated_at
    BEFORE UPDATE ON findings
    FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ─── Scan events log ──────────────────────────────────────────────────────────
CREATE TABLE scan_events (
    id          BIGSERIAL PRIMARY KEY,
    scan_id     UUID REFERENCES scans(id) ON DELETE CASCADE,
    event_type  TEXT NOT NULL,  -- 'phase_start','tool_start','tool_done','error'
    tool_id     TEXT,
    phase       TEXT,
    payload     JSONB,
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_events_scan_id  ON scan_events (scan_id);
CREATE INDEX idx_events_type     ON scan_events (event_type);
CREATE INDEX idx_events_created  ON scan_events (created_at DESC);

-- ─── Tool run history (for caching decisions) ─────────────────────────────────
CREATE TABLE tool_runs (
    id          BIGSERIAL PRIMARY KEY,
    scan_id     UUID REFERENCES scans(id) ON DELETE CASCADE,
    tool_id     TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'running'
                    CHECK (status IN ('running','success','error','timeout','skipped')),
    exit_code   INTEGER,
    started_at  TIMESTAMPTZ DEFAULT NOW(),
    finished_at TIMESTAMPTZ,
    duration_ms INTEGER GENERATED ALWAYS AS (
        CASE WHEN finished_at IS NOT NULL
            THEN EXTRACT(EPOCH FROM (finished_at - started_at))::INTEGER * 1000
            ELSE NULL
        END
    ) STORED,
    output_path TEXT
);

CREATE INDEX idx_tool_runs_scan   ON tool_runs (scan_id);
CREATE INDEX idx_tool_runs_tool   ON tool_runs (tool_id);

-- ─── Sample data (dev only) ───────────────────────────────────────────────────
-- INSERT INTO scans (target, program, tester, platform, scope, status)
-- VALUES ('example.com', 'Example Bug Bounty', 'hunter1', 'hackerone',
--         ARRAY['*.example.com', 'api.example.com'], 'done');
