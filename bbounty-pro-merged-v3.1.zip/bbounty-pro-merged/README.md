# BBounty Pro v3 MERGED

> **Bug Bounty + Pentesting Platform** — VPS-only deployment.
> Go orchestrator + Next.js 15 frontend + 14 skill modules + Python specialist agents + Kali tools container.

## What's in this merged release

- **Original BBounty Pro v3** — Go orchestrator, Next.js 15 frontend, 44 tools, ANALYZE→PLAN→EXECUTE→ITERATE pipeline
- **BountyHunter-Pro v3.0 ULTRA** — 14 skill modules + 7 specialist Python agents + 100+ tools methodology
- **VPS-only enforcement** — refuses to start on localhost (override: `ALLOW_LOCAL=true`)
- **All API keys externalised** — nothing hardcoded, only `.env` configuration

```
┌─────────────────────────────────────────────────────────────┐
│              Caddy / nginx (HTTPS, port 443)                │
└────────────────┬────────────────────────────────────────────┘
                 │
    ┌────────────┴────────────┐
    │                         │
┌───▼──────────┐    ┌─────────▼──────────────────────────────┐
│ Next.js 15   │    │  Go orchestrator (port 8080)            │
│ frontend     │    │  ├─ 44 tool registry                    │
│ (port 3000)  │    │  ├─ 14 skill modules (BH-Pro merged)    │
│              │    │  ├─ JWT auth + RBAC (admin/hunter/view) │
│ 10 tabs:     │    │  ├─ Adaptive per-target rate limiter    │
│ Pipeline     │    │  ├─ AI priority scoring (P1-P4)         │
│ Arsenal      │    │  ├─ Historical diff engine              │
│ Terminal     │    │  ├─ ROE Gate enforcement                │
│ Findings     │    │  └─ VPS-only enforcement                │
│ Skills (NEW) │    └────────┬───────────────────┬────────────┘
│ Priority     │             │                   │
│ Delta        │    ┌────────▼─────────┐ ┌───────▼────────────┐
│ AI Agent     │    │  Python agents   │ │  Kali tool container│
│ Report       │    │  (specialist)    │ │  100+ tools         │
│ Rate Limit   │    │  - VulnScanner   │ │  subfinder, nuclei  │
│              │    │  - SecretScanner │ │  ffuf, dalfox       │
└──────────────┘    │  - ComplianceMap │ │  graphw00f, etc.    │
                    │  - DepAuditor    │ │                     │
                    │  - ThreatIntel   │ │                     │
                    │  - IaCScanner    │ │                     │
                    │  - AuthzReviewer │ │                     │
                    └──────────────────┘ └─────────────────────┘
                                  │
                            ┌─────▼──────┐
                            │   Redis    │
                            │ (sessions, │
                            │  pub/sub)  │
                            └────────────┘
```

## Quick start (VPS)

```bash
# One command on a fresh Ubuntu 22.04+ VPS
curl -fsSL https://raw.githubusercontent.com/your-org/bbounty-pro/main/scripts/install-vps.sh | sudo bash
```

The installer prompts for:
- ANTHROPIC_API_KEY (optional, AI features disabled if empty)
- Your domain (e.g., bounty.yourdomain.com)

It auto-configures:
- UFW firewall (only 22/80/443)
- Caddy with auto-SSL
- Docker + Docker Compose
- Random JWT_SECRET + Postgres password

## Manual deployment

See [`docs/VPS_DEPLOYMENT.md`](docs/VPS_DEPLOYMENT.md).

## Local development (override VPS check)

```bash
git clone <repo> && cd bbounty-pro
cp .env.example .env
# edit .env — set ANTHROPIC_API_KEY, JWT_SECRET, ALLOW_LOCAL=true
ALLOW_LOCAL=true make dev
```

## 14 skill modules

| Skill | Runtime | Methodology |
|---|---|---|
| api-security | Go | OWASP API Top 10 |
| bug-bounty | Go | OWASP Top 10 + WAHH |
| cloud-security | Python | CIS Benchmarks |
| devops-security | Mixed | DevSecOps + Supply Chain |
| exploit-dev | Go | MITRE ATT&CK |
| iot-security | Python | OWASP IoT Top 10 |
| malware-analysis | Python | MITRE ATT&CK |
| mobile-security | Python | OWASP MASVS |
| network-security | Go | PTES |
| osint | Mixed | OSINT Framework |
| red-team | Python | MITRE ATT&CK + Kill Chain |
| report-writing | Go | CVSS 3.1 + CWE |
| social-engineering | Python | SET methodology |
| web-audit | Go | OWASP WSTG |

API: `GET /api/v1/skills` lists all. `POST /api/v1/skills/<id>/execute` runs.

## VPS-only enforcement

The orchestrator refuses to start if any of these checks fail:

1. `BIND_ADDR` is loopback (127.0.0.1, localhost, ::1)
2. No public network interface detected
3. `JWT_SECRET` is empty

Override with `ALLOW_LOCAL=true`. Never use in production.

## Security

- All secrets in `.env` (gitignored). Never committed.
- JWT (15min access) + rotating refresh tokens (7 days)
- 3 roles: admin, hunter, viewer
- ROE Gate: scans refused if target out of scope
- Adaptive rate limiting: backs off on 429, ramps up on clean responses
- Caddy auto-SSL with HSTS, X-Frame-Options, CSP

## Authorized use only

Bug bounty programs with confirmed scope. Systems you own. Authorized pentests.
Labs and CTFs. Anything else is illegal regardless of framing.
